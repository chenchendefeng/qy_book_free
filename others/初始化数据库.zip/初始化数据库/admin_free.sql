/*
Navicat MySQL Data Transfer

Source Server         : 192.168.18.210
Source Server Version : 50631
Source Host           : 192.168.18.210:3306
Source Database       : admin_free

Target Server Type    : MYSQL
Target Server Version : 50631
File Encoding         : 65001

Date: 2019-06-03 11:36:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `a_group`
-- ----------------------------
DROP TABLE IF EXISTS `a_group`;
CREATE TABLE `a_group` (
  `id` int(11) NOT NULL,
  `groupName` varchar(64) DEFAULT NULL COMMENT '组名称',
  `parentId` int(11) DEFAULT NULL COMMENT '父组',
  `description` varchar(200) DEFAULT NULL COMMENT '组描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='组表';

-- ----------------------------
-- Records of a_group
-- ----------------------------
INSERT INTO `a_group` VALUES ('1', '1', '-1', '1');

-- ----------------------------
-- Table structure for `a_group_role`
-- ----------------------------
DROP TABLE IF EXISTS `a_group_role`;
CREATE TABLE `a_group_role` (
  `id` int(11) NOT NULL,
  `gid` int(11) DEFAULT NULL,
  `rid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='组角色表';

-- ----------------------------
-- Records of a_group_role
-- ----------------------------

-- ----------------------------
-- Table structure for `a_group_user`
-- ----------------------------
DROP TABLE IF EXISTS `a_group_user`;
CREATE TABLE `a_group_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户组表';

-- ----------------------------
-- Records of a_group_user
-- ----------------------------

-- ----------------------------
-- Table structure for `a_log`
-- ----------------------------
DROP TABLE IF EXISTS `a_log`;
CREATE TABLE `a_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminId` int(11) NOT NULL COMMENT '操作人id',
  `userName` varchar(64) DEFAULT NULL COMMENT '操作账户名',
  `handleType` tinyint(2) NOT NULL COMMENT '操作类型 0-新增 1-删除 2-更新',
  `tableName` varchar(64) DEFAULT NULL COMMENT '操作表名',
  `tableId` varchar(1024) DEFAULT NULL COMMENT '操作表id',
  `description` varchar(128) DEFAULT NULL COMMENT '操作描述',
  `handleContent` varchar(1024) DEFAULT NULL COMMENT '操作内容',
  `loginIp` varchar(16) DEFAULT NULL COMMENT '登录ip',
  `dateCreate` datetime DEFAULT NULL,
  `dateUpdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AL_AI` (`adminId`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COMMENT='操作日志表';

-- ----------------------------
-- Records of a_log
-- ----------------------------
INSERT INTO `a_log` VALUES ('12', '1', 'admin', '2', 'a_user', '1', '修改用户信息', null, '172.18.193.9', '2018-12-27 22:59:47', null);
INSERT INTO `a_log` VALUES ('13', '1', 'admin', '2', 'a_role', '14', '更新角色的权限', null, '172.18.193.9', '2018-12-27 23:00:10', null);
INSERT INTO `a_log` VALUES ('14', '1', 'admin', '2', 'a_role', '15', '更新角色的权限', null, '172.18.193.9', '2018-12-27 23:00:54', null);
INSERT INTO `a_log` VALUES ('15', '1', 'admin', '2', 'a_role', '14', '更新角色的权限', null, '172.18.193.9', '2018-12-28 00:09:44', null);
INSERT INTO `a_log` VALUES ('16', '1', 'admin', '0', 'a_user', '61', '添加用户', null, '172.18.193.9', '2019-01-02 17:30:21', null);
INSERT INTO `a_log` VALUES ('17', '1', 'admin', '0', 'a_user', '62', '添加用户', null, '172.18.193.9', '2019-01-02 17:59:18', null);
INSERT INTO `a_log` VALUES ('18', '1', 'admin', '0', 'a_user', '63', '添加用户', null, '172.18.193.9', '2019-01-02 17:59:34', null);
INSERT INTO `a_log` VALUES ('19', '1', 'admin', '0', 'a_user', '64', '添加用户', null, '172.18.193.9', '2019-01-02 18:00:16', null);
INSERT INTO `a_log` VALUES ('20', '1', 'admin', '0', 'a_user', '65', '添加用户', null, '172.18.193.9', '2019-01-02 18:00:29', null);
INSERT INTO `a_log` VALUES ('21', '1', 'admin', '0', 'a_user', '66', '添加用户', null, '172.18.193.9', '2019-01-02 18:00:52', null);
INSERT INTO `a_log` VALUES ('22', '1', 'admin', '0', 'a_user', '67', '添加用户', null, '172.18.193.9', '2019-01-02 18:01:13', null);
INSERT INTO `a_log` VALUES ('23', '1', 'admin', '0', 'a_user', '68', '添加用户', null, '172.18.193.9', '2019-01-02 18:01:35', null);
INSERT INTO `a_log` VALUES ('24', '1', 'admin', '0', 'a_user', '69', '添加用户', null, '172.18.193.9', '2019-01-02 18:02:03', null);
INSERT INTO `a_log` VALUES ('25', '1', 'admin', '0', 'a_user', '70', '添加用户', null, '172.18.193.9', '2019-01-02 18:02:21', null);
INSERT INTO `a_log` VALUES ('26', '1', 'admin', '0', 'a_user', '71', '添加用户', null, '172.18.193.9', '2019-01-02 18:02:54', null);
INSERT INTO `a_log` VALUES ('27', '1', 'admin', '0', 'a_user', '72', '添加用户', null, '172.18.193.9', '2019-01-02 18:03:15', null);
INSERT INTO `a_log` VALUES ('28', '1', 'admin', '2', 'a_user', '1', '修改用户密码', null, '172.18.193.9', '2019-01-02 18:16:10', null);
INSERT INTO `a_log` VALUES ('29', '69', '张威', '2', 'a_user', '69', '修改用户密码', null, '172.18.193.9', '2019-01-14 18:46:11', null);
INSERT INTO `a_log` VALUES ('30', '69', '张威', '2', 'a_user', '69', '修改用户密码', null, '172.18.193.9', '2019-01-14 18:46:56', null);
INSERT INTO `a_log` VALUES ('31', '69', '张威', '2', 'a_user', '68', '修改用户密码', null, '172.18.193.9', '2019-01-14 18:47:39', null);
INSERT INTO `a_log` VALUES ('32', '68', '陈旭', '2', 'a_user', '68', '修改用户密码', null, '172.18.193.9', '2019-01-14 18:48:03', null);
INSERT INTO `a_log` VALUES ('33', '69', '张威', '2', 'a_user', '69', '修改用户信息', null, '172.18.193.9', '2019-01-14 18:49:42', null);
INSERT INTO `a_log` VALUES ('34', '69', '张威', '2', 'a_user', '69', '修改用户信息', null, '172.18.193.9', '2019-01-14 18:50:10', null);
INSERT INTO `a_log` VALUES ('35', '65', '唐涛', '2', 'a_user', '63', '修改用户密码', null, '172.18.193.9', '2019-01-17 13:56:57', null);
INSERT INTO `a_log` VALUES ('36', '1', 'admin', '2', 'a_role', '15', '更新角色的权限', null, '172.18.193.9', '2019-01-22 17:53:47', null);
INSERT INTO `a_log` VALUES ('37', '1', 'admin', '2', 'a_role', '14', '更新角色的权限', null, '172.18.193.9', '2019-01-22 17:54:03', null);
INSERT INTO `a_log` VALUES ('38', '1', 'admin', '2', 'a_role', '15', '更新角色的权限', null, '172.18.193.9', '2019-01-22 17:54:41', null);
INSERT INTO `a_log` VALUES ('39', '62', '傅晗', '0', 'a_role', '19', '添加角色', null, '172.18.193.10', '2019-02-19 16:26:59', null);
INSERT INTO `a_log` VALUES ('40', '62', '傅晗', '2', 'a_role', '19', '更新角色的权限', null, '172.18.193.10', '2019-02-19 16:27:23', null);
INSERT INTO `a_log` VALUES ('41', '62', '傅晗', '1', 'a_role', '19', '批量删除角色', null, '172.18.193.10', '2019-02-19 16:34:49', null);
INSERT INTO `a_log` VALUES ('42', '62', '傅晗', '0', 'a_user', '73', '添加用户', null, '172.18.193.10', '2019-02-19 16:35:10', null);
INSERT INTO `a_log` VALUES ('43', '65', '唐涛', '2', 'a_role', '14', '更新角色的权限', null, '172.18.193.10', '2019-02-27 09:33:10', null);
INSERT INTO `a_log` VALUES ('44', '68', '陈旭', '2', 'a_role', '14', '更新角色的权限', null, '172.18.193.10', '2019-02-27 09:54:51', null);
INSERT INTO `a_log` VALUES ('45', '65', '唐涛', '2', 'a_role', '14', '更新角色的权限', null, '172.18.193.10', '2019-03-04 19:39:25', null);
INSERT INTO `a_log` VALUES ('46', '65', '唐涛', '2', 'a_role', '14', '更新角色的权限', null, '172.18.193.10', '2019-03-25 12:01:17', null);
INSERT INTO `a_log` VALUES ('47', '1', 'admin', '0', 'a_user', '74', '添加用户', null, '192.168.18.24', '2019-05-09 15:38:48', null);

-- ----------------------------
-- Table structure for `a_permission`
-- ----------------------------
DROP TABLE IF EXISTS `a_permission`;
CREATE TABLE `a_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rightName` varchar(64) NOT NULL DEFAULT '' COMMENT '权限名称',
  `url` varchar(255) DEFAULT '',
  `parentId` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL COMMENT '权限描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COMMENT='权限表';

-- ----------------------------
-- Records of a_permission
-- ----------------------------
INSERT INTO `a_permission` VALUES ('1', '会员管理', '/member/list', null, null);
INSERT INTO `a_permission` VALUES ('2', '书籍管理', '/books/list', null, null);
INSERT INTO `a_permission` VALUES ('3', '模块管理', '', null, null);
INSERT INTO `a_permission` VALUES ('4', '礼品管理', '/gifts/list', null, null);
INSERT INTO `a_permission` VALUES ('5', '用户管理', '/user/list', null, null);
INSERT INTO `a_permission` VALUES ('6', '推送管理', '', null, null);
INSERT INTO `a_permission` VALUES ('8', '系统设置', '', null, null);
INSERT INTO `a_permission` VALUES ('10', '会员购买记录', '/member/buyRecord', '1', null);
INSERT INTO `a_permission` VALUES ('11', '充值会员', '/member/recharge', '1', null);
INSERT INTO `a_permission` VALUES ('12', '会员商品管理', '/member/goods', '1', null);
INSERT INTO `a_permission` VALUES ('13', '书籍列表', '/books/list', '2', null);
INSERT INTO `a_permission` VALUES ('14', '个人中心管理', '/module/personal', '3', null);
INSERT INTO `a_permission` VALUES ('15', '福利中心管理', '/module/welfare', '3', null);
INSERT INTO `a_permission` VALUES ('16', '女生专区管理', '/module/girl', '3', null);
INSERT INTO `a_permission` VALUES ('17', '男生专区管理', '/module/boy', '3', null);
INSERT INTO `a_permission` VALUES ('18', '推荐专区管理', '/module/recommend', '3', null);
INSERT INTO `a_permission` VALUES ('19', '弹窗管理', '/module/popups', '3', null);
INSERT INTO `a_permission` VALUES ('20', '启动页管理', '/module/startup', '3', null);
INSERT INTO `a_permission` VALUES ('21', 'banner管理', '/module/banner', '3', null);
INSERT INTO `a_permission` VALUES ('22', '版本管理', '/module/version', '3', null);
INSERT INTO `a_permission` VALUES ('23', '帮助管理', '/module/help', '3', null);
INSERT INTO `a_permission` VALUES ('24', '礼品兑换记录', '/gifts/exchangeList', '4', null);
INSERT INTO `a_permission` VALUES ('25', '礼品列表', '/gifts/list', '4', null);
INSERT INTO `a_permission` VALUES ('26', '用户列表', '/user/list', '5', null);
INSERT INTO `a_permission` VALUES ('27', '用户充值', '/user/recharge', '5', null);
INSERT INTO `a_permission` VALUES ('28', '金豆~红包数据统计', '/user/analysis', '5', null);
INSERT INTO `a_permission` VALUES ('29', '云通信账户', '/push/communicate', '6', null);
INSERT INTO `a_permission` VALUES ('30', '消息推送', '/push/post', '6', null);
INSERT INTO `a_permission` VALUES ('31', '反馈管理', '/push/feedback', '6', null);
INSERT INTO `a_permission` VALUES ('40', '系统用户', '/system/user', '8', null);
INSERT INTO `a_permission` VALUES ('41', '权限管理', '/system/role', '8', null);

-- ----------------------------
-- Table structure for `a_permission_group`
-- ----------------------------
DROP TABLE IF EXISTS `a_permission_group`;
CREATE TABLE `a_permission_group` (
  `id` int(11) NOT NULL,
  `gid` int(11) DEFAULT NULL COMMENT '组id',
  `pid` int(11) DEFAULT NULL COMMENT '权限id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='组权限表';

-- ----------------------------
-- Records of a_permission_group
-- ----------------------------

-- ----------------------------
-- Table structure for `a_permission_role`
-- ----------------------------
DROP TABLE IF EXISTS `a_permission_role`;
CREATE TABLE `a_permission_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_apr_rid` (`rid`) USING BTREE,
  KEY `idx_apr_pid` (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=479 DEFAULT CHARSET=utf8 COMMENT='角色权限表';

-- ----------------------------
-- Records of a_permission_role
-- ----------------------------
INSERT INTO `a_permission_role` VALUES ('287', '15', '23');
INSERT INTO `a_permission_role` VALUES ('288', '15', '28');
INSERT INTO `a_permission_role` VALUES ('289', '15', '9');
INSERT INTO `a_permission_role` VALUES ('290', '15', '22');
INSERT INTO `a_permission_role` VALUES ('291', '15', '13');
INSERT INTO `a_permission_role` VALUES ('292', '15', '19');
INSERT INTO `a_permission_role` VALUES ('293', '15', '21');
INSERT INTO `a_permission_role` VALUES ('294', '15', '16');
INSERT INTO `a_permission_role` VALUES ('295', '15', '14');
INSERT INTO `a_permission_role` VALUES ('296', '15', '17');
INSERT INTO `a_permission_role` VALUES ('297', '15', '20');
INSERT INTO `a_permission_role` VALUES ('298', '15', '15');
INSERT INTO `a_permission_role` VALUES ('299', '15', '18');
INSERT INTO `a_permission_role` VALUES ('300', '15', '32');
INSERT INTO `a_permission_role` VALUES ('301', '15', '38');
INSERT INTO `a_permission_role` VALUES ('302', '15', '37');
INSERT INTO `a_permission_role` VALUES ('303', '19', '23');
INSERT INTO `a_permission_role` VALUES ('304', '19', '26');
INSERT INTO `a_permission_role` VALUES ('305', '19', '29');
INSERT INTO `a_permission_role` VALUES ('306', '19', '27');
INSERT INTO `a_permission_role` VALUES ('307', '19', '31');
INSERT INTO `a_permission_role` VALUES ('308', '19', '28');
INSERT INTO `a_permission_role` VALUES ('309', '19', '25');
INSERT INTO `a_permission_role` VALUES ('310', '19', '24');
INSERT INTO `a_permission_role` VALUES ('311', '19', '30');
INSERT INTO `a_permission_role` VALUES ('312', '19', '13');
INSERT INTO `a_permission_role` VALUES ('313', '19', '19');
INSERT INTO `a_permission_role` VALUES ('314', '19', '21');
INSERT INTO `a_permission_role` VALUES ('315', '19', '16');
INSERT INTO `a_permission_role` VALUES ('316', '19', '14');
INSERT INTO `a_permission_role` VALUES ('317', '19', '17');
INSERT INTO `a_permission_role` VALUES ('318', '19', '20');
INSERT INTO `a_permission_role` VALUES ('319', '19', '15');
INSERT INTO `a_permission_role` VALUES ('320', '19', '18');
INSERT INTO `a_permission_role` VALUES ('428', '14', '1');
INSERT INTO `a_permission_role` VALUES ('429', '14', '2');
INSERT INTO `a_permission_role` VALUES ('430', '14', '3');
INSERT INTO `a_permission_role` VALUES ('431', '14', '4');
INSERT INTO `a_permission_role` VALUES ('432', '14', '5');
INSERT INTO `a_permission_role` VALUES ('433', '14', '6');
INSERT INTO `a_permission_role` VALUES ('434', '14', '9');
INSERT INTO `a_permission_role` VALUES ('435', '14', '8');
INSERT INTO `a_permission_role` VALUES ('437', '14', '11');
INSERT INTO `a_permission_role` VALUES ('438', '14', '12');
INSERT INTO `a_permission_role` VALUES ('439', '14', '30');
INSERT INTO `a_permission_role` VALUES ('444', '14', '22');
INSERT INTO `a_permission_role` VALUES ('446', '14', '13');
INSERT INTO `a_permission_role` VALUES ('447', '14', '19');
INSERT INTO `a_permission_role` VALUES ('448', '14', '21');
INSERT INTO `a_permission_role` VALUES ('449', '14', '16');
INSERT INTO `a_permission_role` VALUES ('450', '14', '25');
INSERT INTO `a_permission_role` VALUES ('451', '14', '14');
INSERT INTO `a_permission_role` VALUES ('452', '14', '17');
INSERT INTO `a_permission_role` VALUES ('453', '14', '20');
INSERT INTO `a_permission_role` VALUES ('454', '14', '15');
INSERT INTO `a_permission_role` VALUES ('455', '14', '18');
INSERT INTO `a_permission_role` VALUES ('456', '14', '32');
INSERT INTO `a_permission_role` VALUES ('458', '14', '38');
INSERT INTO `a_permission_role` VALUES ('459', '14', '35');
INSERT INTO `a_permission_role` VALUES ('460', '14', '26');
INSERT INTO `a_permission_role` VALUES ('461', '14', '34');
INSERT INTO `a_permission_role` VALUES ('462', '14', '23');
INSERT INTO `a_permission_role` VALUES ('463', '14', '36');
INSERT INTO `a_permission_role` VALUES ('464', '14', '37');
INSERT INTO `a_permission_role` VALUES ('465', '14', '29');
INSERT INTO `a_permission_role` VALUES ('466', '14', '40');
INSERT INTO `a_permission_role` VALUES ('467', '14', '33');
INSERT INTO `a_permission_role` VALUES ('468', '14', '10');
INSERT INTO `a_permission_role` VALUES ('469', '14', '24');
INSERT INTO `a_permission_role` VALUES ('472', '14', '28');
INSERT INTO `a_permission_role` VALUES ('473', '14', '41');
INSERT INTO `a_permission_role` VALUES ('476', '14', '27');
INSERT INTO `a_permission_role` VALUES ('478', '14', '31');

-- ----------------------------
-- Table structure for `a_role`
-- ----------------------------
DROP TABLE IF EXISTS `a_role`;
CREATE TABLE `a_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(64) NOT NULL DEFAULT '',
  `parentId` bigint(11) DEFAULT NULL COMMENT '父级角色ID',
  `description` varchar(200) DEFAULT NULL COMMENT '角色描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='角色表';

-- ----------------------------
-- Records of a_role
-- ----------------------------
INSERT INTO `a_role` VALUES ('14', '系统管理员', '0', '管理员');
INSERT INTO `a_role` VALUES ('15', '员工', '0', '员工');

-- ----------------------------
-- Table structure for `a_user`
-- ----------------------------
DROP TABLE IF EXISTS `a_user`;
CREATE TABLE `a_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loginName` varchar(64) NOT NULL DEFAULT '' COMMENT '登录账户',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '密码',
  `userName` varchar(64) DEFAULT NULL COMMENT '用户姓名',
  `lastLoginTime` datetime DEFAULT NULL COMMENT '最近登录时间',
  `lastLoginIp` varchar(16) DEFAULT NULL COMMENT '最近登录ip',
  `dateCreate` datetime DEFAULT NULL,
  `dateUpdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AU_LN` (`loginName`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- ----------------------------
-- Records of a_user
-- ----------------------------
INSERT INTO `a_user` VALUES ('1', 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'admin', '2019-06-03 11:27:03', '192.168.18.13', null, '2019-06-03 11:27:03');
INSERT INTO `a_user` VALUES ('62', 'fuhan', 'e10adc3949ba59abbe56e057f20f883e', '傅晗', '2019-04-09 18:33:34', '172.18.193.10', '2019-01-02 17:59:18', '2019-04-09 18:33:34');
INSERT INTO `a_user` VALUES ('63', 'wuliu', 'e10adc3949ba59abbe56e057f20f883e', '吴柳', '2019-02-26 13:47:32', '172.18.193.10', '2019-01-02 17:59:34', '2019-02-26 13:47:32');
INSERT INTO `a_user` VALUES ('64', 'chenhong', 'e10adc3949ba59abbe56e057f20f883e', '陈洪', '2019-04-25 17:59:21', '192.168.18.15', '2019-01-02 18:00:16', '2019-04-25 17:59:21');
INSERT INTO `a_user` VALUES ('65', 'tangtao', '35fd19fbe470f0cb5581884fa700610f', '唐涛', '2019-04-11 17:43:26', '172.18.193.10', '2019-01-02 18:00:29', '2019-04-11 17:43:26');
INSERT INTO `a_user` VALUES ('66', 'wangshuaishuai', 'e10adc3949ba59abbe56e057f20f883e', '王帅帅', null, null, '2019-01-02 18:00:52', null);
INSERT INTO `a_user` VALUES ('67', 'wangsibei', 'e10adc3949ba59abbe56e057f20f883e', '王思贝', '2019-04-10 10:00:40', '172.18.193.10', '2019-01-02 18:01:13', '2019-04-10 10:00:40');
INSERT INTO `a_user` VALUES ('68', 'chenxu', 'a66abb5684c45962d887564f08346e8d', '陈旭', '2019-04-02 11:31:51', '172.18.193.10', '2019-01-02 18:01:35', '2019-04-02 11:31:51');
INSERT INTO `a_user` VALUES ('71', 'huangbing', 'e10adc3949ba59abbe56e057f20f883e', '黄兵', '2019-04-08 11:08:52', '172.18.193.10', '2019-01-02 18:02:54', '2019-04-08 11:08:52');
INSERT INTO `a_user` VALUES ('72', 'tianwei', 'e10adc3949ba59abbe56e057f20f883e', '田伟', null, null, '2019-01-02 18:03:15', null);
INSERT INTO `a_user` VALUES ('73', 'xinwei', 'e10adc3949ba59abbe56e057f20f883e', 'xinwei', '2019-03-22 14:32:45', '172.18.193.10', '2019-02-19 16:35:10', '2019-03-22 14:32:45');
INSERT INTO `a_user` VALUES ('74', 'test', '202cb962ac59075b964b07152d234b70', 'tester', '2019-05-09 15:39:10', '192.168.18.24', '2019-05-09 15:38:48', '2019-05-09 15:39:10');

-- ----------------------------
-- Table structure for `a_user_role`
-- ----------------------------
DROP TABLE IF EXISTS `a_user_role`;
CREATE TABLE `a_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aur_uid` (`id`) USING BTREE,
  KEY `idx_aur_rid` (`rid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COMMENT='用户角色表';

-- ----------------------------
-- Records of a_user_role
-- ----------------------------
INSERT INTO `a_user_role` VALUES ('56', '14', '1');
INSERT INTO `a_user_role` VALUES ('57', '15', '61');
INSERT INTO `a_user_role` VALUES ('58', '14', '62');
INSERT INTO `a_user_role` VALUES ('59', '14', '63');
INSERT INTO `a_user_role` VALUES ('60', '14', '64');
INSERT INTO `a_user_role` VALUES ('61', '14', '65');
INSERT INTO `a_user_role` VALUES ('62', '15', '66');
INSERT INTO `a_user_role` VALUES ('63', '15', '67');
INSERT INTO `a_user_role` VALUES ('64', '15', '68');
INSERT INTO `a_user_role` VALUES ('66', '15', '70');
INSERT INTO `a_user_role` VALUES ('67', '15', '71');
INSERT INTO `a_user_role` VALUES ('68', '15', '72');
INSERT INTO `a_user_role` VALUES ('70', '15', '69');
INSERT INTO `a_user_role` VALUES ('71', '14', '73');
INSERT INTO `a_user_role` VALUES ('72', '15', '74');

-- ----------------------------
-- Table structure for `channle_manage`
-- ----------------------------
DROP TABLE IF EXISTS `channle_manage`;
CREATE TABLE `channle_manage` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `channle` varchar(20) DEFAULT NULL COMMENT '渠道号',
  `name` varchar(25) DEFAULT NULL COMMENT '名称',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `valid` smallint(2) DEFAULT '1' COMMENT '有效状态(1:有效 0:无效)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='渠道管理';

-- ----------------------------
-- Records of channle_manage
-- ----------------------------
INSERT INTO `channle_manage` VALUES ('1', '100', '官网', '2018-12-27 11:05:37', '2019-01-15 11:05:39', '1');
INSERT INTO `channle_manage` VALUES ('2', '102', '应用宝', '2018-12-27 11:05:37', '2018-12-27 11:05:37', '1');
INSERT INTO `channle_manage` VALUES ('3', '103', '华为', '2018-12-27 11:05:37', '2018-12-27 11:05:37', '1');
INSERT INTO `channle_manage` VALUES ('4', '104', '小米', '2018-12-27 11:05:37', '2018-12-27 11:05:37', '1');
INSERT INTO `channle_manage` VALUES ('5', '105', '百度', '2018-12-27 11:05:37', '2018-12-27 11:05:37', '1');
INSERT INTO `channle_manage` VALUES ('6', '106', '豌豆荚', '2018-12-27 11:05:37', '2018-12-27 11:05:37', '1');
INSERT INTO `channle_manage` VALUES ('7', '107', 'OPPO', '2018-12-27 11:05:37', '2018-12-27 11:05:37', '1');
INSERT INTO `channle_manage` VALUES ('8', '108', '搜狗', '2018-12-27 11:05:37', '2018-12-27 11:05:37', '1');
INSERT INTO `channle_manage` VALUES ('9', '109', '魅族', '2018-12-27 11:05:37', '2018-12-27 11:05:37', '1');
INSERT INTO `channle_manage` VALUES ('10', '110', 'VIVO', '2018-12-27 11:05:37', '2018-12-27 11:05:37', '1');
INSERT INTO `channle_manage` VALUES ('11', '111', 'PP助手', '2018-12-27 11:05:37', '2018-12-27 11:05:37', '1');
INSERT INTO `channle_manage` VALUES ('12', '101', '360', '2019-01-15 16:31:37', null, '1');
INSERT INTO `channle_manage` VALUES ('13', '200', 'IOS', null, null, '1');
INSERT INTO `channle_manage` VALUES ('14', '112', '三星', '2019-02-28 13:39:13', '2019-02-28 13:39:16', '1');

-- ----------------------------
-- Table structure for `client_type`
-- ----------------------------
DROP TABLE IF EXISTS `client_type`;
CREATE TABLE `client_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) DEFAULT NULL COMMENT '客户端类型（IOS,ANDROID）',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='客户端类型表';

-- ----------------------------
-- Records of client_type
-- ----------------------------
INSERT INTO `client_type` VALUES ('1', 'IOS', '2018-12-27 10:59:51', '2018-12-27 10:59:57');
INSERT INTO `client_type` VALUES ('2', 'Android', '2018-12-27 11:00:32', '2018-12-27 11:00:35');

-- ----------------------------
-- Table structure for `customer_manage_record`
-- ----------------------------
DROP TABLE IF EXISTS `customer_manage_record`;
CREATE TABLE `customer_manage_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `staffId` int(11) DEFAULT NULL COMMENT '管理人员id',
  `uid` bigint(20) DEFAULT NULL COMMENT '用户id',
  `cbid` bigint(20) DEFAULT NULL COMMENT '书籍id',
  `name` varchar(50) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL COMMENT '修改类型',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `createDate` datetime DEFAULT NULL,
  `loginIp` varchar(50) DEFAULT NULL COMMENT '登录ip',
  `staffName` varchar(50) DEFAULT NULL COMMENT '用户名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COMMENT='管理用户记录表';

-- ----------------------------
-- Records of customer_manage_record
-- ----------------------------
INSERT INTO `customer_manage_record` VALUES ('1', '65', null, null, null, '4', '修改1000/1书币', '2019-02-27 11:00:56', '172.18.193.10', '唐涛');
INSERT INTO `customer_manage_record` VALUES ('2', '65', null, null, null, '4', '修改1000/1书币', '2019-02-27 11:01:17', '172.18.193.10', '唐涛');
INSERT INTO `customer_manage_record` VALUES ('3', '65', '104561', null, null, '1', '减去1000书币', '2019-02-27 14:23:22', '172.18.193.10', '唐涛');
INSERT INTO `customer_manage_record` VALUES ('4', '71', '104557', null, null, '1', '增加-100书币', '2019-02-27 15:31:00', '172.18.193.10', '黄兵');
INSERT INTO `customer_manage_record` VALUES ('5', '68', null, null, null, '4', '下架', '2019-03-01 09:50:40', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('6', '68', null, null, null, '4', '上架', '2019-03-01 09:50:43', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('7', '68', null, null, null, '4', '下架', '2019-03-01 09:50:54', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('8', '68', null, null, null, '4', '上架', '2019-03-01 09:50:56', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('9', '68', null, null, null, '4', '下架', '2019-03-01 09:51:55', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('10', '68', null, null, null, '4', '上架', '2019-03-01 09:51:58', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('11', '68', null, null, null, '4', '下架', '2019-03-01 09:52:47', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('12', '68', null, null, null, '4', '上架', '2019-03-01 09:52:50', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('13', '68', null, null, null, '4', '下架', '2019-03-01 09:53:08', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('14', '68', null, null, null, '4', '上架', '2019-03-01 09:53:22', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('15', '68', null, null, null, '4', '下架', '2019-03-01 09:53:37', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('16', '68', null, null, null, '4', '上架', '2019-03-01 09:53:39', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('17', '68', null, null, null, '4', '下架', '2019-03-01 09:54:00', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('18', '68', null, null, null, '4', '上架', '2019-03-01 09:54:03', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('19', '68', null, null, null, '4', '下架', '2019-03-01 09:54:48', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('20', '68', null, null, null, '4', '上架', '2019-03-01 09:54:51', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('21', '68', null, null, null, '4', '下架', '2019-03-01 09:55:05', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('22', '68', null, null, null, '4', '上架', '2019-03-01 09:55:08', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('23', '68', null, null, null, '4', '下架', '2019-03-01 09:55:18', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('24', '68', null, null, null, '4', '上架', '2019-03-01 09:55:20', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('25', '68', null, null, null, '4', '下架', '2019-03-01 09:55:30', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('26', '68', null, null, null, '4', '上架', '2019-03-01 09:55:33', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('27', '68', null, null, null, '4', '下架', '2019-03-01 09:55:46', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('28', '68', null, null, null, '4', '上架', '2019-03-01 09:55:48', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('29', '68', null, null, null, '4', '下架', '2019-03-01 09:55:55', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('30', '68', null, null, null, '4', '上架', '2019-03-01 09:55:57', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('31', '68', null, null, null, '4', '下架', '2019-03-01 09:56:04', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('32', '68', null, null, null, '4', '上架', '2019-03-01 09:56:06', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('33', '68', null, null, null, '4', '下架', '2019-03-01 10:11:35', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('34', '68', null, null, null, '4', '上架', '2019-03-01 10:11:38', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('35', '68', null, null, null, '4', '下架', '2019-03-01 10:12:09', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('36', '68', null, null, null, '4', '上架', '2019-03-01 10:12:11', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('37', '68', null, null, null, '4', '下架', '2019-03-01 10:12:19', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('38', '68', null, null, null, '4', '上架', '2019-03-01 10:12:21', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('39', '68', null, null, null, '4', '下架', '2019-03-01 10:12:28', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('40', '68', null, null, null, '4', '上架', '2019-03-01 10:12:29', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('41', '68', null, null, null, '4', '下架', '2019-03-01 10:12:34', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('42', '68', null, null, null, '4', '上架', '2019-03-01 10:12:36', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('43', '68', null, null, null, '4', '下架', '2019-03-01 10:12:42', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('44', '68', null, null, null, '4', '上架', '2019-03-01 10:12:44', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('45', '68', null, null, null, '4', '下架', '2019-03-01 10:12:50', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('46', '68', null, null, null, '4', '上架', '2019-03-01 10:12:52', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('47', '68', null, null, null, '4', '下架', '2019-03-01 10:12:57', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('48', '68', null, null, null, '4', '上架', '2019-03-01 10:12:59', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('49', '68', null, null, null, '4', '下架', '2019-03-01 10:13:05', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('50', '68', null, null, null, '4', '上架', '2019-03-01 10:13:07', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('51', '68', null, null, null, '4', '下架', '2019-03-01 10:13:13', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('52', '68', null, null, null, '4', '上架', '2019-03-01 10:13:15', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('53', '68', null, null, null, '4', '下架', '2019-03-01 10:13:26', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('54', '68', null, null, null, '4', '上架', '2019-03-01 10:13:28', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('55', '68', null, null, null, '4', '下架', '2019-03-01 10:13:35', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('56', '68', null, null, null, '4', '上架', '2019-03-01 10:13:37', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('57', '68', null, null, null, '4', '下架', '2019-03-01 10:13:47', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('58', '68', null, null, null, '4', '下架', '2019-03-01 10:13:57', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('59', '68', null, null, null, '4', '上架', '2019-03-01 10:13:59', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('60', '68', null, null, null, '4', '下架', '2019-03-01 10:14:05', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('61', '68', null, null, null, '4', '上架', '2019-03-01 10:14:07', '172.18.193.10', '陈旭');
INSERT INTO `customer_manage_record` VALUES ('62', '65', '104562', null, null, '1', '减去3440书币', '2019-03-05 18:32:36', '172.18.193.10', '唐涛');
