/*
Navicat MySQL Data Transfer

Source Server         : 192.168.18.210
Source Server Version : 50631
Source Host           : 192.168.18.210:3306
Source Database       : user_free

Target Server Type    : MYSQL
Target Server Version : 50631
File Encoding         : 65001

Date: 2019-06-03 11:37:32
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `account_flow_record`
-- ----------------------------
DROP TABLE IF EXISTS `account_flow_record`;
CREATE TABLE `account_flow_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL COMMENT '用户id',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `changeType` varchar(50) DEFAULT NULL COMMENT '类型（recharge:充值;reward：奖励;consume:消费；）',
  `specificType` varchar(50) DEFAULT NULL COMMENT '具体类型',
  `currencyType` varchar(20) DEFAULT NULL COMMENT '币种（rmb：现金；gold：金币）',
  `amount` bigint(20) DEFAULT NULL COMMENT '金额',
  `img` varchar(255) DEFAULT NULL COMMENT '图片',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=307 DEFAULT CHARSET=utf8 COMMENT='账户流水';

-- ----------------------------
-- Records of account_flow_record
-- ----------------------------
INSERT INTO `account_flow_record` VALUES ('1', '112233', '阅读福利', 'reward', null, 'gold', '150', null, '2019-05-09 17:27:40', '今日累计阅读30分钟，奖励金豆100');
INSERT INTO `account_flow_record` VALUES ('2', '112233', '注册红包', 'reward', ' RegisterRedpack', 'rmb', '491', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-10 10:35:51', null);
INSERT INTO `account_flow_record` VALUES ('3', '112233', '注册奖励', 'reward', ' RegisterAward', 'gold', '10000', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-10 10:35:51', null);
INSERT INTO `account_flow_record` VALUES ('4', '118814', '注册红包', 'reward', ' RegisterRedpack', 'rmb', '102', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-10 10:37:36', null);
INSERT INTO `account_flow_record` VALUES ('5', '118814', '注册奖励', 'reward', ' RegisterAward', 'gold', '10000', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-10 10:37:36', null);
INSERT INTO `account_flow_record` VALUES ('6', '118812', '注册红包', 'reward', ' RegisterRedpack', 'rmb', '146', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-10 10:44:30', null);
INSERT INTO `account_flow_record` VALUES ('7', '118812', '注册奖励', 'reward', ' RegisterAward', 'gold', '10000', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-10 10:44:30', null);
INSERT INTO `account_flow_record` VALUES ('8', '118814', '阅读福利', 'reward', null, 'gold', '30', null, '2019-05-10 14:15:03', null);
INSERT INTO `account_flow_record` VALUES ('9', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 13:47:56', null);
INSERT INTO `account_flow_record` VALUES ('10', '118819', '消费退回', 'consumeReturn', null, 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/recharge.png', '2019-05-14 13:47:56', null);
INSERT INTO `account_flow_record` VALUES ('11', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 13:49:00', null);
INSERT INTO `account_flow_record` VALUES ('12', '118819', '消费退回', 'consumeReturn', null, 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/recharge.png', '2019-05-14 13:49:00', null);
INSERT INTO `account_flow_record` VALUES ('13', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 13:53:02', null);
INSERT INTO `account_flow_record` VALUES ('14', '118819', '消费退回', 'consumeReturn', null, 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/recharge.png', '2019-05-14 13:53:02', null);
INSERT INTO `account_flow_record` VALUES ('15', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 13:54:28', null);
INSERT INTO `account_flow_record` VALUES ('16', '118819', '消费退回', 'consumeReturn', null, 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/recharge.png', '2019-05-14 13:54:28', null);
INSERT INTO `account_flow_record` VALUES ('17', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 13:58:39', null);
INSERT INTO `account_flow_record` VALUES ('18', '118819', '消费退回', 'consumeReturn', null, 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/recharge.png', '2019-05-14 13:58:39', null);
INSERT INTO `account_flow_record` VALUES ('19', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:05:16', null);
INSERT INTO `account_flow_record` VALUES ('20', '118819', '消费退回', 'consumeReturn', null, 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/recharge.png', '2019-05-14 14:05:44', null);
INSERT INTO `account_flow_record` VALUES ('21', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:06:47', null);
INSERT INTO `account_flow_record` VALUES ('22', '118819', '消费退回', 'consumeReturn', null, 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/recharge.png', '2019-05-14 14:07:16', null);
INSERT INTO `account_flow_record` VALUES ('23', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:08:32', null);
INSERT INTO `account_flow_record` VALUES ('24', '118819', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:08:32', null);
INSERT INTO `account_flow_record` VALUES ('25', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:09:17', null);
INSERT INTO `account_flow_record` VALUES ('26', '118819', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:09:17', null);
INSERT INTO `account_flow_record` VALUES ('27', '118819', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:11:21', null);
INSERT INTO `account_flow_record` VALUES ('28', '118819', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:11:46', null);
INSERT INTO `account_flow_record` VALUES ('29', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:11:50', null);
INSERT INTO `account_flow_record` VALUES ('30', '118819', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:11:50', null);
INSERT INTO `account_flow_record` VALUES ('31', '118819', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:14:47', null);
INSERT INTO `account_flow_record` VALUES ('32', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:16:04', null);
INSERT INTO `account_flow_record` VALUES ('33', '118819', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:16:04', null);
INSERT INTO `account_flow_record` VALUES ('34', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:17:59', null);
INSERT INTO `account_flow_record` VALUES ('35', '118819', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:17:59', null);
INSERT INTO `account_flow_record` VALUES ('36', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:18:17', null);
INSERT INTO `account_flow_record` VALUES ('37', '118819', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:18:17', null);
INSERT INTO `account_flow_record` VALUES ('38', '118819', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:19:23', null);
INSERT INTO `account_flow_record` VALUES ('39', '118819', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '14', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:19:23', null);
INSERT INTO `account_flow_record` VALUES ('40', '118821', '注册红包', 'reward', ' RegisterRedpack', 'rmb', '395', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:37:05', null);
INSERT INTO `account_flow_record` VALUES ('41', '118821', '注册奖励', 'reward', ' RegisterAward', 'gold', '10000', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:37:05', null);
INSERT INTO `account_flow_record` VALUES ('42', '118819', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '150', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 14:56:42', null);
INSERT INTO `account_flow_record` VALUES ('43', '118829', '注册红包', 'reward', ' RegisterRedpack', 'rmb', '238', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 16:57:39', null);
INSERT INTO `account_flow_record` VALUES ('44', '118829', '注册奖励', 'reward', ' RegisterAward', 'gold', '10000', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 16:57:39', null);
INSERT INTO `account_flow_record` VALUES ('45', '118816', '注册红包', 'reward', ' RegisterRedpack', 'rmb', '214', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 16:58:37', null);
INSERT INTO `account_flow_record` VALUES ('46', '118816', '注册奖励', 'reward', ' RegisterAward', 'gold', '10000', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 16:58:37', null);
INSERT INTO `account_flow_record` VALUES ('47', '118820', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 17:43:02', null);
INSERT INTO `account_flow_record` VALUES ('62', '118829', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '150', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 18:22:18', null);
INSERT INTO `account_flow_record` VALUES ('63', '118829', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 18:25:04', null);
INSERT INTO `account_flow_record` VALUES ('64', '118829', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 18:25:04', null);
INSERT INTO `account_flow_record` VALUES ('65', '118829', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 18:26:20', null);
INSERT INTO `account_flow_record` VALUES ('66', '118829', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '14', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-14 18:26:20', null);
INSERT INTO `account_flow_record` VALUES ('67', '118842', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-16 14:24:15', null);
INSERT INTO `account_flow_record` VALUES ('68', '118814', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-20 19:00:26', null);
INSERT INTO `account_flow_record` VALUES ('69', '118851', '每日分享奖励[]金豆', 'reward', 'DailySharingAward', 'gold', '76', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-22 20:28:20', null);
INSERT INTO `account_flow_record` VALUES ('71', '118853', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-23 16:39:14', null);
INSERT INTO `account_flow_record` VALUES ('72', '118852', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-23 18:09:16', null);
INSERT INTO `account_flow_record` VALUES ('73', '118852', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-23 18:57:30', null);
INSERT INTO `account_flow_record` VALUES ('74', '118852', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-23 19:46:56', null);
INSERT INTO `account_flow_record` VALUES ('75', '118852', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-23 19:51:31', null);
INSERT INTO `account_flow_record` VALUES ('76', '118852', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-23 19:51:56', null);
INSERT INTO `account_flow_record` VALUES ('77', '118852', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-23 20:16:31', null);
INSERT INTO `account_flow_record` VALUES ('78', '118852', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 09:25:48', null);
INSERT INTO `account_flow_record` VALUES ('80', '118852', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 10:40:23', null);
INSERT INTO `account_flow_record` VALUES ('81', '118852', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 10:40:33', null);
INSERT INTO `account_flow_record` VALUES ('82', '118852', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 10:43:41', null);
INSERT INTO `account_flow_record` VALUES ('83', '118852', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 10:52:13', null);
INSERT INTO `account_flow_record` VALUES ('84', '118855', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 11:16:58', null);
INSERT INTO `account_flow_record` VALUES ('88', '118814', '观看小视频奖励100金豆', 'reward', 'WatchSmallVideoAward', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 11:39:21', null);
INSERT INTO `account_flow_record` VALUES ('133', '118856', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-20 14:00:37', null);
INSERT INTO `account_flow_record` VALUES ('134', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-21 14:01:01', null);
INSERT INTO `account_flow_record` VALUES ('135', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-22 14:01:15', null);
INSERT INTO `account_flow_record` VALUES ('136', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-23 14:01:28', null);
INSERT INTO `account_flow_record` VALUES ('139', '118856', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '150', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:05:21', null);
INSERT INTO `account_flow_record` VALUES ('140', '118856', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:06:45', null);
INSERT INTO `account_flow_record` VALUES ('141', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '20', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:06:45', null);
INSERT INTO `account_flow_record` VALUES ('142', '118856', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:06:52', null);
INSERT INTO `account_flow_record` VALUES ('143', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '22', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:06:52', null);
INSERT INTO `account_flow_record` VALUES ('144', '118856', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:06:55', null);
INSERT INTO `account_flow_record` VALUES ('145', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '24', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:06:55', null);
INSERT INTO `account_flow_record` VALUES ('146', '118856', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:06:59', null);
INSERT INTO `account_flow_record` VALUES ('147', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '26', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:06:59', null);
INSERT INTO `account_flow_record` VALUES ('148', '118856', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '300', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:07:13', null);
INSERT INTO `account_flow_record` VALUES ('149', '118856', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '300', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:13:01', null);
INSERT INTO `account_flow_record` VALUES ('150', '118856', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '1000', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:17:55', null);
INSERT INTO `account_flow_record` VALUES ('151', '118851', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:18:06', null);
INSERT INTO `account_flow_record` VALUES ('152', '118856', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '1000', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:27:33', null);
INSERT INTO `account_flow_record` VALUES ('153', '118852', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:31:51', null);
INSERT INTO `account_flow_record` VALUES ('154', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:32:48', null);
INSERT INTO `account_flow_record` VALUES ('155', '118856', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '1000', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:37:35', null);
INSERT INTO `account_flow_record` VALUES ('156', '118856', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:38:44', null);
INSERT INTO `account_flow_record` VALUES ('157', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:39:20', null);
INSERT INTO `account_flow_record` VALUES ('158', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '14', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:40:03', null);
INSERT INTO `account_flow_record` VALUES ('159', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:40:18', null);
INSERT INTO `account_flow_record` VALUES ('160', '118856', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:40:52', null);
INSERT INTO `account_flow_record` VALUES ('161', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:40:52', null);
INSERT INTO `account_flow_record` VALUES ('162', '118856', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:41:36', null);
INSERT INTO `account_flow_record` VALUES ('163', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:41:36', null);
INSERT INTO `account_flow_record` VALUES ('164', '118856', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '150', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 14:42:05', null);
INSERT INTO `account_flow_record` VALUES ('165', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 15:22:39', null);
INSERT INTO `account_flow_record` VALUES ('166', '118856', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 15:23:30', null);
INSERT INTO `account_flow_record` VALUES ('167', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 15:23:30', null);
INSERT INTO `account_flow_record` VALUES ('168', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 15:30:48', null);
INSERT INTO `account_flow_record` VALUES ('169', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 15:33:50', null);
INSERT INTO `account_flow_record` VALUES ('170', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 15:34:28', null);
INSERT INTO `account_flow_record` VALUES ('171', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 15:34:50', null);
INSERT INTO `account_flow_record` VALUES ('172', '118856', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 15:35:44', null);
INSERT INTO `account_flow_record` VALUES ('173', '118814', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 17:01:05', null);
INSERT INTO `account_flow_record` VALUES ('174', '118814', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 17:01:05', null);
INSERT INTO `account_flow_record` VALUES ('175', '118814', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 17:02:34', null);
INSERT INTO `account_flow_record` VALUES ('176', '118844', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 17:39:04', null);
INSERT INTO `account_flow_record` VALUES ('177', '118851', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 18:42:00', null);
INSERT INTO `account_flow_record` VALUES ('178', '118851', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 18:43:33', null);
INSERT INTO `account_flow_record` VALUES ('179', '118851', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-24 18:44:47', null);
INSERT INTO `account_flow_record` VALUES ('180', '118851', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 14:26:47', null);
INSERT INTO `account_flow_record` VALUES ('181', '118814', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '16', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 14:30:39', null);
INSERT INTO `account_flow_record` VALUES ('182', '118814', '观看小视频奖励100金豆', 'reward', 'WatchSmallVideoAward', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 14:31:16', null);
INSERT INTO `account_flow_record` VALUES ('183', '118856', '观看小视频奖励100金豆', 'reward', 'WatchSmallVideoAward', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 17:58:00', null);
INSERT INTO `account_flow_record` VALUES ('184', '118860', '观看小视频奖励100金豆', 'reward', 'WatchSmallVideoAward', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 18:34:43', null);
INSERT INTO `account_flow_record` VALUES ('187', '118860', '每日分享奖励[]金豆', 'reward', 'DailySharingAward', 'gold', '24', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 18:48:22', null);
INSERT INTO `account_flow_record` VALUES ('188', '118859', '每日分享奖励[]金豆', 'reward', 'DailySharingAward', 'gold', '18', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 18:48:46', null);
INSERT INTO `account_flow_record` VALUES ('189', '118857', '每日分享奖励[]金豆', 'reward', 'DailySharingAward', 'gold', '65', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 18:48:59', null);
INSERT INTO `account_flow_record` VALUES ('190', '118814', '每日分享奖励[]金豆', 'reward', 'DailySharingAward', 'gold', '38', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 18:51:14', null);
INSERT INTO `account_flow_record` VALUES ('191', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:11:08', null);
INSERT INTO `account_flow_record` VALUES ('192', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:20:13', null);
INSERT INTO `account_flow_record` VALUES ('193', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:24:26', null);
INSERT INTO `account_flow_record` VALUES ('194', '118859', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:25:03', null);
INSERT INTO `account_flow_record` VALUES ('195', '118859', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:25:08', null);
INSERT INTO `account_flow_record` VALUES ('196', '118859', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:25:51', null);
INSERT INTO `account_flow_record` VALUES ('197', '118859', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:25:57', null);
INSERT INTO `account_flow_record` VALUES ('198', '118859', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:26:09', null);
INSERT INTO `account_flow_record` VALUES ('199', '118857', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:27:11', null);
INSERT INTO `account_flow_record` VALUES ('200', '118857', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:27:42', null);
INSERT INTO `account_flow_record` VALUES ('201', '118857', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:27:52', null);
INSERT INTO `account_flow_record` VALUES ('202', '118857', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:28:01', null);
INSERT INTO `account_flow_record` VALUES ('203', '118857', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-25 19:28:02', null);
INSERT INTO `account_flow_record` VALUES ('204', '118851', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 10:28:31', null);
INSERT INTO `account_flow_record` VALUES ('205', '118863', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 10:35:15', null);
INSERT INTO `account_flow_record` VALUES ('206', '118844', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 11:53:08', null);
INSERT INTO `account_flow_record` VALUES ('207', '118832', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 15:29:45', null);
INSERT INTO `account_flow_record` VALUES ('208', '118832', '观看小视频奖励100金豆', 'reward', 'WatchSmallVideoAward', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 15:30:22', null);
INSERT INTO `account_flow_record` VALUES ('209', '118854', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 16:02:28', null);
INSERT INTO `account_flow_record` VALUES ('210', '118832', '每日分享奖励[]金豆', 'reward', 'DailySharingAward', 'gold', '90', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 16:54:13', null);
INSERT INTO `account_flow_record` VALUES ('211', '118865', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 17:01:02', null);
INSERT INTO `account_flow_record` VALUES ('212', '118837', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 17:30:49', null);
INSERT INTO `account_flow_record` VALUES ('213', '118837', '观看小视频奖励100金豆', 'reward', 'WatchSmallVideoAward', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 17:31:57', null);
INSERT INTO `account_flow_record` VALUES ('214', '118867', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 17:33:56', null);
INSERT INTO `account_flow_record` VALUES ('215', '118866', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 17:52:57', null);
INSERT INTO `account_flow_record` VALUES ('216', '118866', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 18:00:38', null);
INSERT INTO `account_flow_record` VALUES ('217', '118866', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 18:01:42', null);
INSERT INTO `account_flow_record` VALUES ('218', '118869', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-27 19:36:28', null);
INSERT INTO `account_flow_record` VALUES ('219', '118869', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 09:38:50', null);
INSERT INTO `account_flow_record` VALUES ('220', '118814', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 10:32:31', null);
INSERT INTO `account_flow_record` VALUES ('221', '118814', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 10:32:41', null);
INSERT INTO `account_flow_record` VALUES ('222', '118814', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 10:32:41', null);
INSERT INTO `account_flow_record` VALUES ('223', '118814', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '150', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 10:33:16', null);
INSERT INTO `account_flow_record` VALUES ('224', '118814', '观看小视频奖励100金豆', 'reward', 'WatchSmallVideoAward', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 15:45:44', null);
INSERT INTO `account_flow_record` VALUES ('225', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 15:47:13', null);
INSERT INTO `account_flow_record` VALUES ('226', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 15:47:41', null);
INSERT INTO `account_flow_record` VALUES ('227', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 15:48:21', null);
INSERT INTO `account_flow_record` VALUES ('228', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 15:49:11', null);
INSERT INTO `account_flow_record` VALUES ('229', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 15:49:53', null);
INSERT INTO `account_flow_record` VALUES ('230', '118873', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 16:30:11', null);
INSERT INTO `account_flow_record` VALUES ('231', '118814', '每日分享奖励[]金豆', 'reward', 'DailySharingAward', 'gold', '68', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 16:38:09', null);
INSERT INTO `account_flow_record` VALUES ('232', '118844', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 17:10:23', null);
INSERT INTO `account_flow_record` VALUES ('233', '118844', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 17:12:03', null);
INSERT INTO `account_flow_record` VALUES ('234', '118844', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 17:12:30', null);
INSERT INTO `account_flow_record` VALUES ('235', '118844', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 17:12:30', null);
INSERT INTO `account_flow_record` VALUES ('236', '118871', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 17:17:55', null);
INSERT INTO `account_flow_record` VALUES ('237', '118872', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 19:33:07', null);
INSERT INTO `account_flow_record` VALUES ('238', '118872', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 19:33:51', null);
INSERT INTO `account_flow_record` VALUES ('239', '118869', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-28 20:03:56', null);
INSERT INTO `account_flow_record` VALUES ('240', '118814', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '24', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-29 08:54:02', null);
INSERT INTO `account_flow_record` VALUES ('241', '118814', '观看小视频奖励100金豆', 'reward', 'WatchSmallVideoAward', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-29 08:54:22', null);
INSERT INTO `account_flow_record` VALUES ('242', '118869', '阅读福利', 'reward', null, 'gold', '100', null, '2019-05-29 13:01:23', '今日累计阅读30分钟，奖励金豆100');
INSERT INTO `account_flow_record` VALUES ('243', '118869', '阅读福利', 'reward', null, 'gold', '150', null, '2019-05-29 13:32:46', '今日累计阅读60分钟，奖励金豆150');
INSERT INTO `account_flow_record` VALUES ('244', '118869', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '14', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-29 14:27:15', null);
INSERT INTO `account_flow_record` VALUES ('245', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-29 14:39:23', null);
INSERT INTO `account_flow_record` VALUES ('246', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-29 14:40:06', null);
INSERT INTO `account_flow_record` VALUES ('247', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-29 14:40:41', null);
INSERT INTO `account_flow_record` VALUES ('248', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-29 14:41:04', null);
INSERT INTO `account_flow_record` VALUES ('249', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-29 14:41:43', null);
INSERT INTO `account_flow_record` VALUES ('250', '118844', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '20', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-29 15:02:20', null);
INSERT INTO `account_flow_record` VALUES ('251', '118877', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/gift.png', '2019-05-29 15:06:19', null);
INSERT INTO `account_flow_record` VALUES ('252', '118854', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', null, '2019-05-29 16:44:30', null);
INSERT INTO `account_flow_record` VALUES ('253', '118838', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', null, '2019-05-30 09:43:32', null);
INSERT INTO `account_flow_record` VALUES ('254', '118875', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', null, '2019-05-30 09:44:10', null);
INSERT INTO `account_flow_record` VALUES ('255', '118881', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', null, '2019-05-30 09:49:37', null);
INSERT INTO `account_flow_record` VALUES ('256', '118814', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '26', null, '2019-05-30 09:50:37', null);
INSERT INTO `account_flow_record` VALUES ('257', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-30 10:21:11', null);
INSERT INTO `account_flow_record` VALUES ('258', '118886', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', null, '2019-05-30 13:33:11', null);
INSERT INTO `account_flow_record` VALUES ('259', '118886', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-30 13:36:54', null);
INSERT INTO `account_flow_record` VALUES ('260', '118885', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', null, '2019-05-30 13:56:44', null);
INSERT INTO `account_flow_record` VALUES ('261', '118888', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', null, '2019-05-30 16:41:40', null);
INSERT INTO `account_flow_record` VALUES ('262', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-30 18:12:30', null);
INSERT INTO `account_flow_record` VALUES ('263', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-30 18:13:41', null);
INSERT INTO `account_flow_record` VALUES ('264', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-30 18:14:21', null);
INSERT INTO `account_flow_record` VALUES ('265', '118814', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-30 18:15:01', null);
INSERT INTO `account_flow_record` VALUES ('266', '118888', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-30 18:44:06', null);
INSERT INTO `account_flow_record` VALUES ('267', '118814', '连续签到[]奖励', 'reward', 'ContinuityAttendanceAward', 'gold', '300', null, '2019-05-31 10:36:57', null);
INSERT INTO `account_flow_record` VALUES ('268', '118885', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 11:13:35', null);
INSERT INTO `account_flow_record` VALUES ('269', '118885', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 11:19:43', null);
INSERT INTO `account_flow_record` VALUES ('270', '118885', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 11:21:59', null);
INSERT INTO `account_flow_record` VALUES ('271', '118885', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 11:24:06', null);
INSERT INTO `account_flow_record` VALUES ('272', '118885', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 11:24:43', null);
INSERT INTO `account_flow_record` VALUES ('273', '118885', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', null, '2019-05-31 11:42:19', null);
INSERT INTO `account_flow_record` VALUES ('274', '0', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', null, '2019-05-31 16:17:29', null);
INSERT INTO `account_flow_record` VALUES ('275', '118873', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', null, '2019-05-31 16:18:06', null);
INSERT INTO `account_flow_record` VALUES ('276', '118876', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', null, '2019-05-31 16:27:16', null);
INSERT INTO `account_flow_record` VALUES ('277', '118892', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', null, '2019-05-31 16:41:08', null);
INSERT INTO `account_flow_record` VALUES ('278', '118888', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', null, '2019-05-31 16:46:17', null);
INSERT INTO `account_flow_record` VALUES ('279', '118888', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-200', null, '2019-05-31 16:49:05', null);
INSERT INTO `account_flow_record` VALUES ('280', '118888', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', null, '2019-05-31 16:49:05', null);
INSERT INTO `account_flow_record` VALUES ('281', '118892', '首次签到奖励', 'reward', 'First_Attendance_Award', 'gold', '100', null, '2019-05-31 16:49:06', null);
INSERT INTO `account_flow_record` VALUES ('282', '118892', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 16:49:26', null);
INSERT INTO `account_flow_record` VALUES ('283', '118892', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 16:50:36', null);
INSERT INTO `account_flow_record` VALUES ('284', '118892', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 16:51:17', null);
INSERT INTO `account_flow_record` VALUES ('285', '118892', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 16:51:58', null);
INSERT INTO `account_flow_record` VALUES ('286', '118892', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 16:52:27', null);
INSERT INTO `account_flow_record` VALUES ('287', '118876', '幸运转盘奖励50金豆', 'reward', 'DrawLuckyTurntableAward', 'gold', '50', null, '2019-05-31 16:54:04', null);
INSERT INTO `account_flow_record` VALUES ('288', '118888', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-200', null, '2019-05-31 18:51:14', null);
INSERT INTO `account_flow_record` VALUES ('289', '118888', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', null, '2019-05-31 18:51:14', null);
INSERT INTO `account_flow_record` VALUES ('290', '118888', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-200', null, '2019-05-31 18:51:39', null);
INSERT INTO `account_flow_record` VALUES ('291', '118888', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '10', null, '2019-05-31 18:51:39', null);
INSERT INTO `account_flow_record` VALUES ('292', '118888', '补签扣除', 'consume', 'CompensateAttendanceDeduction', 'gold', '-200', null, '2019-05-31 18:51:41', null);
INSERT INTO `account_flow_record` VALUES ('293', '118888', '日常签到奖励', 'reward', 'DailyAttendanceAward', 'gold', '12', null, '2019-05-31 18:51:41', null);
INSERT INTO `account_flow_record` VALUES ('294', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', null, null, '2019-06-03 10:49:01', '充值金豆3个');
INSERT INTO `account_flow_record` VALUES ('295', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', '2', null, '2019-06-03 11:17:17', '充值金豆2个');
INSERT INTO `account_flow_record` VALUES ('296', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', '1', null, '2019-06-03 11:18:07', '充值金豆2个');
INSERT INTO `account_flow_record` VALUES ('297', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', '2', null, '2019-06-03 11:18:36', '充值金豆2个');
INSERT INTO `account_flow_record` VALUES ('298', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', '1', null, '2019-06-03 11:19:57', '充值金豆1个');
INSERT INTO `account_flow_record` VALUES ('299', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', '1', null, '2019-06-03 11:20:52', '充值金豆2个');
INSERT INTO `account_flow_record` VALUES ('300', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', '2', null, '2019-06-03 11:23:44', '充值金豆');
INSERT INTO `account_flow_record` VALUES ('301', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', '2', null, '2019-06-03 11:24:16', '充值金豆2个');
INSERT INTO `account_flow_record` VALUES ('302', '112233', '管理员充值', 'recharge', 'recharege_admin', 'rmb', '200', null, '2019-06-03 11:26:59', '充值现金');
INSERT INTO `account_flow_record` VALUES ('303', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', '11', null, '2019-06-03 11:29:01', 'gold');
INSERT INTO `account_flow_record` VALUES ('304', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', '3', null, '2019-06-03 11:29:04', '充值金豆3个');
INSERT INTO `account_flow_record` VALUES ('305', '112233', '管理员充值', 'recharge', 'recharege_admin', 'gold', '11', null, '2019-06-03 11:29:36', 'gold');
INSERT INTO `account_flow_record` VALUES ('306', '112233', '管理员充值', 'recharge', 'recharege_admin', 'rmb', '11', null, '2019-06-03 11:29:46', 'gold');

-- ----------------------------
-- Table structure for `app_version_manage`
-- ----------------------------
DROP TABLE IF EXISTS `app_version_manage`;
CREATE TABLE `app_version_manage` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `version` varchar(11) DEFAULT NULL COMMENT '版本号',
  `versionCode` int(11) DEFAULT NULL,
  `audit` int(2) DEFAULT '0' COMMENT '审核状态（0:未审核；1：已审核）',
  `enable` tinyint(2) DEFAULT NULL COMMENT '是否启用（0：未启用；1：启用）',
  `clientType` varchar(10) DEFAULT NULL COMMENT '客户端类型（IOS;Android）',
  `createDate` datetime DEFAULT NULL COMMENT '创建日期',
  `miniVersion` varchar(10) DEFAULT NULL COMMENT '最低版本',
  `miniVersionCode` varchar(10) DEFAULT NULL COMMENT '最低版本号',
  `downloadUrl` varchar(100) DEFAULT NULL COMMENT '下载路径',
  `des` varchar(255) DEFAULT NULL COMMENT '描述',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `title` varchar(255) DEFAULT NULL COMMENT '更新主题',
  `intervalTime` int(2) DEFAULT NULL COMMENT '间隔时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `version` (`version`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='app版本管理';

-- ----------------------------
-- Records of app_version_manage
-- ----------------------------
INSERT INTO `app_version_manage` VALUES ('2', '2.0.0', '200', '1', '1', 'IOS', '2019-01-25 11:06:43', '1.0.0', '100', '11', 'test', '2019-03-07 11:45:12', null, null);
INSERT INTO `app_version_manage` VALUES ('4', '4.3.3', '200', '1', '1', 'Android', '2019-02-28 10:33:47', '4.3.1', '431', 'http://wyqy-download.oss-cn-beijing.aliyuncs.com/android_releases/QianYue_v4.3.3_100.apk', '有时，只需要简单改进。\r\n没有大的变动，只是变得更好了', '2019-03-07 13:55:57', null, null);
INSERT INTO `app_version_manage` VALUES ('7', '4.3.4', '200', '0', '1', 'Android', '2019-02-28 10:33:47', '4.3.1', '431', 'http://wyqy-download.oss-cn-beijing.aliyuncs.com/android_releases/QianYue_v4.3.3_100.apk', '445', '2019-03-21 13:55:57', '', null);

-- ----------------------------
-- Table structure for `cloud_communication`
-- ----------------------------
DROP TABLE IF EXISTS `cloud_communication`;
CREATE TABLE `cloud_communication` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) DEFAULT NULL COMMENT '用户id',
  `identifier` varchar(32) DEFAULT NULL COMMENT '用户名',
  `gender` tinyint(2) DEFAULT '1' COMMENT '性别（1:男，2：女）',
  `nick` varchar(50) DEFAULT NULL COMMENT '昵称',
  `faceUrl` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `type` tinyint(1) DEFAULT '0' COMMENT '类型（开发者默认无需填写，值 0 表示普通帐号，1 表示机器人帐号）',
  `usersig` text COMMENT '签名',
  `expireDate` datetime DEFAULT NULL COMMENT '过期时间',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_uid` (`cuId`) USING BTREE COMMENT 'uid唯一索引'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='云通讯账户表';

-- ----------------------------
-- Records of cloud_communication
-- ----------------------------
INSERT INTO `cloud_communication` VALUES ('1', '118814', 'AD_118814', '1', '爱读5112', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', '0', 'eJw1z8FygjAUheF3YWtHExNo2h1iq4EKtIADqwyYgGmVMmloFcd3lzK4-f7FufdixG-RNG8ayVmuGVLceDaA8TCwODVSCZaXWqiekQXuRXJRa1nKwe0lg5AQiMf4I6teNy*ZQ98doskMBPGCeM6k*PjlBw8lCiFRemu6jOEkRl1hr2Zt9-hH9zb160PmJ0EaheetG1Wtj50gO1ruK*UlSUJNVGQW6addbO5j-IsN5-eTEAMALYAwGqOWR-HvpkmeTIDhfPR8t-tua830uRHDv9cbBaVOSA__', '2019-05-27 18:44:53', '2019-05-27 15:50:52');

-- ----------------------------
-- Table structure for `communication_message`
-- ----------------------------
DROP TABLE IF EXISTS `communication_message`;
CREATE TABLE `communication_message` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `fromIdentifier` varchar(100) DEFAULT NULL COMMENT '发送方',
  `toIdentifier` varchar(100) DEFAULT NULL COMMENT '接收方',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `content` text COMMENT '内容',
  `fileType` varchar(50) DEFAULT NULL COMMENT '文件类型（picture：图片；video：视频）',
  `fileUrl` varchar(255) DEFAULT NULL COMMENT '文件路径',
  `jumpType` varchar(50) DEFAULT NULL COMMENT '跳转类型（(page,url)）',
  `directionPath` varchar(255) DEFAULT NULL COMMENT '跳转地址',
  `msgType` tinyint(2) DEFAULT '0' COMMENT '消息类型（0：群发：1：单聊）',
  `gender` tinyint(2) DEFAULT NULL COMMENT '性别（1：男；2：女）',
  `timing` tinyint(2) DEFAULT NULL COMMENT '是否定时',
  `sendTime` datetime DEFAULT NULL COMMENT '发送时间',
  `sendStatus` tinyint(2) DEFAULT '0' COMMENT '发送状态（0：未发送；1：已发送；2：撤销）',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `createUid` int(11) DEFAULT NULL COMMENT '创捷人id',
  `createName` varchar(255) DEFAULT NULL COMMENT '创捷人名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of communication_message
-- ----------------------------
INSERT INTO `communication_message` VALUES ('1', 'ADMGR_1', null, '呵呵呵呵呵呵', '呵呵呵呵呵呵', '', '', '', '', '0', null, '0', null, '2', '2019-05-22 17:10:34', '1', 'admin');
INSERT INTO `communication_message` VALUES ('2', 'ADMGR_1', null, '呵呵呵呵呵呵', '呵呵呵呵呵呵', '', '', '', '', '0', null, '1', '2019-05-22 17:25:12', '2', '2019-05-22 17:25:16', '1', 'admin');
INSERT INTO `communication_message` VALUES ('3', 'ADMGR_1', '1', '嘿嘿嘿哈哈哈呵呵呵呵', '嘿嘿嘿哈哈哈呵呵呵呵', '', '', '', '', '1', null, '0', '2019-05-22 18:37:07', '1', '2019-05-22 18:37:07', '1', 'admin');
INSERT INTO `communication_message` VALUES ('4', 'ADMGR_1', '123', '单聊推送', '单聊推送', '', '', '', '', '1', null, '0', null, '0', '2019-05-23 09:54:44', '1', 'admin');
INSERT INTO `communication_message` VALUES ('5', 'ADMGR_1', '212323', '单聊推送', '单聊推送', '', '', '', '', '1', null, '0', null, '0', '2019-05-23 10:05:10', '1', 'admin');

-- ----------------------------
-- Table structure for `communication_mrg_acount`
-- ----------------------------
DROP TABLE IF EXISTS `communication_mrg_acount`;
CREATE TABLE `communication_mrg_acount` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `identifier` varchar(255) DEFAULT NULL COMMENT '用户名',
  `nick` varchar(50) DEFAULT NULL COMMENT '昵称',
  `type` tinyint(2) DEFAULT NULL COMMENT '类型（开发者默认无需填写，值 0 表示普通帐号，1 表示机器人帐号）',
  `faceUrl` varchar(255) DEFAULT NULL COMMENT '头像',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态（0：停用；1：启用）',
  `createDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_idx` (`identifier`) USING BTREE COMMENT '管理账户唯一索引'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='云通信管理账户';

-- ----------------------------
-- Records of communication_mrg_acount
-- ----------------------------
INSERT INTO `communication_mrg_acount` VALUES ('1', 'ADMGR_1', '爱读小助手', '0', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/communicate/d35178c3-731a-4d71-bba1-0e8cedc2b8e0-1558515725944.jpg', '1', '2019-05-22 17:02:19');
INSERT INTO `communication_mrg_acount` VALUES ('2', 'ADMGR_2', 'test1', '0', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/communicate/b3c1e1c3-8b16-4a43-99e7-3c1d93e5c332-1558515960895.jpg', '1', '2019-05-22 17:06:20');

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `cuId` bigint(20) NOT NULL AUTO_INCREMENT,
  `nickName` varchar(255) DEFAULT NULL,
  `cuName` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `avatar` mediumtext,
  `source` varchar(32) DEFAULT NULL COMMENT 'IOS, Android, H5',
  `sex` int(2) DEFAULT '3' COMMENT '1:男  2:女  3:未知',
  `imei` varchar(255) DEFAULT NULL,
  `regDate` datetime DEFAULT NULL COMMENT '注册时间',
  `bindSource` tinyint(3) DEFAULT '0' COMMENT '绑定来源：1：代表电话；2：代表微信；4：代表qq；3：代表1+2...',
  `bindPhone` varchar(30) DEFAULT NULL COMMENT '绑定手机号',
  `bindOpenid` varchar(255) DEFAULT NULL COMMENT '微信绑定OpenID',
  `bindQq` varchar(50) DEFAULT NULL COMMENT '绑定QQ',
  `registChannel` varchar(16) DEFAULT NULL COMMENT '渠道',
  `phoneModel` varchar(255) DEFAULT NULL COMMENT '手机型号',
  `userType` varchar(16) DEFAULT NULL COMMENT '用户类型（visitor:游客  |  register: 注册用户）',
  `userStatus` varchar(16) NOT NULL DEFAULT 'normal' COMMENT '用户状态（ frozen:封号 | frozenByImei:封设备  | drawdown:账户注销  | normal:正常 ）\n',
  `regVersion` varchar(32) DEFAULT NULL,
  `address` varchar(512) DEFAULT NULL,
  `vipFlag` varchar(16) DEFAULT NULL COMMENT '会员状态（vip：会员 | notvip: 非会员）',
  `vipStartDate` datetime DEFAULT NULL,
  `vipEndDate` datetime DEFAULT NULL,
  `invitationCode` varchar(20) DEFAULT NULL COMMENT '邀请码',
  PRIMARY KEY (`cuId`),
  UNIQUE KEY `index_username_imei` (`imei`,`nickName`,`cuName`,`bindPhone`) USING BTREE,
  KEY `index_NAME` (`nickName`) USING BTREE,
  KEY `IDX_UU_BP` (`bindPhone`),
  KEY `IDX_UU_BQ` (`bindQq`),
  KEY `IDX_UU_BO` (`bindOpenid`),
  KEY `index_invitationCode` (`invitationCode`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=118895 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('112233', 'hello', '书童_test', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/1b8480f2-e02d-4171-98be-6a57ce63ef4a-1559526425718.jpg', 'IOS', '3', '1111', '2019-04-30 17:04:30', '0', '123', null, null, '100', null, 'register', 'normal', null, null, null, null, null, '6X6GK6');
INSERT INTO `customer` VALUES ('118812', 'JordanCZ', null, null, 'http://thirdwx.qlogo.cn/mmopen/vi_32/nHTeBrP98wwKs8v7cWRWZwGscRuIGicRB7M7xIEWs9ibs9LHwn779tExsKVcmSjAGGe97JPIJjnqIbXvxFh780zg/132', 'IOS', '1', '95769113a5af676c015a14c6c3f4cdca', '2019-05-09 15:58:51', '0', null, 'oSIh_1c8Zh0waWcGxRuTCv_tai4M', null, '200', null, 'register', 'normal', null, 'IS', null, null, null, null);
INSERT INTO `customer` VALUES ('118814', 'yang', '13622375112', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/df9b7013-a8a1-4c3c-8090-abc4c59429ac-1559529233514.jpg', 'IOS', '1', '95769113a5af676c015a14c6c3f4cdca', '2019-05-30 16:21:04', '0', '13622375112', null, null, '200', null, 'register', 'normal', null, null, null, null, null, '2UZ5P5');
INSERT INTO `customer` VALUES ('118815', '爱读8421', '18588268421', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', null, '2019-05-10 18:00:47', '0', '18588268421', null, null, null, null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118816', '爱读3737', '13737373737', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-13 14:30:24', '0', '13737373737', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118817', '游客_95769113a5af676c015a14c6c3f4cdca', '游客_95769113a5af676c015a14c6c3f4cdca', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '95769113a5af676c015a14c6c3f4cdca', '2019-05-13 15:34:43', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118818', '爱读6842', '18588826842', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-13 16:21:12', '0', '18588826842', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118819', '游客_da44c83b700ec06fba23f3c2c3aede25', '游客_da44c83b700ec06fba23f3c2c3aede25', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', 'da44c83b700ec06fba23f3c2c3aede25', '2019-05-13 16:23:14', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118822', '爱读6767', '13767676767', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-14 17:25:43', '0', '13767676767', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118823', '爱读3733', '13437373733', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-14 17:31:59', '0', '13437373733', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118827', '游客_ccbb', '游客_ccbb', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'ios', '3', 'ccbb', '2019-05-14 17:55:50', '0', null, null, null, 'sdfd', null, 'visitor', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118829', '爱读4569', '12536544569', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'ios', '3', 'ios', '2019-05-14 18:17:58', '0', '12536544569', null, null, 'ios', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118831', '游客_ios', '游客_ios', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', 'ios', '2019-05-14 19:05:06', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118832', '游客_320036cae0322132bb0ed44bf2f6d435', '游客_320036cae0322132bb0ed44bf2f6d435', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '320036cae0322132bb0ed44bf2f6d435', '2019-05-15 11:32:15', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, 'TRK1V5');
INSERT INTO `customer` VALUES ('118834', '爱读3888', '13838383888', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-15 15:31:35', '0', '13838383888', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118835', '爱读4343', '13434334343', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-15 17:11:45', '0', '13434334343', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118836', '爱读7373', '13737337373', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-15 20:41:57', '0', '13737337373', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118837', '游客_47dede945ca5e8c79decb6e056863acd', '游客_47dede945ca5e8c79decb6e056863acd', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '47dede945ca5e8c79decb6e056863acd', '2019-05-16 10:03:26', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, '46PLSK');
INSERT INTO `customer` VALUES ('118838', '游客_ee1fdf3e7e0397abe699459950a3efd8', '游客_ee1fdf3e7e0397abe699459950a3efd8', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', 'ee1fdf3e7e0397abe699459950a3efd8', '2019-05-16 10:03:43', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, 'F3124S');
INSERT INTO `customer` VALUES ('118839', '游客_2371752eade39794791dd11ae157c82d', '游客_2371752eade39794791dd11ae157c82d', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '2371752eade39794791dd11ae157c82d', '2019-05-16 10:03:49', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, '6LC134');
INSERT INTO `customer` VALUES ('118840', '小灰灰?', null, null, 'http://thirdwx.qlogo.cn/mmopen/vi_32/FLJE6pjYqYeP6o0sq2goLTdYf2KFA2LKZFQbc3icLRBYze2wyMo8lRWiaJXT1dOkia2OHeKAmPYQkWiaDMeJmJHBgA/132', 'IOS', '2', '47dede945ca5e8c79decb6e056863acd', '2019-05-16 10:10:01', '0', null, 'oSIh_1f4OeVCnbQOaQEYJ_f_xmPs', null, '200', null, 'register', 'normal', null, 'UM', null, null, null, null);
INSERT INTO `customer` VALUES ('118841', '爱读7832', '18290017832', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '320036cae0322132bb0ed44bf2f6d435', '2019-05-16 10:30:07', '0', '18290017832', null, null, '200', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118844', '爱读6044', '13291826044', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '47dede945ca5e8c79decb6e056863acd', '2019-05-16 17:32:40', '0', '13291826044', null, null, '200', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118845', '爱读0251', '15012680251', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '320036cae0322132bb0ed44bf2f6d435', '2019-05-16 18:44:04', '0', '15012680251', null, null, '200', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118846', '爱读3343', '13434343343', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '869066034936857', '2019-05-18 10:32:11', '0', '13434343343', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118848', '爱读2312', '18269352312', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-20 14:58:44', '0', '18269352312', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118849', '游客_f78322dade9fcf2aa661e4f541936e3a', '游客_f78322dade9fcf2aa661e4f541936e3a', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', 'f78322dade9fcf2aa661e4f541936e3a', '2019-05-20 17:43:21', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118850', '爱读2356', '18696352356', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-20 18:46:45', '0', '18696352356', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118851', '爱读5678', '13012345678', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '869066034936857', '2019-05-21 10:53:56', '0', '13012345678', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, '1E5YQV');
INSERT INTO `customer` VALUES ('118852', '爱读5119', '13622375119', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '320036cae0322132bb0ed44bf2f6d435', '2019-05-23 10:47:20', '0', '13622375119', null, null, '300', null, 'register', 'normal', null, null, null, null, null, '21ITQB');
INSERT INTO `customer` VALUES ('118853', '爱读1233', '18098901233', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '47dede945ca5e8c79decb6e056863acd', '2019-05-23 16:39:12', '0', '18098901233', null, null, '300', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118854', '游客_b963f659e69057178e999a64e2320520', '游客_b963f659e69057178e999a64e2320520', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', 'b963f659e69057178e999a64e2320520', '2019-05-23 18:28:44', '0', null, null, null, '300', null, 'visitor', 'normal', null, null, null, null, null, '6KD8WY');
INSERT INTO `customer` VALUES ('118855', '爱读2585', '13636362585', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', 'ee1fdf3e7e0397abe699459950a3efd8', '2019-05-24 09:56:20', '0', '13636362585', null, null, '300', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118856', '爱读1111', '12536541111', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'ios', '3', 'ios', '2019-05-14 11:19:52', '0', '12536541111', null, null, 'ios', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118857', '爱读3333', '18269693333', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-24 16:34:58', '0', '18269693333', null, null, 'test', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118858', '游客_862400040867458', '游客_862400040867458', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '862400040867458', '2019-05-25 15:38:02', '0', null, null, null, '100', null, 'visitor', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118859', '爱读1111', '13011111111', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '862400040867458', '2019-05-25 15:39:06', '0', '13011111111', null, null, '100', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118860', '爱读6985', '18263636985', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', null, '2019-05-25 17:46:30', '0', '18263636985', null, null, '200', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118861', '爱读2222', '12536542222', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'ios', '3', 'ios', '2019-05-27 09:55:23', '0', '12536542222', null, null, 'ios', null, 'register', 'normal', null, null, null, null, null, 'MH7C4G');
INSERT INTO `customer` VALUES ('118862', '游客_', '游客_', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-27 10:23:16', '0', null, null, null, '100', null, 'visitor', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118863', '爱读3333', '15669693333', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '', '2019-05-27 10:24:40', '0', '15669693333', null, null, '100', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118864', '爱读5555', '12536545555', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'ios', '3', 'ios', '2019-05-27 16:01:44', '0', '12536545555', null, null, 'ios', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118865', '爱读3636', '13737363636', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '320036cae0322132bb0ed44bf2f6d435', '2019-05-27 16:55:54', '0', '13737363636', null, null, '200', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118866', '爱读5656', '13736365656', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '320036cae0322132bb0ed44bf2f6d435', '2019-05-27 17:02:22', '0', '13736365656', null, null, '200', null, 'register', 'normal', null, null, null, null, null, '8V4C19');
INSERT INTO `customer` VALUES ('118867', '游客_869066034936857', '游客_869066034936857', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '869066034936857', '2019-05-27 17:15:25', '0', null, null, null, '100', null, 'visitor', 'normal', null, null, null, null, null, '8EK1LH');
INSERT INTO `customer` VALUES ('118868', '爱读9999', '18299999999', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'ios', '3', 'ios', '2019-05-27 17:39:15', '0', '18299999999', null, null, 'ios', null, 'register', 'normal', null, null, null, null, null, '8EZN2Z');
INSERT INTO `customer` VALUES ('118869', '落', null, null, 'http://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83eovLtFRmict7mj5xSYe2SIEsfvL40Hia0pr2KAO2k2dCMkepD5ne2n3J4gib8eZNOs07crekcsBcicbjA/132', 'Android', '1', '869066034936857', '2019-05-27 18:56:18', '0', null, 'oSIh_1THYeC4RR4Bhp84RyD3CTUQ', null, '100', null, 'register', 'normal', null, 'CNFujianNingde', null, null, null, 'K5BJDS');
INSERT INTO `customer` VALUES ('118870', '爱读9999', '18899999999', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'ios', '3', 'ios', '2019-05-28 10:20:46', '0', '18899999999', null, null, 'ios', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118871', '爱读5632', '12323235632', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '868362034086350', '2019-05-28 11:50:56', '0', '12323235632', null, null, '100', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118872', '爱读2323', '13622372323', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '320036cae0322132bb0ed44bf2f6d435', '2019-05-28 11:51:32', '0', '13622372323', null, null, '200', null, 'register', 'normal', null, null, null, null, null, 'W8PZI7');
INSERT INTO `customer` VALUES ('118873', '游客_868585040788177', '游客_868585040788177', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '868585040788177', '2019-05-28 16:27:22', '0', null, null, null, '100', null, 'visitor', 'normal', null, null, null, null, null, 'BDT8Z2');
INSERT INTO `customer` VALUES ('118874', '游客_c32e1a4adc2bcd78d7e8136def791984', '游客_c32e1a4adc2bcd78d7e8136def791984', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', 'c32e1a4adc2bcd78d7e8136def791984', '2019-05-28 20:20:33', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, '1KC2RE');
INSERT INTO `customer` VALUES ('118875', '游客_956340fcb5cde5376614a6bed9a13506', '游客_956340fcb5cde5376614a6bed9a13506', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '956340fcb5cde5376614a6bed9a13506', '2019-05-29 09:28:06', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, '54QK8Y');
INSERT INTO `customer` VALUES ('118876', '游客_868362034086350', '游客_868362034086350', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '868362034086350', '2019-05-29 14:43:46', '0', null, null, null, '100', null, 'visitor', 'normal', null, null, null, null, null, 'M9GC86');
INSERT INTO `customer` VALUES ('118877', '爱读5122', '13622375122', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '956340fcb5cde5376614a6bed9a13506', '2019-05-29 15:01:17', '0', '13622375122', null, null, '200', null, 'register', 'normal', null, null, null, null, null, 'T4188K');
INSERT INTO `customer` VALUES ('118878', '爱读6363', '12323266363', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '868362034086350', '2019-05-29 15:59:02', '0', '12323266363', null, null, '100', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118879', '爱读3333', '12323233333', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '868362034086350', '2019-05-29 17:48:29', '0', '12323233333', null, null, '100', null, 'register', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118881', '爱读1458', '13585221458', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '867302023485909', '2019-05-30 09:49:32', '0', '13585221458', null, null, '100', null, 'register', 'normal', null, null, null, null, null, 'YP4FMN');
INSERT INTO `customer` VALUES ('118885', '爱读3026', '13076963026', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '869066034936857', '2019-05-30 12:50:56', '0', '13076963026', null, null, '100', null, 'register', 'normal', null, null, null, null, null, '2279EI');
INSERT INTO `customer` VALUES ('118886', '爱读1225', '18055521225', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '47dede945ca5e8c79decb6e056863acd', '2019-05-30 13:32:56', '0', '18055521225', null, null, '200', null, 'register', 'normal', null, null, null, null, null, 'FEYRZ0');
INSERT INTO `customer` VALUES ('118887', '爱读8888', '18288888888', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '868362034086350', '2019-05-30 14:52:42', '0', '18288888888', null, null, '100', null, 'register', 'normal', null, null, null, null, null, 'XRBRX1');
INSERT INTO `customer` VALUES ('118888', '爱读5118', '13622375118', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '47dede945ca5e8c79decb6e056863acd', '2019-05-26 16:37:06', '0', '13622375118', null, null, '200', null, 'register', 'normal', null, null, null, null, null, 'Q467ZT');
INSERT INTO `customer` VALUES ('118889', '爱读2323', '12323232323', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '868362034086350', '2019-05-30 16:40:11', '0', '12323232323', null, null, '100', null, 'register', 'normal', null, null, null, null, null, '4IM47P');
INSERT INTO `customer` VALUES ('118890', '游客_6dd6f50d87774896633c2a75340ceb0a', '游客_6dd6f50d87774896633c2a75340ceb0a', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'IOS', '3', '6dd6f50d87774896633c2a75340ceb0a', '2019-05-31 10:09:04', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118891', '游客_867302023485909', '游客_867302023485909', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '867302023485909', '2019-05-31 16:17:17', '0', null, null, null, '100', null, 'visitor', 'normal', null, null, null, null, null, '5S4V19');
INSERT INTO `customer` VALUES ('118892', '爱读7554', '18099917554', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '868585040788177', '2019-05-31 16:34:57', '0', '18099917554', null, null, '100', null, 'register', 'normal', null, null, null, null, null, 'Q4Z753');
INSERT INTO `customer` VALUES ('118893', '游客_12455698875', '游客_12455698875', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'ios', '3', '12455698875', '2019-05-31 17:13:03', '0', null, null, null, '200', null, 'visitor', 'normal', null, null, null, null, null, null);
INSERT INTO `customer` VALUES ('118894', '爱读8756', '12345688756', null, 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/head/default.png', 'Android', '3', '868362034086350', '2019-05-31 17:16:37', '0', '12345688756', null, null, '100', null, 'register', 'normal', null, null, null, null, null, null);

-- ----------------------------
-- Table structure for `customer_account`
-- ----------------------------
DROP TABLE IF EXISTS `customer_account`;
CREATE TABLE `customer_account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL COMMENT '用户id',
  `rmb` bigint(20) DEFAULT '0' COMMENT '现金',
  `gold` bigint(20) DEFAULT '0' COMMENT '金币',
  `rmbTotal` bigint(20) DEFAULT '0' COMMENT '人民币总额',
  `changed` tinyint(2) DEFAULT '0' COMMENT '是否变更(0：未变更；1：已变更）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COMMENT='用户账户';

-- ----------------------------
-- Records of customer_account
-- ----------------------------
INSERT INTO `customer_account` VALUES ('1', '112233', '702', '10454', '702', '1');
INSERT INTO `customer_account` VALUES ('2', '118795', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('3', '118796', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('4', '118799', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('5', '118800', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('6', '118801', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('7', '118805', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('8', '118806', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('9', '118807', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('10', '118809', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('11', '118810', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('12', '118811', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('13', '118812', '146', '10000', '146', '1');
INSERT INTO `customer_account` VALUES ('14', '118813', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('15', '118814', '10200', '21888', '10200', '1');
INSERT INTO `customer_account` VALUES ('16', '118815', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('18', '118818', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('19', '118819', '0', '1064', '0', '1');
INSERT INTO `customer_account` VALUES ('20', '118821', '395', '10000', '395', '1');
INSERT INTO `customer_account` VALUES ('21', '118829', '238', '9974', '238', '1');
INSERT INTO `customer_account` VALUES ('28', '118828', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('29', '118830', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('30', '118834', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('31', '118835', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('32', '118836', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('33', '118840', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('34', '118841', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('35', '118842', '0', '100', '0', '1');
INSERT INTO `customer_account` VALUES ('37', '118844', '0', '206', '0', '1');
INSERT INTO `customer_account` VALUES ('38', '118845', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('39', '118846', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('40', '118847', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('41', '118848', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('42', '118850', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('43', '118851', '0', '2445', '0', '1');
INSERT INTO `customer_account` VALUES ('44', '118852', '0', '612', '0', '1');
INSERT INTO `customer_account` VALUES ('45', '118853', '0', '100', '0', '1');
INSERT INTO `customer_account` VALUES ('46', '118855', '0', '100', '0', '1');
INSERT INTO `customer_account` VALUES ('47', '118856', '0', '14150', '0', '1');
INSERT INTO `customer_account` VALUES ('48', '118857', '0', '315', '0', '1');
INSERT INTO `customer_account` VALUES ('49', '118859', '0', '952', '0', '1');
INSERT INTO `customer_account` VALUES ('50', '118860', '0', '277', '0', '1');
INSERT INTO `customer_account` VALUES ('53', '118861', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('54', '118863', '0', '253', '0', '1');
INSERT INTO `customer_account` VALUES ('55', '118832', '0', '290', '0', '1');
INSERT INTO `customer_account` VALUES ('56', '118864', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('57', '118854', '0', '110', '0', '1');
INSERT INTO `customer_account` VALUES ('58', '118865', '0', '100', '0', '1');
INSERT INTO `customer_account` VALUES ('59', '118866', '0', '200', '0', '1');
INSERT INTO `customer_account` VALUES ('60', '118837', '0', '200', '0', '1');
INSERT INTO `customer_account` VALUES ('61', '118867', '0', '100', '0', '1');
INSERT INTO `customer_account` VALUES ('62', '118868', '1000', '0', '1000', '0');
INSERT INTO `customer_account` VALUES ('63', '118869', '0', '8129', '0', '1');
INSERT INTO `customer_account` VALUES ('64', '118870', '1000', '28', '26', '0');
INSERT INTO `customer_account` VALUES ('65', '118871', '0', '1421', '0', '1');
INSERT INTO `customer_account` VALUES ('66', '118872', '0', '100', '0', '1');
INSERT INTO `customer_account` VALUES ('67', '118873', '0', '110', '0', '1');
INSERT INTO `customer_account` VALUES ('68', '118877', '0', '100', '0', '1');
INSERT INTO `customer_account` VALUES ('69', '118878', '0', '201', '0', '0');
INSERT INTO `customer_account` VALUES ('70', '118879', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('71', '118838', '0', '100', '0', '1');
INSERT INTO `customer_account` VALUES ('72', '118875', '0', '100', '0', '1');
INSERT INTO `customer_account` VALUES ('73', '118881', '0', '1074', '0', '1');
INSERT INTO `customer_account` VALUES ('74', '118882', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('75', '118883', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('76', '118884', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('77', '118839', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('78', '118885', '0', '3782', '0', '1');
INSERT INTO `customer_account` VALUES ('79', '118886', '0', '150', '0', '1');
INSERT INTO `customer_account` VALUES ('80', '118887', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('81', '1', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('82', '14185118814', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('83', '118888', '0', '862', '0', '1');
INSERT INTO `customer_account` VALUES ('84', '118889', '0', '1060', '0', '0');
INSERT INTO `customer_account` VALUES ('85', '118874', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('86', '0', '0', '100', '0', '1');
INSERT INTO `customer_account` VALUES ('87', '118876', '0', '150', '0', '1');
INSERT INTO `customer_account` VALUES ('88', '118892', '0', '933', '0', '1');
INSERT INTO `customer_account` VALUES ('89', '118891', '0', '0', '0', '0');
INSERT INTO `customer_account` VALUES ('90', '118894', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `customer_biz`
-- ----------------------------
DROP TABLE IF EXISTS `customer_biz`;
CREATE TABLE `customer_biz` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cuId` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `freeAdvTime` datetime DEFAULT NULL COMMENT '看视频免广告-截止时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer_biz
-- ----------------------------
INSERT INTO `customer_biz` VALUES ('2', '112233', '2019-05-15 14:54:14');
INSERT INTO `customer_biz` VALUES ('3', '118834', null);
INSERT INTO `customer_biz` VALUES ('4', '118835', '2019-05-15 18:53:07');
INSERT INTO `customer_biz` VALUES ('5', '118836', null);
INSERT INTO `customer_biz` VALUES ('6', '118840', '2019-05-23 16:07:58');
INSERT INTO `customer_biz` VALUES ('7', '118841', null);
INSERT INTO `customer_biz` VALUES ('8', '118842', '2019-05-16 16:15:05');
INSERT INTO `customer_biz` VALUES ('9', '118844', null);
INSERT INTO `customer_biz` VALUES ('10', '118845', null);
INSERT INTO `customer_biz` VALUES ('11', '118846', '2019-05-18 13:23:31');
INSERT INTO `customer_biz` VALUES ('12', '118847', null);
INSERT INTO `customer_biz` VALUES ('13', '118848', null);
INSERT INTO `customer_biz` VALUES ('14', '118850', null);
INSERT INTO `customer_biz` VALUES ('15', '118851', '2019-05-23 19:57:59');
INSERT INTO `customer_biz` VALUES ('16', '118852', '2019-05-23 15:43:57');
INSERT INTO `customer_biz` VALUES ('17', '118853', null);
INSERT INTO `customer_biz` VALUES ('18', '118855', null);
INSERT INTO `customer_biz` VALUES ('19', '118856', '2019-05-31 16:59:42');
INSERT INTO `customer_biz` VALUES ('20', '118857', null);
INSERT INTO `customer_biz` VALUES ('21', '118859', null);
INSERT INTO `customer_biz` VALUES ('22', '118860', '2019-05-25 20:26:02');
INSERT INTO `customer_biz` VALUES ('23', '118861', '2019-05-27 12:04:41');
INSERT INTO `customer_biz` VALUES ('24', '118863', null);
INSERT INTO `customer_biz` VALUES ('25', '118864', null);
INSERT INTO `customer_biz` VALUES ('26', '118865', null);
INSERT INTO `customer_biz` VALUES ('27', '118866', '2019-05-27 18:24:26');
INSERT INTO `customer_biz` VALUES ('28', '118868', '2019-05-31 16:56:07');
INSERT INTO `customer_biz` VALUES ('29', '118869', null);
INSERT INTO `customer_biz` VALUES ('30', '118870', null);
INSERT INTO `customer_biz` VALUES ('31', '118871', null);
INSERT INTO `customer_biz` VALUES ('32', '118872', null);
INSERT INTO `customer_biz` VALUES ('33', '118877', null);
INSERT INTO `customer_biz` VALUES ('34', '118878', null);
INSERT INTO `customer_biz` VALUES ('35', '118879', null);
INSERT INTO `customer_biz` VALUES ('36', '118881', null);
INSERT INTO `customer_biz` VALUES ('37', '118882', null);
INSERT INTO `customer_biz` VALUES ('38', '118883', null);
INSERT INTO `customer_biz` VALUES ('39', '118884', null);
INSERT INTO `customer_biz` VALUES ('40', '118885', null);
INSERT INTO `customer_biz` VALUES ('41', '118886', '2019-05-30 13:55:48');
INSERT INTO `customer_biz` VALUES ('42', '118887', null);
INSERT INTO `customer_biz` VALUES ('43', '118888', '2019-05-30 17:03:41');
INSERT INTO `customer_biz` VALUES ('44', '118889', null);
INSERT INTO `customer_biz` VALUES ('45', '118892', null);
INSERT INTO `customer_biz` VALUES ('46', '118894', null);

-- ----------------------------
-- Table structure for `exchange_goods`
-- ----------------------------
DROP TABLE IF EXISTS `exchange_goods`;
CREATE TABLE `exchange_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(20) DEFAULT NULL COMMENT '名称',
  `marker` varchar(255) DEFAULT NULL COMMENT '标记',
  `exchangeType` varchar(255) DEFAULT 'gold' COMMENT '兑换类型（gold:金豆 | rmb:人民币）',
  `requirement` varchar(255) DEFAULT 'all' COMMENT '条件（VIP:会员 | readTime| all:所有）',
  `requirementNumber` int(11) DEFAULT NULL COMMENT '条件数量',
  `cost` int(11) DEFAULT '0' COMMENT '费用',
  `status` tinyint(2) DEFAULT '0' COMMENT '状态（0：下架 | 1:上架）',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `sort` int(11) DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='兑换商品';

-- ----------------------------
-- Records of exchange_goods
-- ----------------------------
INSERT INTO `exchange_goods` VALUES ('1', null, null, 'gold', 'all', null, '0', '0', '2019-05-27 17:01:20', '2019-05-27 17:01:20', '0');
INSERT INTO `exchange_goods` VALUES ('2', null, null, 'gold', 'all', null, '0', '0', '2019-05-27 17:04:01', '2019-05-27 17:04:01', '0');
INSERT INTO `exchange_goods` VALUES ('3', null, null, 'gold', 'all', null, '0', '0', '2019-05-27 17:06:57', '2019-05-27 17:06:57', '0');
INSERT INTO `exchange_goods` VALUES ('4', '礼品1', '角标', 'rmb', 'readTime', '189', '10', '1', '2019-05-27 17:07:48', '2019-05-27 17:13:50', '0');
INSERT INTO `exchange_goods` VALUES ('5', '礼品1', '角标', 'gold', 'VIP', '0', '10', '1', '2019-05-27 17:08:51', '2019-05-27 17:08:51', '0');
INSERT INTO `exchange_goods` VALUES ('6', '礼品1', '角标', 'gold', 'VIP', '189', '10', '1', '2019-05-27 17:09:48', '2019-05-27 17:09:48', '0');
INSERT INTO `exchange_goods` VALUES ('7', '礼品1', '角标', 'gold', 'VIP', '189', '10', '1', '2019-05-27 17:09:54', '2019-05-27 17:09:54', '0');
INSERT INTO `exchange_goods` VALUES ('8', '礼品1', '角标', 'rmb', 'readTime', '1', '10', '1', '2019-05-27 17:13:50', '2019-05-27 17:14:52', '0');
INSERT INTO `exchange_goods` VALUES ('9', '礼品1', '角标', 'rmb', 'readTime', '1', '10', '1', '2019-05-27 17:14:52', '2019-05-27 17:14:52', '0');
INSERT INTO `exchange_goods` VALUES ('10', '礼品3', '', 'rmb', 'readTime', '8', '34', '0', '2019-05-27 17:15:58', '2019-05-27 17:17:51', '0');
INSERT INTO `exchange_goods` VALUES ('11', '兑换1元', '新人专享', 'gold', 'readTime', '40', '10000', '1', '2019-05-27 17:16:16', '2019-05-31 17:41:25', '0');
INSERT INTO `exchange_goods` VALUES ('12', '礼品3', '', 'rmb', 'readTime', '8', '34', '0', '2019-05-27 17:17:51', '2019-05-27 17:17:51', '0');
INSERT INTO `exchange_goods` VALUES ('13', '礼品3', '', 'rmb', 'readTime', '8', '34', '1', '2019-05-27 17:19:32', '2019-05-27 17:19:32', '0');

-- ----------------------------
-- Table structure for `exchange_order`
-- ----------------------------
DROP TABLE IF EXISTS `exchange_order`;
CREATE TABLE `exchange_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cuId` bigint(20) NOT NULL COMMENT '用户id',
  `orderNo` varchar(28) NOT NULL COMMENT '订单号',
  `goodsName` varchar(11) NOT NULL COMMENT '礼品名称',
  `exchangeType` varchar(255) DEFAULT NULL COMMENT '礼品类型（gold:金豆 | rmb:人民币）',
  `cost` int(11) DEFAULT '0' COMMENT '消耗量',
  `auditTime` datetime DEFAULT NULL COMMENT '审核时间',
  `orderStatus` tinyint(2) DEFAULT '0' COMMENT '订单状态(0：审核中 | 1：审核成功 | 2：审核失败 | 3：微信发送处理中 | 4：红包发送成功 | 5：红包发送失败 ）',
  `remark` text,
  `noDeduction` bigint(20) DEFAULT NULL COMMENT '扣除前余额',
  `deductioned` bigint(20) DEFAULT NULL COMMENT '扣除后余额',
  `createTime` datetime DEFAULT NULL,
  `rmbAmount` int(11) DEFAULT NULL COMMENT '人民币金额',
  `auditorId` int(11) DEFAULT NULL COMMENT '审核人',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cuId_orderNo` (`cuId`,`orderNo`) USING BTREE,
  UNIQUE KEY `uq_orderNo` (`orderNo`),
  KEY `index_cuId` (`cuId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='兑换订单';

-- ----------------------------
-- Records of exchange_order
-- ----------------------------

-- ----------------------------
-- Table structure for `faq`
-- ----------------------------
DROP TABLE IF EXISTS `faq`;
CREATE TABLE `faq` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `createUid` int(11) DEFAULT NULL COMMENT '创建人ID',
  `logo` varchar(255) DEFAULT NULL COMMENT '创建人logo',
  `question` varchar(255) DEFAULT NULL COMMENT '问题',
  `answer` varchar(255) DEFAULT NULL COMMENT '回答',
  `orderNo` int(11) DEFAULT NULL COMMENT '排序号',
  `createTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updateTime` datetime DEFAULT NULL COMMENT '更新时间',
  `status` tinyint(2) DEFAULT '0' COMMENT '状态：0：无效；1有效',
  `channle` varchar(20) DEFAULT '-1' COMMENT '渠道（-1：全部）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of faq
-- ----------------------------
INSERT INTO `faq` VALUES ('59', '1', null, 'test01', 'ok', '1', '2019-05-22 13:47:24', '2019-05-22 13:47:24', '0', '-1');
INSERT INTO `faq` VALUES ('63', '1', null, '小说全部都是免费的吗？', '爱读免费小说提供的全部高质量小说都可以免费阅读，我们承担了所有的版权费用。', '0', '2019-05-24 09:38:03', '2019-05-24 09:38:03', '1', '-1');
INSERT INTO `faq` VALUES ('64', '1', null, '金豆是什么？', '金豆是爱读免费小说的虚拟货币，金豆可以兑换现金。', '1', '2019-05-24 09:38:15', '2019-05-24 09:38:15', '1', '-1');
INSERT INTO `faq` VALUES ('65', '1', null, '怎样获取金豆？', '获取金豆的方式有很多：阅读、签到、完成任务，比如绑定手机或微信、每日分享app、参与活动抽奖等都可以获得大量的金豆。', '2', '2019-05-24 09:38:27', '2019-05-24 09:38:27', '1', '-1');
INSERT INTO `faq` VALUES ('66', '1', null, '为什么有时阅读书籍没有金豆？', '正常每天阅读书籍前3小时都可获得金豆奖励，30秒奖励一次，每次最高可获50金豆。如 无网络或阅读本地书籍时是没有金豆奖励哦', '3', '2019-05-24 09:38:41', '2019-05-24 09:38:41', '1', '-1');
INSERT INTO `faq` VALUES ('67', '1', null, '签到怎么获得金豆呢？', '签到奖励分为日常签到、首次签到、连续签到奖励。每天都签到可获得超级丰厚的金豆奖励', '4', '2019-05-24 09:38:56', '2019-05-24 09:38:56', '1', '-1');
INSERT INTO `faq` VALUES ('68', '1', null, '金豆可以送给朋友吗？', '目前金豆是和您账号进行绑定的，暂时不可以赠送给其他人噢。督促朋友和您一起阅读，就可以一起获得丰厚金豆奖励呢。\n', '5', '2019-05-24 09:39:07', '2019-05-24 09:39:07', '1', '-1');
INSERT INTO `faq` VALUES ('69', '1', null, '获取现金红包的方式有哪些呢？', '注册就可以获得新手现金红包奖励噢，另外邀请好友更可以获得大额现金红包。', '6', '2019-05-24 09:39:20', '2019-05-24 09:39:20', '1', '-1');
INSERT INTO `faq` VALUES ('70', '1', null, '提现方式有哪些？多久到账？', '提现方式目前只支持提现到绑定的微信账户中，后续会增加更多途径选择。 提现正常情况下会立即到账，如有异常情况则会转为系统审核，我们会在3个工作日内完成审核。', '7', '2019-05-24 09:39:34', '2019-05-24 09:39:34', '1', '-1');
INSERT INTO `faq` VALUES ('71', '1', null, '为什么提现到微信失败？', '提现到绑定微信账号中需要在微信完成实名认证并绑定银行卡，请先完成微信实名认证后再尝试重新发起提现操作。', '8', '2019-05-24 09:39:47', '2019-05-24 09:39:47', '1', '-1');
INSERT INTO `faq` VALUES ('72', '1', null, '红包码是什么？', '每个用户注册成功后都会有专属自己的唯一红包码。当您朋友注册之后填写了您的红包码，就自动成为您的好友，好友每天看书可以为您贡献金币奖励。\n', '9', '2019-05-24 09:40:00', '2019-05-24 09:40:00', '1', '-1');
INSERT INTO `faq` VALUES ('73', '1', null, '邀请好友奖励怎么获得？', '邀请好友能快速获得现金奖励、活动期间每邀请以为好友即可获得5元现金，好友阅读满一定时间后发放，分3天发放。', '10', '2019-05-24 09:40:16', '2019-05-24 09:40:16', '1', '-1');
INSERT INTO `faq` VALUES ('74', '1', null, '邀请好友有数量上限吗？', '没有！但若发现通过恶意作弊获刷金豆的行为，所有奖励都会被取消噢。同时账户也将可能被停止使用。', '11', '2019-05-24 09:40:33', '2019-05-24 09:40:33', '1', '-1');
INSERT INTO `faq` VALUES ('75', '1', null, '怎样查看我的账户余额？', '进入\"我\",选择“我的钱包”，就能看到您的金豆余额以及红包余额。', '12', '2019-05-24 09:40:47', '2019-05-24 09:40:47', '1', '-1');
INSERT INTO `faq` VALUES ('76', '1', null, '如何开通会员业务？', '进入“我”的页面，选择“会员福利”，点选相应金额完成支付，即可开通会员业务。', '13', '2019-05-24 09:41:00', '2019-05-24 09:41:00', '1', '-1');
INSERT INTO `faq` VALUES ('77', '1', null, '为什么我开通会员没有显示标识和有效时间？', '正常情况下您支付成功后30秒内会自动开通，有时会因为网络延迟导致书币没有及时到账，请您稍后查看或者退出账户重新登录，如超过24小时依旧显示未开通请通过意见反馈与我们联系。', '14', '2019-05-24 09:41:13', '2019-05-24 09:41:13', '1', '-1');
INSERT INTO `faq` VALUES ('78', '1', null, '开通会员包月服务为什么不能免除所有的广告?', '成功开通会员后，在阅读所有书籍时都无任何广告。作为专业的免费小说阅读平台，广告是我们唯一的收入来源，我们从设计之初就巧妙的解决了其余位置出现的广告可能对您使用造成的使用体验', '15', '2019-05-24 09:41:27', '2019-05-24 09:41:27', '1', '-1');
INSERT INTO `faq` VALUES ('79', '1', null, '如何离线下载书籍？', '共有2处可使用离线下载书籍功能\n1：在书架中长按某一本书籍，底部会弹出选择框，点选离线下载即可把免费下载至手机中。\n2：在书籍阅读中，点选右下角图标会弹出离线下载安按钮，点击即可把免费下载至手机中。', '16', '2019-05-24 09:41:42', '2019-05-24 09:41:42', '1', '-1');
INSERT INTO `faq` VALUES ('80', '1', null, '如何设置阅读界面的背景和字体大小？', '在阅读界面，点击屏幕中央，底部会出现工具栏，所有阅读界面的设置都可在此处设置。底部4?个按钮分别为：章节目录、夜间模式、功能设置、下载书籍\n点选第三个按钮可设置不同的阅读背景颜色及亮度调节、阅读字体的大小调节', '17', '2019-05-24 09:41:54', '2019-05-24 09:41:54', '1', '-1');
INSERT INTO `faq` VALUES ('81', '1', null, '如何管理书架中的书籍？', '在书架中长按某一本书籍，底部会弹出选择框，所有操作在这里进行。可以进行移出书架、分享、以及下载书籍。', '18', '2019-05-24 09:42:08', '2019-05-24 09:42:08', '1', '-1');
INSERT INTO `faq` VALUES ('82', '1', null, '为什么有的书籍我无法阅读？', '书籍无法阅读时，请首先检查手机网络是否连接顺畅。当手机网络信号不佳时，会导致图书更新速度变慢，建议耐心等待或稍后重试。\n另外部分书籍可能会因版权方不定时的调整导致无法阅读。', '19', '2019-05-24 09:42:24', '2019-05-24 09:42:24', '1', '-1');
INSERT INTO `faq` VALUES ('83', '1', null, '如何开通会员+业务', '进入“我”的页面，选择会员+，点选相应金额完成支付，即可开通会员+业务。\n开通会员+业务后，每个自然月都可领取高额书币奖励。首次开通可额外再获赠500书币。\n书币需要您在会员+有效期内主动领取，否则会错过权益噢', '20', '2019-05-24 09:42:53', '2019-05-24 09:42:53', '1', '-1');
INSERT INTO `faq` VALUES ('84', '1', null, '如何取消自动续费', '请在微信客户端上登陆当时付款的微信账号，再点击微信 App 中的钱包 → 支付中心（右上角按钮） → 支付管理 → 自动扣费 → 找到【千阅会员微信自动续费】点击停止扣费，然后根据页面提示进行操作关闭即可', '21', '2019-05-24 09:43:08', '2019-05-24 09:43:08', '1', '-1');

-- ----------------------------
-- Table structure for `feedback`
-- ----------------------------
DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `f_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cuId` bigint(20) DEFAULT NULL,
  `content` varchar(512) DEFAULT NULL,
  `contentType` smallint(6) DEFAULT '1' COMMENT '反馈内容类型(1:文本 2:图片)',
  `qq` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COMMENT='用户反馈';

-- ----------------------------
-- Records of feedback
-- ----------------------------
INSERT INTO `feedback` VALUES ('101', '118814', '是是是', '1', null, null, '2019-05-14 13:48:29');
INSERT INTO `feedback` VALUES ('102', '104556', '为什么。。。？', '1', null, null, '2019-05-14 14:37:08');
INSERT INTO `feedback` VALUES ('103', '118814', '你好', '1', null, null, '2019-05-27 16:46:58');
INSERT INTO `feedback` VALUES ('104', '118814', '你好', '1', '', '', '2019-05-29 18:10:54');
INSERT INTO `feedback` VALUES ('105', '118814', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/feedback/40a69123-5cf2-48b2-8c4a-643627f0172f-1559130042762.png', '2', null, null, '2019-05-29 19:41:44');
INSERT INTO `feedback` VALUES ('106', '118885', '发过火', '1', '', '', '2019-05-31 10:45:04');
INSERT INTO `feedback` VALUES ('107', '118885', '发过火', '1', '', '', '2019-05-31 10:46:53');
INSERT INTO `feedback` VALUES ('108', '118885', '发过火', '1', '', '', '2019-05-31 10:46:53');
INSERT INTO `feedback` VALUES ('109', '118885', '大家', '1', '', '', '2019-05-31 11:00:50');
INSERT INTO `feedback` VALUES ('110', '118885', '独具匠心', '1', '', '', '2019-05-31 11:47:19');
INSERT INTO `feedback` VALUES ('111', '118885', '你好', '1', '', '', '2019-05-31 12:33:18');
INSERT INTO `feedback` VALUES ('112', '118885', '哈哈哈', '1', '', '', '2019-05-31 13:37:50');
INSERT INTO `feedback` VALUES ('113', '118885', '小鸡小鸡继续继续就现金继续继续继续继续看辛苦辛苦', '1', '', '', '2019-05-31 14:17:47');
INSERT INTO `feedback` VALUES ('114', '118885', '日本', '1', '', '', '2019-05-31 14:46:03');
INSERT INTO `feedback` VALUES ('115', '118885', '没有回复？', '1', '', '', '2019-05-31 16:00:26');
INSERT INTO `feedback` VALUES ('116', '118876', '你好', '1', '', '', '2019-05-31 17:12:33');
INSERT INTO `feedback` VALUES ('117', '118876', '你好', '1', '', '', '2019-05-31 17:13:51');

-- ----------------------------
-- Table structure for `feedback_reply`
-- ----------------------------
DROP TABLE IF EXISTS `feedback_reply`;
CREATE TABLE `feedback_reply` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `feedbackId` bigint(20) DEFAULT NULL,
  `content` varchar(512) DEFAULT NULL,
  `contentType` smallint(6) DEFAULT '1' COMMENT '反馈内容类型(1:文本 2:图片)',
  `createUid` bigint(20) DEFAULT NULL,
  `createTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='反馈回复';

-- ----------------------------
-- Records of feedback_reply
-- ----------------------------

-- ----------------------------
-- Table structure for `friend`
-- ----------------------------
DROP TABLE IF EXISTS `friend`;
CREATE TABLE `friend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL COMMENT '用户id',
  `fuId` bigint(20) DEFAULT NULL COMMENT '好友uid',
  `createDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_cuId_fuId` (`cuId`,`fuId`) USING BTREE COMMENT '好友关系唯一索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户好友表';

-- ----------------------------
-- Records of friend
-- ----------------------------

-- ----------------------------
-- Table structure for `invitation_record`
-- ----------------------------
DROP TABLE IF EXISTS `invitation_record`;
CREATE TABLE `invitation_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL COMMENT '用户ID',
  `invitedCuid` bigint(20) NOT NULL COMMENT '被邀请人',
  `createTime` datetime DEFAULT NULL,
  `taskStatus` tinyint(2) DEFAULT '0' COMMENT '任务状态（0：未完成任务;1：完成1；2：完成2；3：完成3）',
  `taskExpiryTime` datetime DEFAULT NULL COMMENT '任务到期时间',
  PRIMARY KEY (`id`),
  KEY `cuid` (`cuId`) USING BTREE,
  KEY `invitedCuid` (`invitedCuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='邀请记录';

-- ----------------------------
-- Records of invitation_record
-- ----------------------------
INSERT INTO `invitation_record` VALUES ('1', '112233', '112233', '2019-05-24 15:01:13', '0', '2019-05-25 15:01:23');
INSERT INTO `invitation_record` VALUES ('2', '112233', '118812', '2019-05-24 15:01:58', '0', '2019-05-25 15:02:01');
INSERT INTO `invitation_record` VALUES ('3', '118852', '118814', '2019-05-24 15:02:45', '0', '2019-05-25 15:02:53');
INSERT INTO `invitation_record` VALUES ('4', '118852', '118815', '2019-05-24 15:02:50', '0', '2019-05-25 15:02:59');
INSERT INTO `invitation_record` VALUES ('5', '118852', '118816', '2019-05-24 15:03:24', '0', '2019-05-25 15:03:28');
INSERT INTO `invitation_record` VALUES ('6', '118852', '118817', '2019-05-24 15:03:53', '0', '2019-05-25 15:03:55');
INSERT INTO `invitation_record` VALUES ('7', '118852', '118818', '2019-05-24 15:04:11', '0', '2019-05-25 15:04:14');
INSERT INTO `invitation_record` VALUES ('8', '118852', '118819', '2019-05-24 15:04:36', '0', '2019-05-25 15:04:39');
INSERT INTO `invitation_record` VALUES ('9', '118852', '118822', '2019-05-24 15:07:46', '0', '2019-05-25 15:08:04');
INSERT INTO `invitation_record` VALUES ('10', '118852', '118823', '2019-05-24 15:07:50', '0', '2019-05-25 15:08:15');
INSERT INTO `invitation_record` VALUES ('11', '118852', '118827', '2019-05-24 15:07:52', '0', '2019-05-25 15:08:18');
INSERT INTO `invitation_record` VALUES ('12', '118852', '118829', '2019-05-24 15:07:55', '0', '2019-05-25 15:08:22');
INSERT INTO `invitation_record` VALUES ('13', '118852', '118831', '2019-05-24 15:07:58', '0', '2019-05-25 15:08:27');
INSERT INTO `invitation_record` VALUES ('14', '118852', '118832', '2019-05-24 15:08:00', '0', '2019-05-25 15:08:30');
INSERT INTO `invitation_record` VALUES ('15', '118852', '118834', '2019-05-24 15:09:21', '0', '2019-05-25 15:09:27');
INSERT INTO `invitation_record` VALUES ('16', '118852', '118835', '2019-05-24 15:10:05', '0', '2019-05-25 15:10:09');

-- ----------------------------
-- Table structure for `online_record`
-- ----------------------------
DROP TABLE IF EXISTS `online_record`;
CREATE TABLE `online_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cuId` bigint(20) NOT NULL,
  `uptime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_cuId` (`cuId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='上线记录';

-- ----------------------------
-- Records of online_record
-- ----------------------------
INSERT INTO `online_record` VALUES ('1', '118793', '2019-05-15 15:12:48');
INSERT INTO `online_record` VALUES ('2', '118793', '2019-05-15 15:13:40');

-- ----------------------------
-- Table structure for `personal_center`
-- ----------------------------
DROP TABLE IF EXISTS `personal_center`;
CREATE TABLE `personal_center` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `mainTitle` varchar(50) DEFAULT NULL COMMENT '主标题',
  `mainTitleColor` varchar(20) DEFAULT NULL COMMENT '主标题字色',
  `subTitle` varchar(50) DEFAULT NULL COMMENT '副标题',
  `subTitleColor` varchar(20) DEFAULT NULL COMMENT '副标题字色',
  `threeTitle` varchar(50) DEFAULT NULL COMMENT '三标题',
  `threeTitleColor` varchar(20) DEFAULT NULL COMMENT '三标题字色',
  `picUrl` varchar(255) DEFAULT NULL COMMENT '图标',
  `direction` varchar(50) DEFAULT NULL COMMENT '跳转去向(VIP+:会员+ ; BOOK_MONEY_RECHARGE:充值书币; MSG_CENTER:消息中心; HELP_FEEDBACK:帮助反馈; BIND_PHONE:绑定手机; SET_UP: 设置; READING_FOOTPRINT:阅读足迹;INVITE_FRIEND:邀请好友；WRITE_INVITATION_CODE:填邀请码)',
  `directionPath` varchar(255) DEFAULT NULL COMMENT '链接路径',
  `status` tinyint(4) DEFAULT '0' COMMENT '状态（0：停用；1：启用）',
  `sort` smallint(6) DEFAULT '0' COMMENT '排序',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='个人中心配置';

-- ----------------------------
-- Records of personal_center
-- ----------------------------
INSERT INTO `personal_center` VALUES ('1', '邀请好友领红包', '#FF292929', '限时，邀请好友立赚10元！', '#8D8D8D', '', '', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/fcd7c562-cb95-4df2-ad96-2ed89ff0aa2d-1559098669746.png', 'app', '{\"linkType\":\"app\",\"url\":\"invite\"}', '1', '0', '2019-05-27 15:04:42', '2019-05-30 13:41:45');
INSERT INTO `personal_center` VALUES ('2', '我的钱包', '#FF292929', '', '', '', '', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/45331176-05ef-400f-ae57-06535a14d12e-1559098756231.png', 'h5', '{\"linkType\":\"h5\"}', '1', '0', '2019-05-27 15:05:08', '2019-05-29 11:13:52');
INSERT INTO `personal_center` VALUES ('3', '我要提现', '#FF292929', '', '', '提现秒到账', ' #8D8D8D ', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/491f09db-98e8-4b0d-89ee-c7b5cef1dfe6-1559098763844.png', 'h5', '{\"linkType\":\"h5\"}', '1', '0', '2019-05-27 15:06:58', '2019-05-29 11:13:56');
INSERT INTO `personal_center` VALUES ('4', '会员福利', '#FF292929', '', '', '金豆奖励X3倍', '#E5220E', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/5c13c184-8ab4-46b7-beae-b189320e6444-1559098776110.png', 'app', '{\"linkType\":\"app\",\"url\":\"undefined\"}', '1', '0', '2019-05-27 15:06:58', '2019-05-29 15:30:23');
INSERT INTO `personal_center` VALUES ('5', '我的好友', '#FF292929', '', '', '', '', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/aab3cb60-dd29-4d5b-b1bb-7c7456529fe5-1559098786663.png', 'h5', '{\"linkType\":\"h5\"}', '1', '0', '2019-05-27 15:06:58', '2019-05-29 11:14:11');
INSERT INTO `personal_center` VALUES ('6', '消息通知', '#FF292929', '', '', '', '', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/86c79600-c1be-48e2-a59c-f5d01d9d1763-1559098803791.png', 'h5', '{\"linkType\":\"h5\"}', '1', '0', '2019-05-27 15:06:58', '2019-05-29 11:14:18');
INSERT INTO `personal_center` VALUES ('7', '阅读足迹', '#FF292929', '', '', '', '#E5220E', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/28da8516-5d85-4ae8-97ff-224724ed5113-1559098814680.png', 'h5', '{\"linkType\":\"h5\"}', '1', '0', '2019-05-27 15:06:58', '2019-05-30 16:40:21');
INSERT INTO `personal_center` VALUES ('8', '红包兑换码', '#FF292929', '', '', '领现金红包', ' #FFE5220E ', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/53d65f42-c8a5-45d8-8776-406abd20d769-1559098827456.png', 'h5', '{\"linkType\":\"h5\"}', '1', '0', '2019-05-27 15:06:58', '2019-05-30 20:14:39');
INSERT INTO `personal_center` VALUES ('9', '帮助中心', '#FF292929', '', '', '', '', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/2e435c39-230f-488a-b7e1-63ca91475f10-1559098837030.png', 'h5', '{\"linkType\":\"h5\"}', '1', '0', '2019-05-27 15:06:58', '2019-05-29 11:14:37');
INSERT INTO `personal_center` VALUES ('10', '系统设置', '#FF292929', '', '', '', '', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/4b23fe8a-03af-4dcb-9cd6-4bd1fe121993-1559098846659.png', 'h5', '{\"linkType\":\"h5\"}', '1', '0', '2019-05-20 15:06:58', '2019-05-29 11:14:42');
INSERT INTO `personal_center` VALUES ('14', 'test', '', '', '', '', '', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/personal/ded109a6-f389-40d3-969e-77afd2604fe8-1559281308646.png', 'app', '{\"linkType\":\"share\"}', '1', '11', '2019-05-31 13:42:07', '2019-05-31 17:01:42');

-- ----------------------------
-- Table structure for `read_footprint`
-- ----------------------------
DROP TABLE IF EXISTS `read_footprint`;
CREATE TABLE `read_footprint` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL COMMENT '用户id',
  `bid` bigint(20) DEFAULT NULL COMMENT '书籍id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COMMENT='阅读足迹';

-- ----------------------------
-- Records of read_footprint
-- ----------------------------
INSERT INTO `read_footprint` VALUES ('4', '222', '1605', '2019-05-17 14:51:20');
INSERT INTO `read_footprint` VALUES ('5', '333', '116312', '2019-05-20 19:33:28');
INSERT INTO `read_footprint` VALUES ('6', '334', '1928', '2019-05-20 19:43:55');
INSERT INTO `read_footprint` VALUES ('7', '335', '11013', '2019-05-29 10:41:39');
INSERT INTO `read_footprint` VALUES ('8', '118868', '11013', '2019-06-03 09:57:48');
INSERT INTO `read_footprint` VALUES ('9', '118814', '11175', '2019-05-28 11:44:49');
INSERT INTO `read_footprint` VALUES ('10', '118869', '11151', '2019-05-30 11:34:55');
INSERT INTO `read_footprint` VALUES ('11', '118814', '11149', '2019-05-29 08:53:15');
INSERT INTO `read_footprint` VALUES ('12', '118814', '11098', '2019-05-29 09:37:08');
INSERT INTO `read_footprint` VALUES ('13', '118832', '11175', '2019-05-29 11:24:45');
INSERT INTO `read_footprint` VALUES ('14', '118832', '11150', '2019-05-29 16:20:28');
INSERT INTO `read_footprint` VALUES ('15', '118869', '1643', '2019-05-29 16:58:58');
INSERT INTO `read_footprint` VALUES ('16', '118869', '1928', '2019-05-29 13:35:12');
INSERT INTO `read_footprint` VALUES ('17', '118869', '11092', '2019-05-29 14:29:13');
INSERT INTO `read_footprint` VALUES ('18', '118832', '11149', '2019-05-29 13:41:02');
INSERT INTO `read_footprint` VALUES ('19', '118869', '1942', '2019-05-29 13:56:49');
INSERT INTO `read_footprint` VALUES ('20', '118869', '1957', '2019-05-29 13:59:16');
INSERT INTO `read_footprint` VALUES ('21', '118875', '11151', '2019-05-29 14:06:24');
INSERT INTO `read_footprint` VALUES ('22', '118875', '11092', '2019-05-29 14:11:48');
INSERT INTO `read_footprint` VALUES ('23', '118869', '11149', '2019-05-29 14:21:58');
INSERT INTO `read_footprint` VALUES ('24', '118869', '11177', '2019-05-29 14:26:28');
INSERT INTO `read_footprint` VALUES ('25', '118832', '11151', '2019-05-29 16:20:11');
INSERT INTO `read_footprint` VALUES ('26', '118854', '1940', '2019-05-29 16:45:07');
INSERT INTO `read_footprint` VALUES ('27', '118881', '11151', '2019-05-30 10:32:25');
INSERT INTO `read_footprint` VALUES ('28', '118869', '1940', '2019-05-30 11:31:01');
INSERT INTO `read_footprint` VALUES ('29', '118838', '11063', '2019-05-30 11:39:08');
INSERT INTO `read_footprint` VALUES ('30', '118814', '11151', '2019-05-30 20:22:24');
INSERT INTO `read_footprint` VALUES ('31', '118838', '11075', '2019-05-30 11:48:47');
INSERT INTO `read_footprint` VALUES ('32', '118881', '11153', '2019-05-30 11:50:16');
INSERT INTO `read_footprint` VALUES ('33', '0', '11151', '2019-05-30 12:49:58');
INSERT INTO `read_footprint` VALUES ('34', '118886', '11151', '2019-05-30 13:38:21');
INSERT INTO `read_footprint` VALUES ('35', '118838', '11151', '2019-05-30 13:54:08');
INSERT INTO `read_footprint` VALUES ('36', '118838', '11098', '2019-05-30 13:42:20');
INSERT INTO `read_footprint` VALUES ('37', '118885', '11151', '2019-05-31 19:32:30');
INSERT INTO `read_footprint` VALUES ('38', '118838', '11175', '2019-05-30 13:54:21');
INSERT INTO `read_footprint` VALUES ('39', '118838', '1940', '2019-05-30 14:15:25');
INSERT INTO `read_footprint` VALUES ('40', '118881', '115604', '2019-05-30 13:56:28');
INSERT INTO `read_footprint` VALUES ('41', '118881', '115626', '2019-05-30 13:59:35');
INSERT INTO `read_footprint` VALUES ('42', '118814', '115457', '2019-05-30 13:59:50');
INSERT INTO `read_footprint` VALUES ('43', '118814', '11092', '2019-05-30 14:01:08');
INSERT INTO `read_footprint` VALUES ('44', '118814', '1665', '2019-05-30 14:01:52');
INSERT INTO `read_footprint` VALUES ('45', '118814', '115539', '2019-05-30 14:02:02');
INSERT INTO `read_footprint` VALUES ('46', '118814', '11038', '2019-05-30 14:07:32');
INSERT INTO `read_footprint` VALUES ('47', '118814', '1940', '2019-05-30 14:42:24');
INSERT INTO `read_footprint` VALUES ('48', '118814', '11183', '2019-05-30 14:41:05');
INSERT INTO `read_footprint` VALUES ('49', '118814', '1637', '2019-05-30 14:43:25');
INSERT INTO `read_footprint` VALUES ('50', '118814', '1931', '2019-05-31 15:46:22');
INSERT INTO `read_footprint` VALUES ('51', '118888', '118284', '2019-05-30 16:50:18');
INSERT INTO `read_footprint` VALUES ('52', '118888', '11177', '2019-05-30 16:58:12');
INSERT INTO `read_footprint` VALUES ('53', '118888', '11150', '2019-05-30 16:56:33');
INSERT INTO `read_footprint` VALUES ('54', '118885', '11092', '2019-05-30 19:05:06');
INSERT INTO `read_footprint` VALUES ('55', '118888', '1946', '2019-05-30 17:43:27');
INSERT INTO `read_footprint` VALUES ('56', '118885', '11177', '2019-05-30 18:30:30');
INSERT INTO `read_footprint` VALUES ('57', '118885', '11183', '2019-05-30 17:56:24');
INSERT INTO `read_footprint` VALUES ('58', '118885', '11149', '2019-05-30 18:07:15');
INSERT INTO `read_footprint` VALUES ('59', '118885', '11098', '2019-05-30 20:05:53');
INSERT INTO `read_footprint` VALUES ('60', '118885', '11150', '2019-05-30 18:30:22');
INSERT INTO `read_footprint` VALUES ('61', '118885', '11175', '2019-05-30 18:30:45');
INSERT INTO `read_footprint` VALUES ('62', '118885', '11075', '2019-05-30 18:37:06');
INSERT INTO `read_footprint` VALUES ('63', '118814', '11178', '2019-05-30 20:08:02');
INSERT INTO `read_footprint` VALUES ('64', '118814', '1928', '2019-05-30 20:17:00');
INSERT INTO `read_footprint` VALUES ('65', '118814', '11075', '2019-05-30 20:44:37');
INSERT INTO `read_footprint` VALUES ('66', '0', '115593', '2019-05-31 11:33:06');
INSERT INTO `read_footprint` VALUES ('67', '118881', '1957', '2019-05-31 15:15:56');
INSERT INTO `read_footprint` VALUES ('68', '118881', '11149', '2019-05-31 15:20:48');
INSERT INTO `read_footprint` VALUES ('69', '118885', '116211', '2019-05-31 19:21:30');
INSERT INTO `read_footprint` VALUES ('70', '118873', '11177', '2019-05-31 16:13:04');
INSERT INTO `read_footprint` VALUES ('71', '118873', '11151', '2019-05-31 16:17:24');
INSERT INTO `read_footprint` VALUES ('72', '0', '115656', '2019-05-31 16:30:39');
INSERT INTO `read_footprint` VALUES ('73', '118892', '11151', '2019-05-31 16:35:23');
INSERT INTO `read_footprint` VALUES ('74', '118885', '11087', '2019-05-31 16:56:40');
INSERT INTO `read_footprint` VALUES ('75', '118885', '115517', '2019-05-31 16:58:00');
INSERT INTO `read_footprint` VALUES ('76', '118885', '1790', '2019-05-31 16:58:06');
INSERT INTO `read_footprint` VALUES ('77', '118885', '1636', '2019-05-31 17:11:07');
INSERT INTO `read_footprint` VALUES ('78', '118858', '11151', '2019-05-31 17:11:38');
INSERT INTO `read_footprint` VALUES ('79', '118892', '1637', '2019-05-31 17:30:40');
INSERT INTO `read_footprint` VALUES ('80', '118888', '11095', '2019-05-31 17:32:28');
INSERT INTO `read_footprint` VALUES ('81', '118892', '11149', '2019-05-31 17:32:41');

-- ----------------------------
-- Table structure for `read_time_perday`
-- ----------------------------
DROP TABLE IF EXISTS `read_time_perday`;
CREATE TABLE `read_time_perday` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cuId` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `readDate` varchar(255) DEFAULT NULL COMMENT '阅读日期 ( yyyy-MM-dd )',
  `lastReadTime` datetime DEFAULT NULL,
  `timeCount` bigint(20) DEFAULT NULL COMMENT '阅读时长（秒）',
  `awardStatus` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of read_time_perday
-- ----------------------------
INSERT INTO `read_time_perday` VALUES ('1', '118794', '2019-05-08', '2019-05-10 18:52:24', '120', null);
INSERT INTO `read_time_perday` VALUES ('2', '112233', '2019-05-08', '2019-05-09 17:27:40', '3600', '60');
INSERT INTO `read_time_perday` VALUES ('3', '112233', '2019-05-10', '2019-05-10 14:13:18', '30', '60');
INSERT INTO `read_time_perday` VALUES ('4', '118851', '2019-05-23', '2019-05-23 13:54:29', '120', '0');
INSERT INTO `read_time_perday` VALUES ('5', '118851', '2019-05-24', '2019-05-24 16:31:22', '840', '0');
INSERT INTO `read_time_perday` VALUES ('6', '118851', '2019-05-25', '2019-05-25 16:43:08', '1020', '0');
INSERT INTO `read_time_perday` VALUES ('7', '118859', '2019-05-25', '2019-05-25 16:22:39', '600', '0');
INSERT INTO `read_time_perday` VALUES ('8', '118860', '2019-05-25', '2019-05-25 19:08:00', '120', '0');
INSERT INTO `read_time_perday` VALUES ('9', '118851', '2019-05-27', '2019-05-27 09:35:50', '180', '0');
INSERT INTO `read_time_perday` VALUES ('10', '118863', '2019-05-27', '2019-05-27 13:56:04', '210', '0');
INSERT INTO `read_time_perday` VALUES ('11', '118859', '2019-05-27', '2019-05-27 15:45:05', '60', '0');
INSERT INTO `read_time_perday` VALUES ('12', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('13', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('14', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('15', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('16', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('17', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('18', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('19', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('20', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('21', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('22', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('23', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('24', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('25', '118859', '2019-05-27', '2019-05-27 15:44:35', '30', '0');
INSERT INTO `read_time_perday` VALUES ('26', '118869', '2019-05-27', '2019-05-27 20:28:11', '1380', '0');
INSERT INTO `read_time_perday` VALUES ('27', '118844', '2019-05-28', '2019-05-28 17:10:01', '120', '0');
INSERT INTO `read_time_perday` VALUES ('28', '118871', '2019-05-28', '2019-05-28 17:57:08', '1440', '0');
INSERT INTO `read_time_perday` VALUES ('29', '118869', '2019-05-28', '2019-05-28 19:01:11', '90', '0');
INSERT INTO `read_time_perday` VALUES ('30', '118869', '2019-05-29', '2019-05-29 14:26:58', '4890', '60');
INSERT INTO `read_time_perday` VALUES ('31', '118878', '2019-05-29', '2019-05-29 17:32:42', '180', '0');
INSERT INTO `read_time_perday` VALUES ('32', '118844', '2019-05-29', '2019-05-29 17:47:57', '30', '0');
INSERT INTO `read_time_perday` VALUES ('33', '118881', '2019-05-30', '2019-05-30 13:58:55', '720', '0');
INSERT INTO `read_time_perday` VALUES ('34', '118869', '2019-05-30', '2019-05-30 11:32:20', '720', '0');
INSERT INTO `read_time_perday` VALUES ('35', '118885', '2019-05-30', '2019-05-30 20:06:23', '1680', '0');
INSERT INTO `read_time_perday` VALUES ('36', '118889', '2019-05-30', '2019-05-30 16:47:54', '90', '0');
INSERT INTO `read_time_perday` VALUES ('37', '118881', '2019-05-31', '2019-05-31 15:17:49', '120', '0');
INSERT INTO `read_time_perday` VALUES ('38', '118885', '2019-05-31', '2019-05-31 19:33:00', '1470', '0');
INSERT INTO `read_time_perday` VALUES ('39', '118892', '2019-05-31', '2019-05-31 17:39:25', '480', '0');

-- ----------------------------
-- Table structure for `redpacket_check_result`
-- ----------------------------
DROP TABLE IF EXISTS `redpacket_check_result`;
CREATE TABLE `redpacket_check_result` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `returnCode` varchar(32) DEFAULT NULL COMMENT '通信状态(SUCCESS | FAIL）',
  `returnMsg` varchar(255) DEFAULT NULL COMMENT '信息',
  `resultCode` varchar(32) DEFAULT NULL COMMENT '结果（SUCCESS/FAIL）',
  `errCode` varchar(32) DEFAULT NULL COMMENT '错误代码',
  `errCodeCes` varchar(255) DEFAULT NULL COMMENT '错误代码描述',
  `mchBillno` varchar(32) NOT NULL COMMENT '商户订单号	',
  `mchId` varchar(32) DEFAULT NULL COMMENT '商户号	',
  `detailId` varchar(32) DEFAULT NULL COMMENT '红包单号	',
  `status` varchar(255) DEFAULT NULL COMMENT 'SENDING:发放中 | SENT:已发放待领取 | FAILED：发放失败 | RECEIVED:已领取  | RFUND_ING:退款中 | REFUND:已退款',
  `sendType` varchar(255) DEFAULT NULL COMMENT '发放类型(API:通过API接口发放 | UPLOAD:通过上传文件方式发放 | ACTIVITY:通过活动方式发放)',
  `hbType` varchar(255) DEFAULT NULL COMMENT '红包类型	(GROUP:裂变红包 | NORMAL:普通红包)',
  `totalNum` int(11) DEFAULT NULL COMMENT '红包个数',
  `totalAmount` int(11) DEFAULT NULL COMMENT '红包金额',
  `reason` varchar(255) DEFAULT NULL COMMENT '失败原因',
  `sendTime` varchar(32) DEFAULT NULL COMMENT '红包发送时间	',
  `refundTime` varchar(32) DEFAULT NULL COMMENT '红包退款时间	',
  `refundAmount` int(11) DEFAULT NULL COMMENT '红包退款金额	',
  `wishing` varchar(255) DEFAULT NULL COMMENT '祝福语	',
  `remark` varchar(255) DEFAULT NULL COMMENT '活动描述	',
  `actName` varchar(255) DEFAULT NULL COMMENT '活动名称	',
  PRIMARY KEY (`id`),
  KEY `mch_billno` (`mchBillno`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='查询红包结果';

-- ----------------------------
-- Records of redpacket_check_result
-- ----------------------------

-- ----------------------------
-- Table structure for `redpacket_result`
-- ----------------------------
DROP TABLE IF EXISTS `redpacket_result`;
CREATE TABLE `redpacket_result` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mchBillno` varchar(50) NOT NULL COMMENT '订单号',
  `returnCode` varchar(255) DEFAULT NULL COMMENT '返回码',
  `returnMsg` varchar(255) DEFAULT NULL COMMENT '返回信息',
  `resultCode` varchar(255) DEFAULT NULL COMMENT '业务结果',
  `errCode` varchar(255) DEFAULT NULL COMMENT '错误码',
  `errCodeDes` varchar(255) DEFAULT NULL COMMENT '错误码描述',
  `mchId` varchar(255) DEFAULT NULL COMMENT '商户id',
  `wxappid` varchar(255) DEFAULT NULL COMMENT '工作号id',
  `reOpenid` varchar(255) DEFAULT NULL COMMENT '用户openid',
  `totalAmount` int(11) DEFAULT '0' COMMENT '付款金额',
  `sendListid` varchar(255) DEFAULT NULL COMMENT '微信单号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of redpacket_result
-- ----------------------------

-- ----------------------------
-- Table structure for `reward_double`
-- ----------------------------
DROP TABLE IF EXISTS `reward_double`;
CREATE TABLE `reward_double` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL COMMENT '用户id',
  `multiple` int(2) DEFAULT '0' COMMENT '倍数',
  `expiryTime` datetime DEFAULT NULL COMMENT '过期时间',
  `type` varchar(20) DEFAULT NULL COMMENT '类型（invitation:邀请）',
  PRIMARY KEY (`id`),
  KEY `IDX_cuId` (`cuId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='奖励加倍';

-- ----------------------------
-- Records of reward_double
-- ----------------------------

-- ----------------------------
-- Table structure for `system_config`
-- ----------------------------
DROP TABLE IF EXISTS `system_config`;
CREATE TABLE `system_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL COMMENT '类型（exchangeRatio:兑换比例）',
  `number1` int(11) DEFAULT NULL COMMENT '数值1(人民币单位：分)',
  `number2` int(11) DEFAULT NULL COMMENT '数值2',
  PRIMARY KEY (`id`),
  KEY `index_type` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统配置';

-- ----------------------------
-- Records of system_config
-- ----------------------------
INSERT INTO `system_config` VALUES ('1', 'exchangeRatio', '1', '100');
