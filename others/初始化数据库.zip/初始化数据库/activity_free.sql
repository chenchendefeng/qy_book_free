/*
Navicat MySQL Data Transfer

Source Server         : 192.168.18.210
Source Server Version : 50631
Source Host           : 192.168.18.210:3306
Source Database       : activity_free

Target Server Type    : MYSQL
Target Server Version : 50631
File Encoding         : 65001

Date: 2019-06-03 11:36:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `activitys_config`
-- ----------------------------
DROP TABLE IF EXISTS `activitys_config`;
CREATE TABLE `activitys_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type` varchar(50) NOT NULL COMMENT '类型用于查询具体的获取',
  `title` varchar(50) DEFAULT NULL COMMENT '活动名称',
  `enabled` tinyint(2) DEFAULT '0' COMMENT '启用状态（0：关闭；1；启用）',
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `ruleIds` varchar(128) DEFAULT NULL COMMENT '活动规则Id （多个规则用“逗号”分隔）',
  `positionIds` varchar(128) DEFAULT NULL COMMENT '位置Id （多个规则用“逗号”分隔）',
  `awardIds` varchar(128) DEFAULT NULL COMMENT '奖品Id （多个规则用“逗号”分隔）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='活动配置表';

-- ----------------------------
-- Records of activitys_config
-- ----------------------------
INSERT INTO `activitys_config` VALUES ('1', 'SPRING_DRAW', '新春七天乐', '1', '2019-01-31 11:00:00', '2019-02-07 23:59:59', '2019-01-28 18:44:49', '2019-01-28 18:44:51', null, null, null);
INSERT INTO `activitys_config` VALUES ('2', 'NEWUSER_500_BOOKMONEY', '新人大礼包1000', '1', '2019-02-27 17:06:32', '2024-02-27 17:06:40', '2019-02-27 17:07:23', '2019-02-27 17:07:26', '[2]', '', '[4]');
INSERT INTO `activitys_config` VALUES ('3', 'activity_1553496369325', '摇一摇常规活动', '1', '2019-03-25 00:00:00', '2023-03-31 00:00:00', '2019-03-25 14:46:09', '2019-03-25 14:46:09', '[2]', '[5],[3]', '[3]');

-- ----------------------------
-- Table structure for `activity_rule`
-- ----------------------------
DROP TABLE IF EXISTS `activity_rule`;
CREATE TABLE `activity_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `ruleName` varchar(255) DEFAULT NULL,
  `ruleDesc` varchar(255) DEFAULT NULL,
  `value1` int(11) DEFAULT NULL COMMENT '阈值1',
  `value1Desc` varchar(255) DEFAULT NULL COMMENT '阈值1描述',
  `value2` int(11) DEFAULT NULL COMMENT '阈值2',
  `value2Desc` varchar(255) DEFAULT NULL COMMENT '阈值2描述',
  `ruleCode` varchar(255) DEFAULT NULL COMMENT '规则编码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of activity_rule
-- ----------------------------
INSERT INTO `activity_rule` VALUES ('1', '注册或者首次访问时间小于24小时的用户', '注册或者首次访问时间小于24小时的用户', '24', '注册或者首次访问时间', null, null, 'regDateAndFirstVisit_ge_24');
INSERT INTO `activity_rule` VALUES ('2', '所有用户', '所有用户', null, null, null, null, 'allUser');
INSERT INTO `activity_rule` VALUES ('3', '注册或者首次访问时间大于72小时的用户', '注册或者首次访问时间大于72小时的用户', '72', '注册或者首次访问时间', null, null, 'regDateAndFirstVisit_le_72');

-- ----------------------------
-- Table structure for `app_position`
-- ----------------------------
DROP TABLE IF EXISTS `app_position`;
CREATE TABLE `app_position` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `positionCode` varchar(64) NOT NULL COMMENT '位置编码',
  `positionName` varchar(128) NOT NULL COMMENT '位置名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app_position
-- ----------------------------
INSERT INTO `app_position` VALUES ('3', 'firstPageShake', '精选页面摇一摇');
INSERT INTO `app_position` VALUES ('5', 'findPageShake', '发现页面摇一摇');

-- ----------------------------
-- Table structure for `attendance`
-- ----------------------------
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL,
  `type` tinyint(2) DEFAULT '1' COMMENT '类型（0:首签；1:签到；2：补签)',
  `attendanceDate` varchar(20) DEFAULT NULL COMMENT '日期',
  `times` int(11) DEFAULT NULL COMMENT '连续次数',
  `createTime` datetime DEFAULT NULL COMMENT '创建日期',
  PRIMARY KEY (`id`),
  KEY `cuId` (`cuId`) USING BTREE COMMENT 'cuId索引'
) ENGINE=InnoDB AUTO_INCREMENT=317 DEFAULT CHARSET=utf8 COMMENT='签到';

-- ----------------------------
-- Records of attendance
-- ----------------------------
INSERT INTO `attendance` VALUES ('32', '118819', '0', '2019-05-9', '1', '2019-05-09 14:14:46');
INSERT INTO `attendance` VALUES ('33', '118819', '2', '2019-05-13', '4', '2019-05-14 14:16:04');
INSERT INTO `attendance` VALUES ('38', '118819', '2', '2019-05-10', '1', '2019-05-14 14:17:59');
INSERT INTO `attendance` VALUES ('39', '118819', '2', '2019-05-11', '2', '2019-05-14 14:18:17');
INSERT INTO `attendance` VALUES ('40', '118819', '2', '2019-05-12', '3', '2019-05-14 14:19:23');
INSERT INTO `attendance` VALUES ('41', '118819', '1', '2019-05-14', '5', '2019-05-14 14:56:42');
INSERT INTO `attendance` VALUES ('42', '118820', '0', '2019-05-05', '1', '2019-05-05 17:43:02');
INSERT INTO `attendance` VALUES ('54', '118829', '0', '2019-05-10', '2', '2019-05-10 18:19:24');
INSERT INTO `attendance` VALUES ('56', '118829', '1', '2019-05-12', '4', '2019-05-12 18:20:44');
INSERT INTO `attendance` VALUES ('57', '118829', '1', '2019-05-13', '5', '2019-05-13 18:21:08');
INSERT INTO `attendance` VALUES ('58', '118829', '1', '2019-05-14', '6', '2019-05-14 18:22:18');
INSERT INTO `attendance` VALUES ('60', '118829', '2', '2019-05-09', '1', '2019-05-14 18:25:04');
INSERT INTO `attendance` VALUES ('61', '118829', '2', '2019-05-11', '3', '2019-05-14 18:26:20');
INSERT INTO `attendance` VALUES ('64', '118842', '0', '2019-05-16', '1', '2019-05-16 14:24:15');
INSERT INTO `attendance` VALUES ('65', '118814', '0', '2019-05-10', '1', '2019-05-10 19:00:26');
INSERT INTO `attendance` VALUES ('67', '118853', '0', '2019-05-23', '1', '2019-05-23 16:39:14');
INSERT INTO `attendance` VALUES ('68', '118852', '0', '2019-05-23', '1', '2019-05-23 18:09:16');
INSERT INTO `attendance` VALUES ('69', '118814', '1', '2019-05-24', '3', '2019-05-24 10:23:01');
INSERT INTO `attendance` VALUES ('70', '118855', '0', '2019-05-24', '1', '2019-05-24 11:16:58');
INSERT INTO `attendance` VALUES ('235', '118851', '0', '2019-05-20', '1', '2019-05-20 14:18:06');
INSERT INTO `attendance` VALUES ('237', '118852', '1', '2019-05-24', '2', '2019-05-24 14:31:51');
INSERT INTO `attendance` VALUES ('240', '118856', '0', '2019-05-20', '1', '2019-05-20 14:38:44');
INSERT INTO `attendance` VALUES ('243', '118856', '1', '2019-05-23', '4', '2019-05-24 14:40:18');
INSERT INTO `attendance` VALUES ('253', '118856', '2', '2019-05-21', '2', '2019-05-24 15:35:44');
INSERT INTO `attendance` VALUES ('254', '118814', '2', '2019-05-23', '2', '2019-05-24 17:01:05');
INSERT INTO `attendance` VALUES ('255', '118814', '2', '2019-05-22', '1', '2019-05-24 17:02:34');
INSERT INTO `attendance` VALUES ('256', '118844', '0', '2019-05-24', '1', '2019-05-24 17:39:04');
INSERT INTO `attendance` VALUES ('257', '118851', '1', '2019-05-24', '1', '2019-05-24 18:42:00');
INSERT INTO `attendance` VALUES ('258', '118851', '2', '2019-05-21', '2', '2019-05-24 18:44:47');
INSERT INTO `attendance` VALUES ('259', '118851', '1', '2019-05-25', '2', '2019-05-25 14:26:47');
INSERT INTO `attendance` VALUES ('260', '118814', '1', '2019-05-25', '4', '2019-05-25 14:30:39');
INSERT INTO `attendance` VALUES ('261', '118851', '1', '2019-05-27', '1', '2019-05-27 10:28:31');
INSERT INTO `attendance` VALUES ('262', '118863', '0', '2019-05-27', '1', '2019-05-27 10:35:15');
INSERT INTO `attendance` VALUES ('263', '118844', '1', '2019-05-27', '4', '2019-05-27 11:53:08');
INSERT INTO `attendance` VALUES ('264', '118832', '0', '2019-05-27', '1', '2019-05-27 15:29:45');
INSERT INTO `attendance` VALUES ('265', '118854', '0', '2019-05-27', '1', '2019-05-27 16:02:28');
INSERT INTO `attendance` VALUES ('266', '118865', '0', '2019-05-27', '1', '2019-05-27 17:01:02');
INSERT INTO `attendance` VALUES ('267', '118837', '0', '2019-05-27', '1', '2019-05-27 17:30:49');
INSERT INTO `attendance` VALUES ('268', '118867', '0', '2019-05-27', '1', '2019-05-27 17:33:56');
INSERT INTO `attendance` VALUES ('269', '118866', '0', '2019-05-27', '1', '2019-05-27 17:52:57');
INSERT INTO `attendance` VALUES ('270', '118869', '0', '2019-05-27', '1', '2019-05-27 19:36:28');
INSERT INTO `attendance` VALUES ('271', '118869', '1', '2019-05-28', '2', '2019-05-28 09:38:50');
INSERT INTO `attendance` VALUES ('272', '118814', '1', '2019-05-28', '7', '2019-05-28 10:32:31');
INSERT INTO `attendance` VALUES ('273', '118814', '2', '2019-05-27', '6', '2019-05-28 10:32:41');
INSERT INTO `attendance` VALUES ('274', '118814', '2', '2019-05-26', '5', '2019-05-28 10:33:16');
INSERT INTO `attendance` VALUES ('275', '118873', '0', '2019-05-28', '1', '2019-05-28 16:30:11');
INSERT INTO `attendance` VALUES ('276', '118844', '1', '2019-05-28', '5', '2019-05-28 17:10:23');
INSERT INTO `attendance` VALUES ('277', '118844', '2', '2019-05-26', '3', '2019-05-28 17:12:03');
INSERT INTO `attendance` VALUES ('278', '118844', '2', '2019-05-25', '2', '2019-05-28 17:12:29');
INSERT INTO `attendance` VALUES ('279', '118871', '0', '2019-05-28', '1', '2019-05-28 17:17:55');
INSERT INTO `attendance` VALUES ('280', '118814', '1', '2019-05-29', '8', '2019-05-29 08:54:02');
INSERT INTO `attendance` VALUES ('282', '118869', '1', '2019-05-29', '3', '2019-05-29 14:27:15');
INSERT INTO `attendance` VALUES ('283', '118844', '1', '2019-05-29', '6', '2019-05-29 15:02:20');
INSERT INTO `attendance` VALUES ('284', '118877', '0', '2019-05-29', '1', '2019-05-29 15:06:19');
INSERT INTO `attendance` VALUES ('285', '118854', '1', '2019-05-29', '1', '2019-05-29 16:44:30');
INSERT INTO `attendance` VALUES ('286', '118838', '0', '2019-05-30', '1', '2019-05-30 09:43:32');
INSERT INTO `attendance` VALUES ('287', '118875', '0', '2019-05-30', '1', '2019-05-30 09:44:10');
INSERT INTO `attendance` VALUES ('288', '118881', '0', '2019-05-30', '1', '2019-05-30 09:49:37');
INSERT INTO `attendance` VALUES ('289', '118814', '1', '2019-05-30', '9', '2019-05-30 09:50:37');
INSERT INTO `attendance` VALUES ('290', '118886', '0', '2019-05-30', '1', '2019-05-30 13:33:11');
INSERT INTO `attendance` VALUES ('291', '118885', '0', '2019-05-30', '1', '2019-05-30 13:56:44');
INSERT INTO `attendance` VALUES ('293', '118814', '1', '2019-05-31', '10', '2019-05-31 10:36:57');
INSERT INTO `attendance` VALUES ('294', '118885', '1', '2019-05-31', '2', '2019-05-31 11:42:19');
INSERT INTO `attendance` VALUES ('295', '0', '0', '2019-05-31', '1', '2019-05-31 16:17:29');
INSERT INTO `attendance` VALUES ('296', '118873', '1', '2019-05-31', '1', '2019-05-31 16:18:06');
INSERT INTO `attendance` VALUES ('297', '118876', '0', '2019-05-31', '1', '2019-05-31 16:27:16');
INSERT INTO `attendance` VALUES ('298', '118888', '0', '2019-05-26', '1', '2019-05-26 16:41:08');
INSERT INTO `attendance` VALUES ('310', '118888', '1', '2019-05-31', '6', '2019-05-31 16:46:17');
INSERT INTO `attendance` VALUES ('312', '118888', '2', '2019-05-30', '5', '2019-05-31 16:49:05');
INSERT INTO `attendance` VALUES ('313', '118892', '0', '2019-05-31', '1', '2019-05-31 16:49:06');
INSERT INTO `attendance` VALUES ('314', '118888', '2', '2019-05-29', '4', '2019-05-31 18:51:14');
INSERT INTO `attendance` VALUES ('315', '118888', '2', '2019-05-28', '3', '2019-05-31 18:51:39');
INSERT INTO `attendance` VALUES ('316', '118888', '2', '2019-05-27', '2', '2019-05-31 18:51:41');

-- ----------------------------
-- Table structure for `attendance_compensation`
-- ----------------------------
DROP TABLE IF EXISTS `attendance_compensation`;
CREATE TABLE `attendance_compensation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL,
  `times` int(11) DEFAULT '0' COMMENT '补签机会',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cuid` (`cuId`) USING BTREE COMMENT '用户唯一索引'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='补签机会';

-- ----------------------------
-- Records of attendance_compensation
-- ----------------------------
INSERT INTO `attendance_compensation` VALUES ('1', '123', '3');
INSERT INTO `attendance_compensation` VALUES ('2', '118856', '0');
INSERT INTO `attendance_compensation` VALUES ('3', '118851', '0');
INSERT INTO `attendance_compensation` VALUES ('4', '118814', '0');
INSERT INTO `attendance_compensation` VALUES ('5', '118857', '0');
INSERT INTO `attendance_compensation` VALUES ('6', '118844', '0');

-- ----------------------------
-- Table structure for `attendance_reward`
-- ----------------------------
DROP TABLE IF EXISTS `attendance_reward`;
CREATE TABLE `attendance_reward` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type` varchar(255) NOT NULL DEFAULT 'dailySign' COMMENT '类型（firstSign:首签；dailySign：日常；continuitySign：连续）',
  `gold` bigint(20) DEFAULT '0' COMMENT '金豆数',
  `days` int(11) DEFAULT '1' COMMENT '天数',
  `addNum` bigint(20) DEFAULT '0' COMMENT '递增数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='签到奖励配置';

-- ----------------------------
-- Records of attendance_reward
-- ----------------------------
INSERT INTO `attendance_reward` VALUES ('1', 'firstSign', '100', '1', '0');
INSERT INTO `attendance_reward` VALUES ('2', 'dailySign', '10', '1', '2');
INSERT INTO `attendance_reward` VALUES ('3', 'continuitySign', '150', '5', '0');
INSERT INTO `attendance_reward` VALUES ('4', 'continuitySign', '300', '10', '0');
INSERT INTO `attendance_reward` VALUES ('5', 'continuitySign', '300', '20', '0');
INSERT INTO `attendance_reward` VALUES ('6', 'continuitySign', '1000', '30', '0');
INSERT INTO `attendance_reward` VALUES ('7', 'continuitySign', '300', '40', '0');
INSERT INTO `attendance_reward` VALUES ('8', 'continuitySign', '5000', '50', '0');
INSERT INTO `attendance_reward` VALUES ('9', 'continuitySign', '300', '60', '0');
INSERT INTO `attendance_reward` VALUES ('10', 'continuitySign', '300', '70', '0');
INSERT INTO `attendance_reward` VALUES ('11', 'continuitySign', '300', '80', '0');
INSERT INTO `attendance_reward` VALUES ('12', 'continuitySign', '300', '90', '0');
INSERT INTO `attendance_reward` VALUES ('13', 'continuitySign', '10000', '100', '0');

-- ----------------------------
-- Table structure for `award_info`
-- ----------------------------
DROP TABLE IF EXISTS `award_info`;
CREATE TABLE `award_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activityType` varchar(50) DEFAULT NULL COMMENT '活动',
  `type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '奖品类型 0：书币 1：实物 2：会员',
  `awardDesc` varchar(64) DEFAULT NULL COMMENT '奖品描述',
  `awardValue` varchar(16) DEFAULT '0' COMMENT '奖品价值，单位元',
  `awardCount` int(11) DEFAULT '-1' COMMENT '奖品数量 -1表示不限量',
  `remain` int(11) DEFAULT NULL COMMENT '剩余数量 -1表示不限量',
  `amount` int(11) DEFAULT NULL COMMENT '奖品金额（如书币个数、会员天数，若是话费单位就是分）',
  `createDate` datetime DEFAULT NULL,
  `updateDate` datetime DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序（奖品优先级）',
  `sendType` varchar(32) NOT NULL DEFAULT 'fix' COMMENT '奖品数量发放方式 （fix: 固定值  | random: 随机数）',
  `sendPeriod` varchar(32) NOT NULL DEFAULT 'once' COMMENT '发放周期： （ once: 一次 | onceDay： 一天一次| forever: 永久）',
  `usePeriod` int(11) NOT NULL DEFAULT '-1' COMMENT '使用有效期(天)（-1：无时间限制）',
  `amount1` int(11) DEFAULT NULL COMMENT '奖品书籍随机值上限',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态 （1开启|0关闭）',
  `awardType` varchar(32) DEFAULT NULL COMMENT '奖品类型 （virtual:虚拟 | entity:实物）',
  `awardCode` varchar(32) NOT NULL COMMENT '奖品编码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='奖品表';

-- ----------------------------
-- Records of award_info
-- ----------------------------
INSERT INTO `award_info` VALUES ('1', 'SPRING_DRAW', '0', '100书币', '0', '-1', '-1', '100', '2019-01-28 20:18:37', '2019-01-28 20:18:39', '0', 'fix', 'once', '-1', null, '0', null, '');
INSERT INTO `award_info` VALUES ('2', 'NEWUSER_500_BOOKMONEY', '0', '1000书币', '0', '-1', '-1', '1000', '2019-02-27 17:08:15', '2019-02-27 17:08:17', '0', 'fix', 'once', '-1', null, '0', null, '');
INSERT INTO `award_info` VALUES ('3', null, '0', '摇一摇日常奖励', '0', '-1', null, '10', '2019-03-25 14:35:47', '2019-03-25 14:35:47', '0', 'random', 'onceDay', '-1', '50', '1', 'virtual', 'award_1553495746695');
INSERT INTO `award_info` VALUES ('4', null, '0', '新人礼包1000书币', '0', '-1', null, '1000', '2019-03-26 19:58:09', '2019-03-26 19:58:09', '0', 'random', 'once', '-1', '1000', '1', 'virtual', 'award_1553601489463');

-- ----------------------------
-- Table structure for `award_item`
-- ----------------------------
DROP TABLE IF EXISTS `award_item`;
CREATE TABLE `award_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `awardId` bigint(20) NOT NULL,
  `awardItemName` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `odds` decimal(3,1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of award_item
-- ----------------------------

-- ----------------------------
-- Table structure for `award_receive`
-- ----------------------------
DROP TABLE IF EXISTS `award_receive`;
CREATE TABLE `award_receive` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uid` bigint(20) NOT NULL,
  `status` tinyint(2) DEFAULT '0' COMMENT '状态：0：未领取；1：已领取',
  `activityType` varchar(50) DEFAULT NULL COMMENT '活动类型',
  `awardId` int(11) DEFAULT NULL COMMENT '奖品id',
  `createDate` datetime DEFAULT NULL COMMENT '时间',
  `systemType` varchar(32) DEFAULT NULL,
  `channel` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=500 DEFAULT CHARSET=utf8 COMMENT='领奖记录表';

-- ----------------------------
-- Records of award_receive
-- ----------------------------
INSERT INTO `award_receive` VALUES ('3', '105292', '1', 'SPRING_DRAW', '1', '2019-01-31 11:03:34', null, null);
INSERT INTO `award_receive` VALUES ('4', '105263', '1', 'SPRING_DRAW', '1', '2019-01-31 11:04:29', null, null);
INSERT INTO `award_receive` VALUES ('5', '104562', '1', 'SPRING_DRAW', '1', '2019-01-31 11:06:27', null, null);
INSERT INTO `award_receive` VALUES ('6', '104565', '1', 'SPRING_DRAW', '1', '2019-01-31 11:17:42', null, null);
INSERT INTO `award_receive` VALUES ('7', '105402', '1', 'SPRING_DRAW', '1', '2019-01-31 11:20:00', null, null);
INSERT INTO `award_receive` VALUES ('8', '104561', '1', 'SPRING_DRAW', '1', '2019-01-31 11:31:25', null, null);
INSERT INTO `award_receive` VALUES ('9', '105438', '1', 'SPRING_DRAW', '1', '2019-01-31 13:15:34', null, null);
INSERT INTO `award_receive` VALUES ('10', '105440', '1', 'SPRING_DRAW', '1', '2019-01-31 14:18:36', null, null);
INSERT INTO `award_receive` VALUES ('11', '105441', '1', 'SPRING_DRAW', '1', '2019-01-31 14:36:59', null, null);
INSERT INTO `award_receive` VALUES ('12', '104563', '1', 'SPRING_DRAW', '1', '2019-01-31 16:04:16', null, null);
INSERT INTO `award_receive` VALUES ('13', '105444', '1', 'SPRING_DRAW', '1', '2019-01-31 16:19:20', null, null);
INSERT INTO `award_receive` VALUES ('14', '105446', '1', 'SPRING_DRAW', '1', '2019-01-31 19:50:53', null, null);
INSERT INTO `award_receive` VALUES ('15', '105449', '1', 'SPRING_DRAW', '1', '2019-01-31 20:52:58', null, null);
INSERT INTO `award_receive` VALUES ('16', '105450', '1', 'SPRING_DRAW', '1', '2019-01-31 21:27:34', null, null);
INSERT INTO `award_receive` VALUES ('17', '105454', '1', 'SPRING_DRAW', '1', '2019-02-01 01:39:19', null, null);
INSERT INTO `award_receive` VALUES ('18', '105456', '1', 'SPRING_DRAW', '1', '2019-02-01 06:44:25', null, null);
INSERT INTO `award_receive` VALUES ('19', '105458', '1', 'SPRING_DRAW', '1', '2019-02-01 07:19:52', null, null);
INSERT INTO `award_receive` VALUES ('20', '105460', '1', 'SPRING_DRAW', '1', '2019-02-01 09:55:15', null, null);
INSERT INTO `award_receive` VALUES ('21', '105462', '1', 'SPRING_DRAW', '1', '2019-02-01 10:20:40', null, null);
INSERT INTO `award_receive` VALUES ('22', '105463', '1', 'SPRING_DRAW', '1', '2019-02-01 10:48:50', null, null);
INSERT INTO `award_receive` VALUES ('23', '105464', '1', 'SPRING_DRAW', '1', '2019-02-01 12:41:30', null, null);
INSERT INTO `award_receive` VALUES ('24', '105266', '1', 'SPRING_DRAW', '1', '2019-02-01 13:12:04', null, null);
INSERT INTO `award_receive` VALUES ('25', '104557', '1', 'SPRING_DRAW', '1', '2019-02-01 13:45:21', null, null);
INSERT INTO `award_receive` VALUES ('26', '105466', '1', 'SPRING_DRAW', '1', '2019-02-01 14:28:05', null, null);
INSERT INTO `award_receive` VALUES ('27', '105467', '1', 'SPRING_DRAW', '1', '2019-02-01 14:51:30', null, null);
INSERT INTO `award_receive` VALUES ('28', '105469', '1', 'SPRING_DRAW', '1', '2019-02-01 15:57:21', null, null);
INSERT INTO `award_receive` VALUES ('29', '105471', '1', 'SPRING_DRAW', '1', '2019-02-01 17:09:57', null, null);
INSERT INTO `award_receive` VALUES ('30', '105473', '1', 'SPRING_DRAW', '1', '2019-02-01 17:34:07', null, null);
INSERT INTO `award_receive` VALUES ('31', '105478', '1', 'SPRING_DRAW', '1', '2019-02-01 21:28:08', null, null);
INSERT INTO `award_receive` VALUES ('32', '105482', '1', 'SPRING_DRAW', '1', '2019-02-02 00:16:43', null, null);
INSERT INTO `award_receive` VALUES ('33', '105483', '1', 'SPRING_DRAW', '1', '2019-02-02 01:36:25', null, null);
INSERT INTO `award_receive` VALUES ('34', '105484', '1', 'SPRING_DRAW', '1', '2019-02-02 01:40:55', null, null);
INSERT INTO `award_receive` VALUES ('35', '105486', '1', 'SPRING_DRAW', '1', '2019-02-02 08:04:37', null, null);
INSERT INTO `award_receive` VALUES ('36', '105488', '1', 'SPRING_DRAW', '1', '2019-02-02 11:28:50', null, null);
INSERT INTO `award_receive` VALUES ('37', '105490', '1', 'SPRING_DRAW', '1', '2019-02-02 11:42:26', null, null);
INSERT INTO `award_receive` VALUES ('38', '105491', '1', 'SPRING_DRAW', '1', '2019-02-02 11:44:42', null, null);
INSERT INTO `award_receive` VALUES ('39', '105492', '1', 'SPRING_DRAW', '1', '2019-02-02 13:24:36', null, null);
INSERT INTO `award_receive` VALUES ('40', '105497', '1', 'SPRING_DRAW', '1', '2019-02-02 17:09:00', null, null);
INSERT INTO `award_receive` VALUES ('41', '105439', '1', 'SPRING_DRAW', '1', '2019-02-02 17:34:09', null, null);
INSERT INTO `award_receive` VALUES ('42', '105501', '1', 'SPRING_DRAW', '1', '2019-02-02 19:58:50', null, null);
INSERT INTO `award_receive` VALUES ('43', '105503', '1', 'SPRING_DRAW', '1', '2019-02-02 20:22:26', null, null);
INSERT INTO `award_receive` VALUES ('44', '105505', '1', 'SPRING_DRAW', '1', '2019-02-02 20:46:40', null, null);
INSERT INTO `award_receive` VALUES ('45', '105510', '1', 'SPRING_DRAW', '1', '2019-02-03 00:04:39', null, null);
INSERT INTO `award_receive` VALUES ('46', '105512', '1', 'SPRING_DRAW', '1', '2019-02-03 01:32:51', null, null);
INSERT INTO `award_receive` VALUES ('47', '105281', '1', 'SPRING_DRAW', '1', '2019-02-03 08:43:49', null, null);
INSERT INTO `award_receive` VALUES ('48', '105517', '1', 'SPRING_DRAW', '1', '2019-02-03 09:22:55', null, null);
INSERT INTO `award_receive` VALUES ('49', '105518', '1', 'SPRING_DRAW', '1', '2019-02-03 10:25:23', null, null);
INSERT INTO `award_receive` VALUES ('50', '105519', '1', 'SPRING_DRAW', '1', '2019-02-03 10:40:20', null, null);
INSERT INTO `award_receive` VALUES ('51', '105520', '1', 'SPRING_DRAW', '1', '2019-02-03 10:48:17', null, null);
INSERT INTO `award_receive` VALUES ('52', '105523', '1', 'SPRING_DRAW', '1', '2019-02-03 11:16:57', null, null);
INSERT INTO `award_receive` VALUES ('53', '105525', '1', 'SPRING_DRAW', '1', '2019-02-03 12:50:55', null, null);
INSERT INTO `award_receive` VALUES ('54', '105526', '1', 'SPRING_DRAW', '1', '2019-02-03 12:55:45', null, null);
INSERT INTO `award_receive` VALUES ('55', '105527', '1', 'SPRING_DRAW', '1', '2019-02-03 12:56:20', null, null);
INSERT INTO `award_receive` VALUES ('56', '105529', '1', 'SPRING_DRAW', '1', '2019-02-03 14:19:21', null, null);
INSERT INTO `award_receive` VALUES ('57', '105530', '1', 'SPRING_DRAW', '1', '2019-02-03 15:38:43', null, null);
INSERT INTO `award_receive` VALUES ('58', '105532', '1', 'SPRING_DRAW', '1', '2019-02-03 16:25:09', null, null);
INSERT INTO `award_receive` VALUES ('59', '105533', '1', 'SPRING_DRAW', '1', '2019-02-03 17:57:24', null, null);
INSERT INTO `award_receive` VALUES ('60', '105534', '1', 'SPRING_DRAW', '1', '2019-02-03 18:03:32', null, null);
INSERT INTO `award_receive` VALUES ('61', '105536', '1', 'SPRING_DRAW', '1', '2019-02-03 20:06:06', null, null);
INSERT INTO `award_receive` VALUES ('62', '105539', '1', 'SPRING_DRAW', '1', '2019-02-03 23:28:50', null, null);
INSERT INTO `award_receive` VALUES ('63', '105540', '1', 'SPRING_DRAW', '1', '2019-02-03 23:47:25', null, null);
INSERT INTO `award_receive` VALUES ('64', '105543', '1', 'SPRING_DRAW', '1', '2019-02-04 00:17:12', null, null);
INSERT INTO `award_receive` VALUES ('65', '105545', '1', 'SPRING_DRAW', '1', '2019-02-04 02:33:05', null, null);
INSERT INTO `award_receive` VALUES ('66', '105546', '1', 'SPRING_DRAW', '1', '2019-02-04 04:18:51', null, null);
INSERT INTO `award_receive` VALUES ('67', '105549', '1', 'SPRING_DRAW', '1', '2019-02-04 06:06:50', null, null);
INSERT INTO `award_receive` VALUES ('68', '104574', '1', 'SPRING_DRAW', '1', '2019-02-04 11:04:44', null, null);
INSERT INTO `award_receive` VALUES ('69', '105555', '1', 'SPRING_DRAW', '1', '2019-02-04 17:24:02', null, null);
INSERT INTO `award_receive` VALUES ('70', '105558', '1', 'SPRING_DRAW', '1', '2019-02-04 18:31:08', null, null);
INSERT INTO `award_receive` VALUES ('71', '105547', '1', 'SPRING_DRAW', '1', '2019-02-04 22:03:45', null, null);
INSERT INTO `award_receive` VALUES ('72', '105562', '1', 'SPRING_DRAW', '1', '2019-02-04 23:23:04', null, null);
INSERT INTO `award_receive` VALUES ('73', '105566', '1', 'SPRING_DRAW', '1', '2019-02-05 00:58:17', null, null);
INSERT INTO `award_receive` VALUES ('74', '105568', '1', 'SPRING_DRAW', '1', '2019-02-05 02:01:10', null, null);
INSERT INTO `award_receive` VALUES ('75', '105567', '1', 'SPRING_DRAW', '1', '2019-02-05 02:06:34', null, null);
INSERT INTO `award_receive` VALUES ('76', '105569', '1', 'SPRING_DRAW', '1', '2019-02-05 04:33:32', null, null);
INSERT INTO `award_receive` VALUES ('77', '105572', '1', 'SPRING_DRAW', '1', '2019-02-05 10:32:32', null, null);
INSERT INTO `award_receive` VALUES ('78', '105574', '1', 'SPRING_DRAW', '1', '2019-02-05 12:47:45', null, null);
INSERT INTO `award_receive` VALUES ('79', '105578', '1', 'SPRING_DRAW', '1', '2019-02-05 16:47:44', null, null);
INSERT INTO `award_receive` VALUES ('80', '105582', '1', 'SPRING_DRAW', '1', '2019-02-05 21:36:57', null, null);
INSERT INTO `award_receive` VALUES ('81', '105588', '1', 'SPRING_DRAW', '1', '2019-02-06 02:40:44', null, null);
INSERT INTO `award_receive` VALUES ('82', '105591', '1', 'SPRING_DRAW', '1', '2019-02-06 07:18:54', null, null);
INSERT INTO `award_receive` VALUES ('83', '105593', '1', 'SPRING_DRAW', '1', '2019-02-06 17:28:57', null, null);
INSERT INTO `award_receive` VALUES ('84', '105579', '1', 'SPRING_DRAW', '1', '2019-02-06 20:25:56', null, null);
INSERT INTO `award_receive` VALUES ('85', '105600', '1', 'SPRING_DRAW', '1', '2019-02-06 21:57:21', null, null);
INSERT INTO `award_receive` VALUES ('86', '105604', '1', 'SPRING_DRAW', '1', '2019-02-07 01:36:44', null, null);
INSERT INTO `award_receive` VALUES ('87', '105607', '1', 'SPRING_DRAW', '1', '2019-02-07 06:56:05', null, null);
INSERT INTO `award_receive` VALUES ('88', '105608', '1', 'SPRING_DRAW', '1', '2019-02-07 07:44:08', null, null);
INSERT INTO `award_receive` VALUES ('89', '105609', '1', 'SPRING_DRAW', '1', '2019-02-07 09:49:53', null, null);
INSERT INTO `award_receive` VALUES ('90', '105610', '1', 'SPRING_DRAW', '1', '2019-02-07 10:40:33', null, null);
INSERT INTO `award_receive` VALUES ('91', '105611', '1', 'SPRING_DRAW', '1', '2019-02-07 10:56:44', null, null);
INSERT INTO `award_receive` VALUES ('93', '106581', '1', 'NEWUSER_500_BOOKMONEY', '1', '2019-02-27 17:12:37', null, null);
INSERT INTO `award_receive` VALUES ('94', '106582', '1', 'NEWUSER_500_BOOKMONEY', '1', '2019-02-27 17:22:49', null, null);
INSERT INTO `award_receive` VALUES ('95', '106585', '1', 'NEWUSER_500_BOOKMONEY', '1', '2019-02-27 17:26:34', null, null);
INSERT INTO `award_receive` VALUES ('96', '106586', '1', 'NEWUSER_500_BOOKMONEY', '1', '2019-02-27 17:29:15', null, null);
INSERT INTO `award_receive` VALUES ('97', '105292', '1', 'NEWUSER_500_BOOKMONEY', '1', '2019-02-27 17:29:54', null, null);
INSERT INTO `award_receive` VALUES ('98', '106293', '1', 'NEWUSER_500_BOOKMONEY', '1', '2019-02-27 17:41:39', null, null);
INSERT INTO `award_receive` VALUES ('99', '106609', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-27 18:14:11', null, null);
INSERT INTO `award_receive` VALUES ('100', '104574', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-27 19:44:35', null, null);
INSERT INTO `award_receive` VALUES ('101', '106685', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-27 22:33:28', null, null);
INSERT INTO `award_receive` VALUES ('102', '106702', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-27 23:34:08', null, null);
INSERT INTO `award_receive` VALUES ('103', '104567', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 00:16:25', null, null);
INSERT INTO `award_receive` VALUES ('104', '104560', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 00:26:11', null, null);
INSERT INTO `award_receive` VALUES ('105', '106730', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 01:32:29', null, null);
INSERT INTO `award_receive` VALUES ('106', '106733', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 01:40:46', null, null);
INSERT INTO `award_receive` VALUES ('107', '106746', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 06:08:35', null, null);
INSERT INTO `award_receive` VALUES ('108', '106771', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 12:02:27', null, null);
INSERT INTO `award_receive` VALUES ('109', '106777', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 12:50:44', null, null);
INSERT INTO `award_receive` VALUES ('110', '106796', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 14:43:25', null, null);
INSERT INTO `award_receive` VALUES ('111', '106808', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 16:15:10', null, null);
INSERT INTO `award_receive` VALUES ('112', '106815', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 17:08:04', null, null);
INSERT INTO `award_receive` VALUES ('113', '104555', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 18:24:42', null, null);
INSERT INTO `award_receive` VALUES ('114', '106830', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 18:39:05', null, null);
INSERT INTO `award_receive` VALUES ('115', '106833', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 18:42:17', null, null);
INSERT INTO `award_receive` VALUES ('116', '106834', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 18:43:41', null, null);
INSERT INTO `award_receive` VALUES ('117', '106870', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 21:08:31', null, null);
INSERT INTO `award_receive` VALUES ('118', '106074', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 21:53:40', null, null);
INSERT INTO `award_receive` VALUES ('119', '106884', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 21:54:06', null, null);
INSERT INTO `award_receive` VALUES ('120', '105441', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 22:17:02', null, null);
INSERT INTO `award_receive` VALUES ('121', '106896', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 22:32:00', null, null);
INSERT INTO `award_receive` VALUES ('122', '106902', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 22:43:36', null, null);
INSERT INTO `award_receive` VALUES ('123', '106909', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-02-28 22:57:20', null, null);
INSERT INTO `award_receive` VALUES ('124', '106929', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 00:19:01', null, null);
INSERT INTO `award_receive` VALUES ('125', '105629', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 02:03:14', null, null);
INSERT INTO `award_receive` VALUES ('126', '106949', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 08:23:26', null, null);
INSERT INTO `award_receive` VALUES ('127', '106951', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 08:43:34', null, null);
INSERT INTO `award_receive` VALUES ('128', '106961', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 09:29:30', null, null);
INSERT INTO `award_receive` VALUES ('129', '106977', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 11:00:33', null, null);
INSERT INTO `award_receive` VALUES ('130', '106999', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 13:03:46', null, null);
INSERT INTO `award_receive` VALUES ('131', '107027', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 17:06:31', null, null);
INSERT INTO `award_receive` VALUES ('132', '107045', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 17:57:53', null, null);
INSERT INTO `award_receive` VALUES ('133', '107088', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 21:04:54', null, null);
INSERT INTO `award_receive` VALUES ('134', '107129', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-01 23:16:06', null, null);
INSERT INTO `award_receive` VALUES ('135', '107160', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 03:13:51', null, null);
INSERT INTO `award_receive` VALUES ('136', '107165', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 05:14:38', null, null);
INSERT INTO `award_receive` VALUES ('137', '107203', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 10:18:05', null, null);
INSERT INTO `award_receive` VALUES ('138', '107217', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 11:40:11', null, null);
INSERT INTO `award_receive` VALUES ('139', '105637', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 13:26:38', null, null);
INSERT INTO `award_receive` VALUES ('140', '107243', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 13:53:12', null, null);
INSERT INTO `award_receive` VALUES ('141', '107248', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 14:05:53', null, null);
INSERT INTO `award_receive` VALUES ('142', '107249', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 14:06:45', null, null);
INSERT INTO `award_receive` VALUES ('143', '107258', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 14:49:21', null, null);
INSERT INTO `award_receive` VALUES ('144', '107260', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 14:50:27', null, null);
INSERT INTO `award_receive` VALUES ('145', '107298', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 16:56:53', null, null);
INSERT INTO `award_receive` VALUES ('146', '107314', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 18:23:41', null, null);
INSERT INTO `award_receive` VALUES ('147', '107340', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 20:00:49', null, null);
INSERT INTO `award_receive` VALUES ('148', '107419', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 22:27:40', null, null);
INSERT INTO `award_receive` VALUES ('149', '107440', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 22:51:39', null, null);
INSERT INTO `award_receive` VALUES ('150', '107440', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 22:51:39', null, null);
INSERT INTO `award_receive` VALUES ('151', '107448', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 23:02:17', null, null);
INSERT INTO `award_receive` VALUES ('152', '107456', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-02 23:09:23', null, null);
INSERT INTO `award_receive` VALUES ('153', '106246', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 00:44:21', null, null);
INSERT INTO `award_receive` VALUES ('154', '106298', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 03:36:48', null, null);
INSERT INTO `award_receive` VALUES ('155', '107542', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 08:24:26', null, null);
INSERT INTO `award_receive` VALUES ('156', '107581', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 12:16:47', null, null);
INSERT INTO `award_receive` VALUES ('157', '107610', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 14:16:34', null, null);
INSERT INTO `award_receive` VALUES ('158', '107635', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 15:17:06', null, null);
INSERT INTO `award_receive` VALUES ('159', '107634', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 15:17:08', null, null);
INSERT INTO `award_receive` VALUES ('160', '107641', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 15:32:35', null, null);
INSERT INTO `award_receive` VALUES ('161', '107674', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 17:58:05', null, null);
INSERT INTO `award_receive` VALUES ('162', '107685', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 18:17:53', null, null);
INSERT INTO `award_receive` VALUES ('163', '107732', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 20:42:05', null, null);
INSERT INTO `award_receive` VALUES ('164', '107757', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 21:22:34', null, null);
INSERT INTO `award_receive` VALUES ('165', '107744', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 21:40:05', null, null);
INSERT INTO `award_receive` VALUES ('166', '107775', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 21:58:18', null, null);
INSERT INTO `award_receive` VALUES ('167', '107799', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 22:39:52', null, null);
INSERT INTO `award_receive` VALUES ('168', '107815', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 23:07:43', null, null);
INSERT INTO `award_receive` VALUES ('169', '107827', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-03 23:34:08', null, null);
INSERT INTO `award_receive` VALUES ('170', '107736', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 06:34:50', null, null);
INSERT INTO `award_receive` VALUES ('171', '107862', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 07:50:38', null, null);
INSERT INTO `award_receive` VALUES ('172', '107877', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 11:47:59', null, null);
INSERT INTO `award_receive` VALUES ('173', '107893', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 13:13:09', null, null);
INSERT INTO `award_receive` VALUES ('174', '107902', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 14:59:52', null, null);
INSERT INTO `award_receive` VALUES ('175', '107919', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 16:51:51', null, null);
INSERT INTO `award_receive` VALUES ('176', '1065721', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 18:44:29', null, null);
INSERT INTO `award_receive` VALUES ('177', '107934', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 18:47:58', null, null);
INSERT INTO `award_receive` VALUES ('178', '107939', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 19:12:51', null, null);
INSERT INTO `award_receive` VALUES ('179', '104552', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 20:21:27', null, null);
INSERT INTO `award_receive` VALUES ('180', '104562', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 20:28:48', null, null);
INSERT INTO `award_receive` VALUES ('181', '104557', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-04 20:58:18', null, null);
INSERT INTO `award_receive` VALUES ('182', '108096', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-05 11:27:07', null, null);
INSERT INTO `award_receive` VALUES ('183', '108121', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-05 14:45:22', null, null);
INSERT INTO `award_receive` VALUES ('184', '108256', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-06 10:11:01', null, null);
INSERT INTO `award_receive` VALUES ('185', '108303', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-06 15:59:57', null, null);
INSERT INTO `award_receive` VALUES ('186', '108305', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-06 16:14:18', null, null);
INSERT INTO `award_receive` VALUES ('187', '108328', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-06 20:03:20', null, null);
INSERT INTO `award_receive` VALUES ('188', '108399', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-07 04:48:11', null, null);
INSERT INTO `award_receive` VALUES ('189', '108401', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-07 05:40:45', null, null);
INSERT INTO `award_receive` VALUES ('190', '108422', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-07 11:29:54', null, null);
INSERT INTO `award_receive` VALUES ('191', '104565', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-07 17:27:13', null, null);
INSERT INTO `award_receive` VALUES ('192', '107289', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-07 19:41:46', null, null);
INSERT INTO `award_receive` VALUES ('193', '108538', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-07 21:55:17', null, null);
INSERT INTO `award_receive` VALUES ('194', '105242', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-08 12:10:51', null, null);
INSERT INTO `award_receive` VALUES ('195', '108615', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-08 12:57:53', null, null);
INSERT INTO `award_receive` VALUES ('196', '108668', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-08 18:26:37', null, null);
INSERT INTO `award_receive` VALUES ('197', '108844', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-09 13:09:01', null, null);
INSERT INTO `award_receive` VALUES ('198', '109003', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-10 11:00:44', null, null);
INSERT INTO `award_receive` VALUES ('199', '109032', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-10 12:09:29', null, null);
INSERT INTO `award_receive` VALUES ('200', '109167', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 05:52:18', null, null);
INSERT INTO `award_receive` VALUES ('201', '106319', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 06:51:05', null, null);
INSERT INTO `award_receive` VALUES ('202', '109179', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 10:35:01', null, null);
INSERT INTO `award_receive` VALUES ('203', '109299', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 19:08:17', null, null);
INSERT INTO `award_receive` VALUES ('204', '109310', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 19:30:34', null, null);
INSERT INTO `award_receive` VALUES ('205', '106254', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 19:57:56', null, null);
INSERT INTO `award_receive` VALUES ('206', '109400', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 22:11:54', null, null);
INSERT INTO `award_receive` VALUES ('207', '109191', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 22:20:41', null, null);
INSERT INTO `award_receive` VALUES ('208', '109427', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 22:49:22', null, null);
INSERT INTO `award_receive` VALUES ('209', '109432', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 22:53:55', null, null);
INSERT INTO `award_receive` VALUES ('210', '109435', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-11 23:07:17', null, null);
INSERT INTO `award_receive` VALUES ('211', '109449', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 00:48:32', null, null);
INSERT INTO `award_receive` VALUES ('212', '109463', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 06:06:20', null, null);
INSERT INTO `award_receive` VALUES ('213', '106053', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 06:50:34', null, null);
INSERT INTO `award_receive` VALUES ('214', '105157', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 09:45:41', null, null);
INSERT INTO `award_receive` VALUES ('215', '109547', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 11:54:04', null, null);
INSERT INTO `award_receive` VALUES ('216', '109561', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 13:10:13', null, null);
INSERT INTO `award_receive` VALUES ('217', '109614', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 17:54:15', null, null);
INSERT INTO `award_receive` VALUES ('218', '109626', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 19:10:01', null, null);
INSERT INTO `award_receive` VALUES ('219', '109738', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 22:25:28', null, null);
INSERT INTO `award_receive` VALUES ('220', '109744', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 22:33:47', null, null);
INSERT INTO `award_receive` VALUES ('221', '109754', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 22:51:38', null, null);
INSERT INTO `award_receive` VALUES ('222', '109757', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 22:55:23', null, null);
INSERT INTO `award_receive` VALUES ('223', '109772', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-12 23:31:49', null, null);
INSERT INTO `award_receive` VALUES ('224', '109795', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-13 01:57:59', null, null);
INSERT INTO `award_receive` VALUES ('225', '109808', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-13 06:31:36', null, null);
INSERT INTO `award_receive` VALUES ('226', '109839', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-13 12:17:53', null, null);
INSERT INTO `award_receive` VALUES ('227', '109858', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-13 12:24:56', null, null);
INSERT INTO `award_receive` VALUES ('228', '109931', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-13 17:17:31', null, null);
INSERT INTO `award_receive` VALUES ('229', '108290', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-13 21:43:01', null, null);
INSERT INTO `award_receive` VALUES ('230', '110078', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-13 22:12:02', null, null);
INSERT INTO `award_receive` VALUES ('231', '110133', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 00:15:50', null, null);
INSERT INTO `award_receive` VALUES ('232', '110156', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 06:14:50', null, null);
INSERT INTO `award_receive` VALUES ('233', '110173', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 07:45:43', null, null);
INSERT INTO `award_receive` VALUES ('234', '110195', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 09:44:53', null, null);
INSERT INTO `award_receive` VALUES ('235', '110249', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 13:04:21', null, null);
INSERT INTO `award_receive` VALUES ('236', '110298', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 16:30:48', null, null);
INSERT INTO `award_receive` VALUES ('237', '110307', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 16:37:40', null, null);
INSERT INTO `award_receive` VALUES ('238', '110315', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 17:03:15', null, null);
INSERT INTO `award_receive` VALUES ('239', '110380', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 20:19:36', null, null);
INSERT INTO `award_receive` VALUES ('240', '110393', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 20:45:03', null, null);
INSERT INTO `award_receive` VALUES ('241', '110400', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-14 20:52:24', null, null);
INSERT INTO `award_receive` VALUES ('242', '110506', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 00:24:41', null, null);
INSERT INTO `award_receive` VALUES ('243', '110534', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 07:38:17', null, null);
INSERT INTO `award_receive` VALUES ('244', '110563', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 09:22:28', null, null);
INSERT INTO `award_receive` VALUES ('245', '110012', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 10:43:35', null, null);
INSERT INTO `award_receive` VALUES ('246', '110599', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 13:14:33', null, null);
INSERT INTO `award_receive` VALUES ('247', '110618', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 14:26:18', null, null);
INSERT INTO `award_receive` VALUES ('248', '110633', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 15:30:18', null, null);
INSERT INTO `award_receive` VALUES ('249', '110663', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 17:03:24', null, null);
INSERT INTO `award_receive` VALUES ('250', '110672', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 17:30:22', null, null);
INSERT INTO `award_receive` VALUES ('251', '110703', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 18:30:48', null, null);
INSERT INTO `award_receive` VALUES ('252', '110728', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 19:11:09', null, null);
INSERT INTO `award_receive` VALUES ('253', '110821', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 21:08:37', null, null);
INSERT INTO `award_receive` VALUES ('254', '110841', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 21:37:32', null, null);
INSERT INTO `award_receive` VALUES ('255', '110894', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 22:49:27', null, null);
INSERT INTO `award_receive` VALUES ('256', '110910', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-15 23:14:10', null, null);
INSERT INTO `award_receive` VALUES ('257', '110964', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 00:15:51', null, null);
INSERT INTO `award_receive` VALUES ('258', '110974', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 00:47:31', null, null);
INSERT INTO `award_receive` VALUES ('259', '111061', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 09:29:02', null, null);
INSERT INTO `award_receive` VALUES ('260', '110731', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 09:33:47', null, null);
INSERT INTO `award_receive` VALUES ('261', '111124', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 12:16:15', null, null);
INSERT INTO `award_receive` VALUES ('262', '111144', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 12:42:15', null, null);
INSERT INTO `award_receive` VALUES ('263', '110146', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 12:50:14', null, null);
INSERT INTO `award_receive` VALUES ('264', '111300', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 17:19:52', null, null);
INSERT INTO `award_receive` VALUES ('265', '111403', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 19:20:43', null, null);
INSERT INTO `award_receive` VALUES ('266', '111419', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 19:40:53', null, null);
INSERT INTO `award_receive` VALUES ('267', '111424', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 19:52:33', null, null);
INSERT INTO `award_receive` VALUES ('268', '111444', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 20:29:23', null, null);
INSERT INTO `award_receive` VALUES ('269', '111436', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 20:30:20', null, null);
INSERT INTO `award_receive` VALUES ('270', '111467', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-16 21:10:54', null, null);
INSERT INTO `award_receive` VALUES ('271', '111629', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 11:43:14', null, null);
INSERT INTO `award_receive` VALUES ('272', '111631', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 11:45:18', null, null);
INSERT INTO `award_receive` VALUES ('273', '106178', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 15:42:22', null, null);
INSERT INTO `award_receive` VALUES ('274', '111729', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 16:08:33', null, null);
INSERT INTO `award_receive` VALUES ('275', '111854', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 19:52:25', null, null);
INSERT INTO `award_receive` VALUES ('276', '111887', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 20:30:15', null, null);
INSERT INTO `award_receive` VALUES ('277', '111910', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 20:57:15', null, null);
INSERT INTO `award_receive` VALUES ('278', '111921', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 21:13:21', null, null);
INSERT INTO `award_receive` VALUES ('279', '111998', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 22:45:13', null, null);
INSERT INTO `award_receive` VALUES ('280', '112035', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 23:41:27', null, null);
INSERT INTO `award_receive` VALUES ('281', '112042', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-17 23:49:12', null, null);
INSERT INTO `award_receive` VALUES ('282', '112110', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-18 09:12:36', null, null);
INSERT INTO `award_receive` VALUES ('283', '112148', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-18 13:35:36', null, null);
INSERT INTO `award_receive` VALUES ('284', '112235', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-18 19:12:12', null, null);
INSERT INTO `award_receive` VALUES ('285', '112256', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-18 19:52:25', null, null);
INSERT INTO `award_receive` VALUES ('286', '112263', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-18 20:11:43', null, null);
INSERT INTO `award_receive` VALUES ('287', '112307', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-18 21:53:27', null, null);
INSERT INTO `award_receive` VALUES ('288', '112408', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 07:16:00', null, null);
INSERT INTO `award_receive` VALUES ('289', '112437', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 09:17:31', null, null);
INSERT INTO `award_receive` VALUES ('290', '112460', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 10:58:40', null, null);
INSERT INTO `award_receive` VALUES ('291', '112481', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 12:20:33', null, null);
INSERT INTO `award_receive` VALUES ('292', '112511', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 14:26:28', null, null);
INSERT INTO `award_receive` VALUES ('293', '112529', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 15:10:36', null, null);
INSERT INTO `award_receive` VALUES ('294', '112533', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 15:33:06', null, null);
INSERT INTO `award_receive` VALUES ('295', '112519', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 15:33:38', null, null);
INSERT INTO `award_receive` VALUES ('296', '112536', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 15:42:24', null, null);
INSERT INTO `award_receive` VALUES ('297', '112542', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 16:05:16', null, null);
INSERT INTO `award_receive` VALUES ('298', '112734', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 21:32:57', null, null);
INSERT INTO `award_receive` VALUES ('299', '112740', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 21:36:59', null, null);
INSERT INTO `award_receive` VALUES ('300', '112766', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 21:56:52', null, null);
INSERT INTO `award_receive` VALUES ('301', '112794', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 22:26:04', null, null);
INSERT INTO `award_receive` VALUES ('302', '112827', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-19 22:51:02', null, null);
INSERT INTO `award_receive` VALUES ('303', '112898', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 02:34:32', null, null);
INSERT INTO `award_receive` VALUES ('304', '112832', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 06:04:45', null, null);
INSERT INTO `award_receive` VALUES ('305', '112967', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 09:14:23', null, null);
INSERT INTO `award_receive` VALUES ('306', '113047', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 13:20:59', null, null);
INSERT INTO `award_receive` VALUES ('307', '113142', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 18:13:14', null, null);
INSERT INTO `award_receive` VALUES ('308', '110055', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 20:38:00', null, null);
INSERT INTO `award_receive` VALUES ('309', '113252', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 20:58:08', null, null);
INSERT INTO `award_receive` VALUES ('310', '113260', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 21:05:08', null, null);
INSERT INTO `award_receive` VALUES ('311', '113266', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 21:09:38', null, null);
INSERT INTO `award_receive` VALUES ('312', '113280', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 21:25:35', null, null);
INSERT INTO `award_receive` VALUES ('313', '108977', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 22:03:17', null, null);
INSERT INTO `award_receive` VALUES ('314', '113327', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-20 22:19:44', null, null);
INSERT INTO `award_receive` VALUES ('315', '113377', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 01:02:07', null, null);
INSERT INTO `award_receive` VALUES ('316', '112363', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 02:16:59', null, null);
INSERT INTO `award_receive` VALUES ('317', '113401', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 05:42:00', null, null);
INSERT INTO `award_receive` VALUES ('318', '113437', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 09:03:26', null, null);
INSERT INTO `award_receive` VALUES ('319', '113463', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 10:41:25', null, null);
INSERT INTO `award_receive` VALUES ('320', '110574', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 13:44:08', null, null);
INSERT INTO `award_receive` VALUES ('321', '113569', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 18:14:58', null, null);
INSERT INTO `award_receive` VALUES ('322', '113609', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 19:14:37', null, null);
INSERT INTO `award_receive` VALUES ('323', '113670', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 20:48:41', null, null);
INSERT INTO `award_receive` VALUES ('324', '113707', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 21:19:00', null, null);
INSERT INTO `award_receive` VALUES ('325', '113758', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-21 22:09:17', null, null);
INSERT INTO `award_receive` VALUES ('326', '114108', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-22 19:19:11', null, null);
INSERT INTO `award_receive` VALUES ('327', '104559', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-22 20:22:13', 'Android', null);
INSERT INTO `award_receive` VALUES ('328', '114387', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-22 21:01:29', 'Android', '107');
INSERT INTO `award_receive` VALUES ('329', '114433', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-23 00:41:34', 'Android', '107');
INSERT INTO `award_receive` VALUES ('330', '114438', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-23 01:12:05', 'Android', '107');
INSERT INTO `award_receive` VALUES ('331', '114647', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-23 17:18:22', 'Android', '107');
INSERT INTO `award_receive` VALUES ('332', '114650', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-23 17:22:45', 'Android', '107');
INSERT INTO `award_receive` VALUES ('333', '114710', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-23 21:31:51', 'Android', '107');
INSERT INTO `award_receive` VALUES ('334', '114811', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-24 09:32:56', 'Android', '107');
INSERT INTO `award_receive` VALUES ('335', '114848', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-24 10:46:20', 'Android', '103');
INSERT INTO `award_receive` VALUES ('336', '114912', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-24 16:34:19', 'Android', '107');
INSERT INTO `award_receive` VALUES ('337', '114979', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-24 18:56:46', 'Android', '107');
INSERT INTO `award_receive` VALUES ('338', '114980', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-24 19:00:49', 'Android', '107');
INSERT INTO `award_receive` VALUES ('339', '114985', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-24 19:03:30', 'Android', '103');
INSERT INTO `award_receive` VALUES ('340', '115195', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-25 14:10:16', 'Android', '107');
INSERT INTO `award_receive` VALUES ('341', '115212', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-25 14:29:46', 'Android', '107');
INSERT INTO `award_receive` VALUES ('342', '104562', '1', 'activity_1553496369325', '3', '2019-03-25 14:46:27', 'Android', null);
INSERT INTO `award_receive` VALUES ('343', '104549', '1', 'activity_1553496369325', '3', '2019-03-25 17:51:08', 'Android', null);
INSERT INTO `award_receive` VALUES ('344', '104806', '1', 'activity_1553496369325', '3', '2019-03-25 19:31:36', 'Android', null);
INSERT INTO `award_receive` VALUES ('345', '115266', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-25 19:54:52', 'Android', '110');
INSERT INTO `award_receive` VALUES ('346', '104574', '1', 'activity_1553496369325', '3', '2019-03-25 21:57:55', 'Android', null);
INSERT INTO `award_receive` VALUES ('347', '115314', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 00:28:20', 'Android', '107');
INSERT INTO `award_receive` VALUES ('348', '115339', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 07:06:24', 'Android', '107');
INSERT INTO `award_receive` VALUES ('349', '111040', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 13:55:34', 'Android', '107');
INSERT INTO `award_receive` VALUES ('350', '104562', '1', 'activity_1553496369325', '3', '2019-03-26 14:02:43', 'Android', null);
INSERT INTO `award_receive` VALUES ('351', '115452', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 17:51:42', 'Android', '107');
INSERT INTO `award_receive` VALUES ('352', '115454', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 17:57:20', 'Android', '107');
INSERT INTO `award_receive` VALUES ('353', '115479', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 20:06:51', 'Android', '107');
INSERT INTO `award_receive` VALUES ('354', '115521', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 20:27:22', 'Android', '107');
INSERT INTO `award_receive` VALUES ('355', '115528', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 20:36:32', 'Android', '107');
INSERT INTO `award_receive` VALUES ('356', '109210', '1', 'activity_1553496369325', '3', '2019-03-26 20:42:35', 'IOS', null);
INSERT INTO `award_receive` VALUES ('357', '115538', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 20:44:21', 'Android', '104');
INSERT INTO `award_receive` VALUES ('358', '115543', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 20:47:34', 'Android', '100');
INSERT INTO `award_receive` VALUES ('359', '115544', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 20:47:51', 'Android', '100');
INSERT INTO `award_receive` VALUES ('360', '115547', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 20:50:10', 'Android', '107');
INSERT INTO `award_receive` VALUES ('361', '115548', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 20:54:19', 'Android', '100');
INSERT INTO `award_receive` VALUES ('362', '115552', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 20:54:32', 'Android', '100');
INSERT INTO `award_receive` VALUES ('363', '115556', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 20:57:29', 'Android', '107');
INSERT INTO `award_receive` VALUES ('364', '115561', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 21:02:34', 'Android', '107');
INSERT INTO `award_receive` VALUES ('365', '113363', '1', 'activity_1553496369325', '3', '2019-03-26 21:53:59', 'Android', '107');
INSERT INTO `award_receive` VALUES ('366', '115663', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 22:14:31', 'Android', '107');
INSERT INTO `award_receive` VALUES ('367', '115690', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 22:37:58', 'Android', '107');
INSERT INTO `award_receive` VALUES ('368', '115697', '1', 'activity_1553496369325', '3', '2019-03-26 22:43:57', 'Android', '107');
INSERT INTO `award_receive` VALUES ('369', '105266', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 23:30:18', 'Android', '102');
INSERT INTO `award_receive` VALUES ('370', '104644', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-26 23:38:47', 'Android', null);
INSERT INTO `award_receive` VALUES ('371', '105266', '1', 'activity_1553496369325', '3', '2019-03-26 23:40:25', 'Android', '102');
INSERT INTO `award_receive` VALUES ('372', '104644', '1', 'activity_1553496369325', '3', '2019-03-27 00:39:00', 'Android', null);
INSERT INTO `award_receive` VALUES ('373', '106611', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 04:00:38', 'Android', 'test');
INSERT INTO `award_receive` VALUES ('374', '106611', '1', 'activity_1553496369325', '3', '2019-03-27 04:02:08', 'Android', 'test');
INSERT INTO `award_receive` VALUES ('375', '115750', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 04:08:03', 'Android', '107');
INSERT INTO `award_receive` VALUES ('376', '115043', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 08:11:02', 'Android', '107');
INSERT INTO `award_receive` VALUES ('377', '115872', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 13:44:08', 'Android', '107');
INSERT INTO `award_receive` VALUES ('378', '104574', '1', 'activity_1553496369325', '3', '2019-03-27 14:05:16', 'Android', null);
INSERT INTO `award_receive` VALUES ('379', '104549', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 14:11:15', 'Android', null);
INSERT INTO `award_receive` VALUES ('380', '114666', '1', 'activity_1553496369325', '3', '2019-03-27 15:05:59', 'Android', '107');
INSERT INTO `award_receive` VALUES ('381', '115901', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 15:51:11', 'Android', '102');
INSERT INTO `award_receive` VALUES ('382', '115902', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 15:53:12', 'Android', '102');
INSERT INTO `award_receive` VALUES ('383', '115904', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 15:55:28', 'Android', '102');
INSERT INTO `award_receive` VALUES ('384', '107059', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 16:25:19', 'Android', '107');
INSERT INTO `award_receive` VALUES ('385', '115926', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 16:33:30', 'Android', '107');
INSERT INTO `award_receive` VALUES ('386', '115934', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 16:54:32', 'Android', '107');
INSERT INTO `award_receive` VALUES ('387', '104555', '1', 'activity_1553496369325', '3', '2019-03-27 17:10:12', 'Android', null);
INSERT INTO `award_receive` VALUES ('388', '115978', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 18:34:42', 'Android', '107');
INSERT INTO `award_receive` VALUES ('389', '116047', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-27 22:14:54', 'Android', '107');
INSERT INTO `award_receive` VALUES ('390', '116119', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-28 09:55:28', 'Android', '103');
INSERT INTO `award_receive` VALUES ('391', '116174', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-28 14:56:22', 'Android', '107');
INSERT INTO `award_receive` VALUES ('392', '116205', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-28 17:18:08', 'Android', '107');
INSERT INTO `award_receive` VALUES ('393', '116225', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-28 18:18:49', 'Android', '107');
INSERT INTO `award_receive` VALUES ('394', '116247', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-28 19:10:23', 'Android', '107');
INSERT INTO `award_receive` VALUES ('395', '116268', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-28 19:52:42', 'Android', '107');
INSERT INTO `award_receive` VALUES ('396', '111274', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-28 23:10:16', 'Android', '107');
INSERT INTO `award_receive` VALUES ('397', '116345', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-29 00:47:34', 'Android', '107');
INSERT INTO `award_receive` VALUES ('398', '116348', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-29 02:24:55', 'Android', '107');
INSERT INTO `award_receive` VALUES ('399', '116355', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-29 04:37:53', 'Android', '107');
INSERT INTO `award_receive` VALUES ('400', '116144', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-29 07:44:57', 'Android', '107');
INSERT INTO `award_receive` VALUES ('401', '116375', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-29 09:31:00', 'Android', '107');
INSERT INTO `award_receive` VALUES ('402', '116377', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-29 10:09:25', 'Android', '107');
INSERT INTO `award_receive` VALUES ('403', '113011', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-29 18:20:29', 'Android', '107');
INSERT INTO `award_receive` VALUES ('404', '116548', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-29 19:56:53', 'Android', '107');
INSERT INTO `award_receive` VALUES ('405', '116587', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-29 21:39:00', 'Android', '107');
INSERT INTO `award_receive` VALUES ('406', '116600', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-29 22:30:39', 'Android', '107');
INSERT INTO `award_receive` VALUES ('407', '116637', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-30 05:04:55', 'Android', '107');
INSERT INTO `award_receive` VALUES ('408', '116717', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-30 11:15:16', 'Android', '107');
INSERT INTO `award_receive` VALUES ('409', '116723', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-30 11:45:59', 'Android', '102');
INSERT INTO `award_receive` VALUES ('410', '116778', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-30 17:05:37', 'Android', '103');
INSERT INTO `award_receive` VALUES ('411', '116818', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-30 20:23:50', 'Android', '103');
INSERT INTO `award_receive` VALUES ('412', '116836', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-30 21:10:37', 'Android', '107');
INSERT INTO `award_receive` VALUES ('413', '116852', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-30 22:30:38', 'Android', '107');
INSERT INTO `award_receive` VALUES ('414', '116870', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-31 01:11:48', 'Android', '107');
INSERT INTO `award_receive` VALUES ('415', '116878', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-31 04:48:42', 'Android', '103');
INSERT INTO `award_receive` VALUES ('416', '116894', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-31 07:31:24', 'Android', '107');
INSERT INTO `award_receive` VALUES ('417', '106863', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-31 10:37:06', 'Android', '107');
INSERT INTO `award_receive` VALUES ('418', '117005', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-31 16:16:53', 'Android', '103');
INSERT INTO `award_receive` VALUES ('419', '117099', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-03-31 23:36:29', 'Android', '107');
INSERT INTO `award_receive` VALUES ('420', '117125', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 06:53:55', 'Android', '107');
INSERT INTO `award_receive` VALUES ('421', '117144', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 09:28:16', 'Android', '107');
INSERT INTO `award_receive` VALUES ('422', '105266', '1', 'activity_1553496369325', '3', '2019-04-01 09:50:08', 'Android', '102');
INSERT INTO `award_receive` VALUES ('423', '117166', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 12:00:12', 'Android', '102');
INSERT INTO `award_receive` VALUES ('424', '116074', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 13:23:22', 'Android', '107');
INSERT INTO `award_receive` VALUES ('425', '104562', '1', 'activity_1553496369325', '3', '2019-04-01 16:07:13', 'Android', null);
INSERT INTO `award_receive` VALUES ('426', '109210', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 16:45:45', 'IOS', null);
INSERT INTO `award_receive` VALUES ('427', '111162', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 17:47:30', 'Android', '107');
INSERT INTO `award_receive` VALUES ('428', '117290', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 19:53:20', 'Android', '107');
INSERT INTO `award_receive` VALUES ('429', '115903', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 21:21:56', 'Android', '103');
INSERT INTO `award_receive` VALUES ('430', '117329', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 22:19:32', 'Android', '103');
INSERT INTO `award_receive` VALUES ('431', '112752', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 23:01:17', 'Android', '107');
INSERT INTO `award_receive` VALUES ('432', '117345', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-01 23:34:24', 'Android', '107');
INSERT INTO `award_receive` VALUES ('433', '114912', '1', 'activity_1553496369325', '3', '2019-04-02 04:02:39', 'Android', '107');
INSERT INTO `award_receive` VALUES ('434', '117398', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-02 09:40:14', 'Android', '107');
INSERT INTO `award_receive` VALUES ('435', '117405', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-02 10:10:52', 'Android', '107');
INSERT INTO `award_receive` VALUES ('436', '117463', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-02 13:48:22', 'Android', '107');
INSERT INTO `award_receive` VALUES ('437', '117225', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-02 14:14:52', 'Android', '100');
INSERT INTO `award_receive` VALUES ('438', '117225', '1', 'activity_1553496369325', '3', '2019-04-02 14:22:18', 'Android', '100');
INSERT INTO `award_receive` VALUES ('439', '116896', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-02 16:19:41', 'Android', '107');
INSERT INTO `award_receive` VALUES ('440', '104563', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-02 17:15:47', 'Android', null);
INSERT INTO `award_receive` VALUES ('441', '117549', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-03 00:37:46', 'Android', '107');
INSERT INTO `award_receive` VALUES ('442', '117596', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-03 09:29:38', 'Android', '107');
INSERT INTO `award_receive` VALUES ('443', '104562', '1', 'activity_1553496369325', '3', '2019-04-03 15:16:38', 'Android', null);
INSERT INTO `award_receive` VALUES ('444', '117683', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-03 16:24:34', 'Android', '107');
INSERT INTO `award_receive` VALUES ('445', '117695', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-03 17:12:18', 'Android', '107');
INSERT INTO `award_receive` VALUES ('446', '114685', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-03 18:02:15', 'Android', '103');
INSERT INTO `award_receive` VALUES ('447', '117721', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-03 19:19:52', 'Android', '109');
INSERT INTO `award_receive` VALUES ('448', '117731', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-03 19:49:58', 'Android', '107');
INSERT INTO `award_receive` VALUES ('449', '117781', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-03 22:13:28', 'Android', '102');
INSERT INTO `award_receive` VALUES ('450', '117796', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-03 23:42:29', 'Android', '107');
INSERT INTO `award_receive` VALUES ('451', '117831', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-04 08:19:16', 'Android', '107');
INSERT INTO `award_receive` VALUES ('452', '117835', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-04 08:36:16', 'Android', '107');
INSERT INTO `award_receive` VALUES ('453', '117575', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-04 08:46:45', 'Android', '102');
INSERT INTO `award_receive` VALUES ('454', '117899', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-04 14:21:57', 'Android', '107');
INSERT INTO `award_receive` VALUES ('455', '117907', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-04 16:15:35', 'Android', '107');
INSERT INTO `award_receive` VALUES ('456', '117925', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-04 18:28:46', 'Android', '107');
INSERT INTO `award_receive` VALUES ('457', '117952', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-04 20:19:46', 'Android', '103');
INSERT INTO `award_receive` VALUES ('458', '117995', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-04 23:38:51', 'Android', '107');
INSERT INTO `award_receive` VALUES ('459', '118003', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-05 01:15:19', 'Android', '103');
INSERT INTO `award_receive` VALUES ('460', '118013', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-05 06:45:10', 'Android', '107');
INSERT INTO `award_receive` VALUES ('461', '118026', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-05 08:28:20', 'Android', '107');
INSERT INTO `award_receive` VALUES ('462', '109704', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-05 12:16:53', 'Android', '107');
INSERT INTO `award_receive` VALUES ('463', '118057', '1', 'activity_1553496369325', '3', '2019-04-05 12:26:21', 'Android', '107');
INSERT INTO `award_receive` VALUES ('464', '118068', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-05 14:45:15', 'Android', '107');
INSERT INTO `award_receive` VALUES ('465', '118078', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-05 17:29:43', 'Android', '107');
INSERT INTO `award_receive` VALUES ('466', '117900', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-05 18:39:55', 'Android', '102');
INSERT INTO `award_receive` VALUES ('467', '118134', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-06 00:11:33', 'Android', '107');
INSERT INTO `award_receive` VALUES ('468', '111588', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-06 19:11:11', 'Android', '107');
INSERT INTO `award_receive` VALUES ('469', '118225', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-06 20:32:11', 'Android', '107');
INSERT INTO `award_receive` VALUES ('470', '118183', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-06 21:39:04', 'Android', '107');
INSERT INTO `award_receive` VALUES ('471', '118003', '1', 'activity_1553496369325', '3', '2019-04-07 01:08:35', 'Android', '103');
INSERT INTO `award_receive` VALUES ('472', '118274', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-07 08:03:07', 'Android', '103');
INSERT INTO `award_receive` VALUES ('473', '116770', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-07 08:38:11', 'Android', '107');
INSERT INTO `award_receive` VALUES ('474', '104806', '1', 'activity_1553496369325', '3', '2019-04-07 14:37:16', 'Android', null);
INSERT INTO `award_receive` VALUES ('475', '117863', '1', 'activity_1553496369325', '3', '2019-04-07 17:22:58', 'IOS', '200');
INSERT INTO `award_receive` VALUES ('476', '105060', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-07 21:12:32', 'Android', '102');
INSERT INTO `award_receive` VALUES ('477', '118369', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-07 23:38:28', 'Android', '104');
INSERT INTO `award_receive` VALUES ('478', '118206', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-08 08:24:43', 'Android', '103');
INSERT INTO `award_receive` VALUES ('479', '105060', '1', 'activity_1553496369325', '3', '2019-04-08 17:08:45', 'Android', '102');
INSERT INTO `award_receive` VALUES ('480', '118428', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-08 20:46:36', 'Android', '103');
INSERT INTO `award_receive` VALUES ('481', '118504', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-09 16:31:51', 'Android', '110');
INSERT INTO `award_receive` VALUES ('482', '104562', '1', 'activity_1553496369325', '3', '2019-04-09 17:22:17', 'Android', null);
INSERT INTO `award_receive` VALUES ('483', '118552', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-09 21:02:46', 'Android', '103');
INSERT INTO `award_receive` VALUES ('484', '118537', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-09 22:42:22', 'Android', '102');
INSERT INTO `award_receive` VALUES ('485', '106984', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-10 01:07:54', 'Android', '110');
INSERT INTO `award_receive` VALUES ('486', '118574', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-10 01:57:48', 'Android', '103');
INSERT INTO `award_receive` VALUES ('487', '118587', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-10 08:16:35', 'Android', '101');
INSERT INTO `award_receive` VALUES ('488', '115824', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-10 17:52:07', 'Android', '110');
INSERT INTO `award_receive` VALUES ('489', '105398', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-10 17:57:50', 'Android', '110');
INSERT INTO `award_receive` VALUES ('490', '118689', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-10 18:40:12', 'Android', '102');
INSERT INTO `award_receive` VALUES ('491', '118705', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-10 21:47:41', 'Android', '110');
INSERT INTO `award_receive` VALUES ('492', '118714', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-10 22:15:39', 'Android', '109');
INSERT INTO `award_receive` VALUES ('493', '113714', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-11 06:58:05', 'Android', '107');
INSERT INTO `award_receive` VALUES ('494', '118732', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-11 09:43:44', 'Android', '103');
INSERT INTO `award_receive` VALUES ('495', '118735', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-11 11:35:42', 'Android', '107');
INSERT INTO `award_receive` VALUES ('496', '118741', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-11 14:31:38', 'Android', '107');
INSERT INTO `award_receive` VALUES ('497', '118743', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-11 14:49:59', 'Android', '109');
INSERT INTO `award_receive` VALUES ('498', '118745', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-11 15:30:24', 'Android', '102');
INSERT INTO `award_receive` VALUES ('499', '112141', '1', 'NEWUSER_500_BOOKMONEY', '2', '2019-04-11 16:15:40', 'Android', '107');

-- ----------------------------
-- Table structure for `banner`
-- ----------------------------
DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `img` varchar(512) NOT NULL COMMENT '图片URL',
  `url` varchar(512) DEFAULT NULL COMMENT '链接地址',
  `position` varchar(50) NOT NULL COMMENT '位置(recommend推荐、categoryBoy分类-男生、categoryGirl分类-女生、girl女生、boy男生、personalCenter个人中心)',
  `type` varchar(255) NOT NULL COMMENT 'banner对象类型（H5、App）',
  `associatedId` varchar(20) DEFAULT NULL COMMENT '关联id,code等',
  `beginTime` datetime DEFAULT NULL COMMENT '轮播图开始时间',
  `endTime` datetime DEFAULT NULL COMMENT '轮播图结束时间',
  `validStatus` int(11) DEFAULT NULL COMMENT '有效状态 1：有效；0；无效',
  `channel` varchar(20) DEFAULT NULL COMMENT '渠道',
  `orderIndex` int(11) DEFAULT NULL COMMENT '排序',
  `bgColor` varchar(255) DEFAULT NULL COMMENT '背景色',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  `updateTime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of banner
-- ----------------------------
INSERT INTO `banner` VALUES ('1', 'https://qy-pic.oss-cn-shenzhen.aliyuncs.com/banner/banner_1.png', '{\"linkType\":\"app\",\"url\":\"checkIn\"}', 'recommend', 'app', '11023567603485803', '2019-05-09 10:12:41', '2019-12-31 14:12:44', '1', '', '0', 'https://qy-pic.oss-cn-shenzhen.aliyuncs.com/banner/banner1_bg.png', '2019-05-27 18:34:08', '2019-05-27 18:34:08');
INSERT INTO `banner` VALUES ('2', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/null/c7ca7dc3-ea55-44e4-920c-19132e390ec1-1558602801786.gif', '{\"linkType\":\"h5\",\"url\":\"http://engine.raisinsta.com/index/activity?appKey=H9QGNXKEDFSkeJG6KTkKPVR3nBj&adslotId=287181\"}', 'recommend', 'h5', '1', '2019-05-09 14:47:16', '2019-12-31 14:47:35', '1', '', '0', 'https://qy-pic.oss-cn-shenzhen.aliyuncs.com/banner/banner2_bg.png', '2019-05-23 17:16:27', '2019-05-23 17:16:27');
INSERT INTO `banner` VALUES ('4', 'https://qy-pic.oss-cn-shenzhen.aliyuncs.com/banner/a_banner_5.png', '{\"linkType\":\"app\",\"url\":\"book://1611\"}', 'recommend', 'app', '3', '2019-05-09 14:07:58', '2019-12-31 15:08:09', '1', '', '0', 'https://qy-pic.oss-cn-shenzhen.aliyuncs.com/banner/a_banner5_bg.png', '2019-05-31 16:34:05', '2019-05-31 16:34:05');
INSERT INTO `banner` VALUES ('25', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/null/08dd826b-327f-46e3-b5f1-ecb907c4d3d0-1558602821479.jpg', '{\"linkType\":\"h5\",\"url\":\"http://engine.raisinsta.com/index/activity?appKey=H9QGNXKEDFSkeJG6KTkKPVR3nBj&adslotId=287181\"}', 'boy', 'h5', null, '2019-05-23 00:00:00', '2020-05-29 00:00:00', '1', '', null, null, '2019-05-23 17:13:55', '2019-05-23 17:13:55');
INSERT INTO `banner` VALUES ('26', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/null/47255899-2384-4ff8-a937-dd5b16dffaa8-1558602839482.jpg', '{\"linkType\":\"h5\",\"url\":\"http://engine.raisinsta.com/index/activity?appKey=H9QGNXKEDFSkeJG6KTkKPVR3nBj&adslotId=287181\"}', 'girl', 'h5', '', '2019-05-23 00:00:00', '2020-05-30 00:00:00', '1', '', '0', '', '2019-05-27 10:34:50', '2019-05-27 10:34:50');
INSERT INTO `banner` VALUES ('27', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/null/08dd826b-327f-46e3-b5f1-ecb907c4d3d0-1558602821479.jpg', '{\"linkType\":\"h5\",\"url\":\"http://engine.raisinsta.com/index/activity?appKey=H9QGNXKEDFSkeJG6KTkKPVR3nBj&adslotId=287181\"}', 'categoryBoy', 'h5', '', '2019-05-23 00:00:00', '2020-05-29 00:00:00', '1', '', '0', '', '2019-05-31 16:10:53', '2019-05-31 16:10:53');
INSERT INTO `banner` VALUES ('28', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/null/08dd826b-327f-46e3-b5f1-ecb907c4d3d0-1558602821479.jpg', '{\"linkType\":\"app\",\"url\":\"bookshelf\"}', 'personalCenter', 'app', '', '2019-05-23 00:00:00', '2020-05-29 00:00:00', '1', '', '0', '', '2019-05-31 17:01:53', '2019-05-31 17:01:53');
INSERT INTO `banner` VALUES ('29', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/null/08dd826b-327f-46e3-b5f1-ecb907c4d3d0-1558602821479.jpg', '{\"linkType\":\"h5\",\"url\":\"http://engine.raisinsta.com/index/activity?appKey=H9QGNXKEDFSkeJG6KTkKPVR3nBj&adslotId=287181\"}', 'boy', 'h5', '', '2019-05-23 00:00:00', '2020-05-29 00:00:00', '1', '', null, '', '2019-05-23 17:13:55', '2019-05-23 17:13:55');
INSERT INTO `banner` VALUES ('30', 'https://qy-pic.oss-cn-shenzhen.aliyuncs.com/banner/a_banner_5.png', '{\"linkType\":\"app\",\"url\":\"checkIn\"}', 'girl', 'app', '3', '2019-05-09 14:07:58', '2019-12-31 15:08:09', '1', '', '0', 'https://qy-pic.oss-cn-shenzhen.aliyuncs.com/banner/a_banner5_bg.png', '2019-05-29 14:44:44', '2019-05-29 14:44:44');

-- ----------------------------
-- Table structure for `compensate_chance_receive`
-- ----------------------------
DROP TABLE IF EXISTS `compensate_chance_receive`;
CREATE TABLE `compensate_chance_receive` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL COMMENT '用户id',
  `type` varchar(50) DEFAULT NULL COMMENT '类型(video：视频）',
  `receiveDate` varchar(50) DEFAULT NULL COMMENT '领取时间',
  `createTime` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COMMENT='补签机会领取记录';

-- ----------------------------
-- Records of compensate_chance_receive
-- ----------------------------
INSERT INTO `compensate_chance_receive` VALUES ('1', '118856', 'video', '2019-05-24', '2019-05-24 15:21:08');
INSERT INTO `compensate_chance_receive` VALUES ('2', '123', '', '2019-05-24', '2019-05-24 15:28:55');
INSERT INTO `compensate_chance_receive` VALUES ('3', '123', null, '2019-05-24', '2019-05-24 15:29:40');
INSERT INTO `compensate_chance_receive` VALUES ('4', '123', null, '2019-05-24', '2019-05-24 15:29:42');
INSERT INTO `compensate_chance_receive` VALUES ('5', '118856', null, '2019-05-24', '2019-05-24 15:29:59');
INSERT INTO `compensate_chance_receive` VALUES ('6', '118856', null, '2019-05-24', '2019-05-24 15:33:07');
INSERT INTO `compensate_chance_receive` VALUES ('7', '118856', null, '2019-05-24', '2019-05-24 15:33:08');
INSERT INTO `compensate_chance_receive` VALUES ('8', '118856', null, '2019-05-24', '2019-05-24 15:33:08');
INSERT INTO `compensate_chance_receive` VALUES ('9', '118856', null, '2019-05-24', '2019-05-24 15:33:09');
INSERT INTO `compensate_chance_receive` VALUES ('10', '118856', null, '2019-05-24', '2019-05-24 15:33:09');
INSERT INTO `compensate_chance_receive` VALUES ('11', '118856', null, '2019-05-24', '2019-05-24 15:33:09');
INSERT INTO `compensate_chance_receive` VALUES ('12', '118856', null, '2019-05-24', '2019-05-24 15:33:09');
INSERT INTO `compensate_chance_receive` VALUES ('13', '118856', null, '2019-05-24', '2019-05-24 15:33:09');
INSERT INTO `compensate_chance_receive` VALUES ('14', '118856', null, '2019-05-24', '2019-05-24 15:33:10');
INSERT INTO `compensate_chance_receive` VALUES ('15', '118856', null, '2019-05-24', '2019-05-24 15:33:10');
INSERT INTO `compensate_chance_receive` VALUES ('16', '118856', null, '2019-05-24', '2019-05-24 15:33:10');
INSERT INTO `compensate_chance_receive` VALUES ('17', '118856', null, '2019-05-24', '2019-05-24 15:33:10');
INSERT INTO `compensate_chance_receive` VALUES ('18', '118856', null, '2019-05-24', '2019-05-24 15:33:11');
INSERT INTO `compensate_chance_receive` VALUES ('19', '118856', null, '2019-05-24', '2019-05-24 15:33:11');
INSERT INTO `compensate_chance_receive` VALUES ('20', '118856', null, '2019-05-24', '2019-05-24 15:33:12');
INSERT INTO `compensate_chance_receive` VALUES ('21', '118851', 'video', '2019-05-24', '2019-05-24 16:07:06');
INSERT INTO `compensate_chance_receive` VALUES ('22', '118856', null, '2019-05-24', '2019-05-24 17:01:27');
INSERT INTO `compensate_chance_receive` VALUES ('23', '118814', 'video', '2019-05-24', '2019-05-24 17:02:34');
INSERT INTO `compensate_chance_receive` VALUES ('24', '118857', 'video', '2019-05-24', '2019-05-24 17:04:34');
INSERT INTO `compensate_chance_receive` VALUES ('25', '118857', null, '2019-05-24', '2019-05-24 18:47:28');
INSERT INTO `compensate_chance_receive` VALUES ('26', '118857', null, '2019-05-24', '2019-05-24 18:47:29');
INSERT INTO `compensate_chance_receive` VALUES ('27', '118857', null, '2019-05-24', '2019-05-24 18:47:29');
INSERT INTO `compensate_chance_receive` VALUES ('28', '118857', null, '2019-05-24', '2019-05-24 18:47:30');
INSERT INTO `compensate_chance_receive` VALUES ('29', '118857', null, '2019-05-24', '2019-05-24 18:53:30');
INSERT INTO `compensate_chance_receive` VALUES ('30', '118857', null, '2019-05-24', '2019-05-24 18:53:30');
INSERT INTO `compensate_chance_receive` VALUES ('31', '118857', null, '2019-05-24', '2019-05-24 18:53:30');
INSERT INTO `compensate_chance_receive` VALUES ('32', '118857', null, '2019-05-24', '2019-05-24 18:53:31');
INSERT INTO `compensate_chance_receive` VALUES ('33', '118857', null, '2019-05-24', '2019-05-24 18:53:31');
INSERT INTO `compensate_chance_receive` VALUES ('34', '118857', null, '2019-05-24', '2019-05-24 18:53:31');
INSERT INTO `compensate_chance_receive` VALUES ('35', '118857', null, '2019-05-24', '2019-05-24 18:53:34');
INSERT INTO `compensate_chance_receive` VALUES ('36', '118857', null, '2019-05-24', '2019-05-24 18:53:35');
INSERT INTO `compensate_chance_receive` VALUES ('37', '118857', null, '2019-05-24', '2019-05-24 18:53:35');
INSERT INTO `compensate_chance_receive` VALUES ('38', '118857', null, '2019-05-24', '2019-05-24 18:53:35');
INSERT INTO `compensate_chance_receive` VALUES ('39', '118857', null, '2019-05-24', '2019-05-24 18:53:36');
INSERT INTO `compensate_chance_receive` VALUES ('40', '118857', null, '2019-05-27', '2019-05-27 10:05:58');
INSERT INTO `compensate_chance_receive` VALUES ('41', '118814', 'video', '2019-05-28', '2019-05-28 10:33:16');
INSERT INTO `compensate_chance_receive` VALUES ('42', '118844', 'video', '2019-05-28', '2019-05-28 17:12:03');

-- ----------------------------
-- Table structure for `extra_bonus`
-- ----------------------------
DROP TABLE IF EXISTS `extra_bonus`;
CREATE TABLE `extra_bonus` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL COMMENT '用户ID',
  `amount` bigint(20) DEFAULT NULL COMMENT '金额',
  `multiple` int(2) DEFAULT '1' COMMENT '倍数',
  `status` tinyint(2) DEFAULT '0' COMMENT '状态（0：未兑现；1：已兑现）',
  `expiryTime` datetime DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`id`),
  KEY `idex_cuid` (`cuId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='额外奖励';

-- ----------------------------
-- Records of extra_bonus
-- ----------------------------

-- ----------------------------
-- Table structure for `popup_window`
-- ----------------------------
DROP TABLE IF EXISTS `popup_window`;
CREATE TABLE `popup_window` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `windowType` tinyint(2) NOT NULL DEFAULT '0' COMMENT '类型（0:大弹窗; 1:小弹窗）',
  `showType` tinyint(2) DEFAULT '0' COMMENT '显示类型 0：点击消失 1：一直显示',
  `showPage` varchar(50) NOT NULL COMMENT '显示页面',
  `skipType` tinyint(2) DEFAULT '0' COMMENT '跳转类型 0：app内 1：h5',
  `skipPage` varchar(255) DEFAULT NULL COMMENT '跳转页面',
  `status` tinyint(2) DEFAULT '0' COMMENT '状态（0：关闭；1启用）',
  `img` varchar(255) DEFAULT NULL COMMENT '图片',
  `channel` varchar(50) DEFAULT 'all' COMMENT '渠道号',
  `clientType` varchar(255) DEFAULT 'all' COMMENT '客户端类型(android，ios，H5，pc，all）',
  `startTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  `bindActivity` tinyint(2) DEFAULT '0' COMMENT '是否匹配活动（0：否，1：是）',
  `activityId` int(11) DEFAULT NULL COMMENT '活动id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=358 DEFAULT CHARSET=utf8 COMMENT='弹窗';

-- ----------------------------
-- Records of popup_window
-- ----------------------------
INSERT INTO `popup_window` VALUES ('2', '0', '0', 'recommend', '1', '{\"linkType\":\"h5\",\"url\":\"sdf\"}', '1', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/popupWindow/52ddf9f8-8a4e-4ea9-925a-d16adcbb4034-1558507159838.jpg', '', 'all', '2019-05-22 14:59:26', '2019-05-30 00:00:00', '2019-05-22 14:40:10', '0', '0');
INSERT INTO `popup_window` VALUES ('3', '1', '0', 'boy', '0', '{\"linkType\":\"h5\"}', '1', 'http://k.zol-img.com.cn/sjbbs/7692/a7691515_s.jpg', '110', 'Android', '2019-05-22 14:59:26', '2019-05-30 00:00:00', '2019-05-22 14:40:10', '0', '0');
INSERT INTO `popup_window` VALUES ('4', '1', '0', 'girl', '0', '{\"linkType\":\"h5\"}', '1', 'http://k.zol-img.com.cn/sjbbs/7692/a7691515_s.jpg', '107', 'Android', '2019-05-22 14:59:26', '2019-05-30 00:00:00', '2019-05-22 14:40:10', '0', '0');

-- ----------------------------
-- Table structure for `receive_welfare`
-- ----------------------------
DROP TABLE IF EXISTS `receive_welfare`;
CREATE TABLE `receive_welfare` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL COMMENT '用户id',
  `type` varchar(50) DEFAULT NULL COMMENT '福利类型',
  `date` datetime DEFAULT NULL COMMENT '领取时间',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='福利领取记录';

-- ----------------------------
-- Records of receive_welfare
-- ----------------------------
INSERT INTO `receive_welfare` VALUES ('3', '118851', 'dailyShareForGold', '2019-05-22 00:00:00', '2019-05-22 20:28:20');
INSERT INTO `receive_welfare` VALUES ('4', '118814', 'videoForGold100', '2019-05-24 00:00:00', '2019-05-24 11:39:21');
INSERT INTO `receive_welfare` VALUES ('5', '118814', 'videoForGold100', '2019-05-25 00:00:00', '2019-05-25 14:31:16');
INSERT INTO `receive_welfare` VALUES ('6', '118856', 'videoForGold100', '2019-05-25 00:00:00', '2019-05-25 17:58:00');
INSERT INTO `receive_welfare` VALUES ('7', '118860', 'videoForGold100', '2019-05-25 00:00:00', '2019-05-25 18:34:43');
INSERT INTO `receive_welfare` VALUES ('9', '1', 'dailyShareForGold', '2019-05-25 00:00:00', '2019-05-25 18:43:53');
INSERT INTO `receive_welfare` VALUES ('10', '118860', 'dailyShareForGold', '2019-05-25 00:00:00', '2019-05-25 18:48:22');
INSERT INTO `receive_welfare` VALUES ('11', '118859', 'dailyShareForGold', '2019-05-25 00:00:00', '2019-05-25 18:48:46');
INSERT INTO `receive_welfare` VALUES ('12', '118857', 'dailyShareForGold', '2019-05-25 00:00:00', '2019-05-25 18:48:59');
INSERT INTO `receive_welfare` VALUES ('13', '118814', 'dailyShareForGold', '2019-05-25 00:00:00', '2019-05-25 18:51:14');
INSERT INTO `receive_welfare` VALUES ('14', '118832', 'videoForGold100', '2019-05-27 00:00:00', '2019-05-27 15:30:22');
INSERT INTO `receive_welfare` VALUES ('15', '118832', 'dailyShareForGold', '2019-05-27 00:00:00', '2019-05-27 16:54:13');
INSERT INTO `receive_welfare` VALUES ('16', '118837', 'videoForGold100', '2019-05-27 00:00:00', '2019-05-27 17:31:57');
INSERT INTO `receive_welfare` VALUES ('17', '118814', 'videoForGold100', '2019-05-28 00:00:00', '2019-05-28 15:45:44');
INSERT INTO `receive_welfare` VALUES ('18', '118814', 'dailyShareForGold', '2019-05-28 00:00:00', '2019-05-28 16:38:09');
INSERT INTO `receive_welfare` VALUES ('19', '118814', 'videoForGold100', '2019-05-29 00:00:00', '2019-05-29 08:54:22');

-- ----------------------------
-- Table structure for `start_page`
-- ----------------------------
DROP TABLE IF EXISTS `start_page`;
CREATE TABLE `start_page` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `fileType` varchar(10) DEFAULT NULL COMMENT '文件类型 （ pic-图片 | gif-动图  |  video-视频）',
  `fileUrl` varchar(2000) DEFAULT NULL COMMENT '文件url',
  `beginDate` datetime DEFAULT NULL COMMENT '生效期-开始时间',
  `endDate` datetime DEFAULT NULL COMMENT '生效期-结束时间',
  `status` tinyint(2) unsigned DEFAULT NULL COMMENT '是否启用 (1:启用  0：未启用)',
  `channelCodes` varchar(100) DEFAULT NULL COMMENT '渠道编码 （多个渠道用逗号隔开）',
  `clientType` varchar(10) DEFAULT NULL COMMENT '支持的客户端类型 （all | ios | Android ）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of start_page
-- ----------------------------
INSERT INTO `start_page` VALUES ('19', 'pic', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/startPage/faeb782a-daee-45d4-a678-a819bbba2c0f-1548646531330.jpg', '2019-02-04 00:00:00', '2019-05-08 23:59:59', '0', '110', 'Android');
INSERT INTO `start_page` VALUES ('20', 'pic', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/startPage/0b226375-e4ed-4a47-96d2-ec1bebabcf79-1548667438094.jpg', '2019-01-28 00:00:00', '2019-01-28 23:59:00', '0', '107', 'all');
INSERT INTO `start_page` VALUES ('21', 'pic', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/startPage/05ca3405-9cf1-43eb-8076-137377e49f80-1550050187794.jpg', '2019-02-14 00:00:00', '2019-02-14 23:59:59', '1', '', 'all');
INSERT INTO `start_page` VALUES ('22', 'pic', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/startPage/0d0a3c4f-df2a-4d9b-89a4-1cdddf5ce907-1548645958474.jpg', '2019-02-15 00:00:00', '2019-02-18 23:59:59', '0', '107', 'all');
INSERT INTO `start_page` VALUES ('23', 'pic', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/startPage/9acc2226-676f-44ed-9a2c-290794de5b6c-1550050298347.jpg', '2019-02-19 00:00:00', '2019-02-19 23:59:59', '0', '107', 'all');
INSERT INTO `start_page` VALUES ('28', 'pic', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/startPage/dfeaedd6-eb4d-4288-91e9-fb3416695f5f-1552368607894.jpg', '2019-03-12 00:00:00', '2019-03-12 23:59:59', '0', '107', 'all');
INSERT INTO `start_page` VALUES ('29', 'pic', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/startPage/0b518e50-a5b8-4034-bc44-c5416cc0c05f-1553069119773.png', '2019-03-21 00:00:00', '2019-05-31 23:59:59', '0', '', 'all');
INSERT INTO `start_page` VALUES ('31', 'pic', 'http://qy-pic.oss-cn-shenzhen.aliyuncs.com/startPage/dcb9cae8-650e-456f-8359-dc3d7ad771be-1553655577146.png', '2019-03-27 00:00:00', '2023-03-31 00:00:00', '0', '', 'all');

-- ----------------------------
-- Table structure for `welfare`
-- ----------------------------
DROP TABLE IF EXISTS `welfare`;
CREATE TABLE `welfare` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type` varchar(50) DEFAULT NULL COMMENT '类型(novice:新手;read:阅读；daily：日常）',
  `welfareType` varchar(50) DEFAULT NULL COMMENT '福利类型（videoForGold：看视频奖励金豆 | dailyShareForGold：每日分享奖励1-100 | turnaroundDraw：转盘抽奖',
  `rewardType` varchar(20) DEFAULT NULL COMMENT '奖励类型（rmb:人民币，gold:金豆）',
  `mainTitle` varchar(50) DEFAULT NULL COMMENT '主标题',
  `mainTitleColor` varchar(20) DEFAULT NULL COMMENT '主标题字色',
  `subTitle` varchar(50) DEFAULT NULL COMMENT '副标题',
  `subTitleColor` varchar(20) DEFAULT NULL COMMENT '副标题字色',
  `minNum` double(11,2) DEFAULT NULL,
  `maxNum` double(11,2) DEFAULT NULL,
  `skipType` varchar(20) DEFAULT NULL COMMENT '跳转类型(app,h5）',
  `skipPage` varchar(255) DEFAULT NULL COMMENT '跳转地址',
  `buttonTex` varchar(255) DEFAULT NULL COMMENT '按钮文案',
  `iconTex` varchar(255) DEFAULT NULL COMMENT '图标文案',
  `status` tinyint(2) DEFAULT '0' COMMENT '状态（0：停用；1：启用）',
  `sort` int(11) DEFAULT '1' COMMENT '排序',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `showTime` int(11) DEFAULT NULL COMMENT '展示时间：分钟',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_welfareType` (`welfareType`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='福利配置';

-- ----------------------------
-- Records of welfare
-- ----------------------------
INSERT INTO `welfare` VALUES ('3', 'read', '1', 'gold', '每日阅读', '#FF3E3837', '完成阅读时长任务获得额外奖励', '#FF8D8D8D', '0.00', '0.00', 'app', '{\"linkType\":\"app\",\"url\":\"bookshelf\"}', '去阅读', '会员奖励X3', '1', '1', '2019-05-27 15:40:07', '2019-05-31 16:40:58', '1000');
INSERT INTO `welfare` VALUES ('5', 'novice', '2', 'rmb', '有奖答题', '#FF3E3837', '助你玩转任务，累计获得的金豆越多', '#FF8D8D8D', '1.00', '1.00', 'h5', '{\"linkType\":\"h5\"}', '去参与', '+1', '0', '1', '2019-05-31 15:43:17', '2019-05-31 16:38:03', '10000');
INSERT INTO `welfare` VALUES ('16', 'daily', '3', 'gold', '观看小视频', '#FF3E3837', '观看15~30秒小视频获得丰厚金豆奖励', '#FF8D8D8D', '100.00', '100.00', 'app', '{\"linkType\":\"video\"}', '去观看', '+100', '1', '1', '2019-05-25 18:01:29', '2019-05-31 14:38:14', '0');
INSERT INTO `welfare` VALUES ('17', 'daily', '4', 'gold', '每日分享', '#FF3E3837', '分享至朋友圈，微信可获得100金豆奖励', '#FF8D8D8D', '100.00', '100.00', 'app', '{\"linkType\":\"share\"}', '去分享', '最高100', '1', '1', '2019-05-13 18:03:24', '2019-05-31 17:06:12', '0');
INSERT INTO `welfare` VALUES ('18', 'daily', '5', 'rmb', '邀请好友获得现金奖励', '#FF3E3837', '邀请好友双方获得现金红包，可提现', '#FF8D8D8D', '1.00', '2.00', 'h5', '{\"linkType\":\"h5\",\"url\":\"http://192.168.18.212/#/free/invite\"}', '去邀请', '可提现', '1', '1', '2019-05-25 18:04:40', '2019-05-31 16:56:21', '0');
INSERT INTO `welfare` VALUES ('19', 'daily', '6', 'rmb', '幸运转盘', '#FF3E3837', '金豆，现金红包，100%中奖', '#FF8D8D8D', '0.00', '0.00', 'h5', '{\"linkType\":\"h5\",\"url\":\"http://192.168.18.212/#/free/lottery\"}', '去抽奖', '随机大奖', '1', '1', '2019-05-25 18:06:09', '2019-05-31 16:58:14', '0');
INSERT INTO `welfare` VALUES ('20', 'read', '7', 'gold', '阅读30秒计时奖励', '#FF3E3837', '阅读时间越久，累计获得的金豆越多', '#FF8D8D8D', '50.00', '50.00', 'app', '{\"linkType\":\"app\",\"url\":\"bookshelf\"}', '去阅读', '最高50', '1', '1', '2019-05-25 18:11:17', '2019-05-29 11:24:50', '0');
INSERT INTO `welfare` VALUES ('22', 'novice', '8', 'gold', '绑定手机', '#FF3E3837', '绑定手机奖励100金豆', '#FF8D8D8D', '100.00', '100.00', 'app', '{\"linkType\":\"app\",\"url\":\"bindPhone\"}', '去绑定', '+100', '1', '1', '2019-05-28 10:32:01', '2019-05-29 11:25:01', '10000');
INSERT INTO `welfare` VALUES ('23', 'novice', '9', 'rmb', '限时邀请好友', '', '成功邀请一位好友，金豆翻倍', '', '1.00', '5.00', 'app', '{\"linkType\":\"app\",\"url\":\"invite\"}', '最高10倍', '去邀请', '1', '1', '2019-05-31 13:51:58', '2019-06-03 10:50:36', '0');
INSERT INTO `welfare` VALUES ('24', 'novice', '10', 'rmb', 'test', '', '', '', '3.00', '25.00', 'app', '{\"linkType\":\"app\",\"url\":\"invite\"}', 'res', 'tets', '1', '1', '2019-05-31 14:28:42', '2019-05-31 14:36:13', '0');
INSERT INTO `welfare` VALUES ('25', 'novice', null, 'rmb', '填好友红包码', '', '填写好友红包码领现金红包，可提现', '', '0.00', '0.00', 'app', '{\"linkType\":\"app\",\"url\":\"rewardCode\"}', '去填写', '最高5元', '1', '2', '2019-05-31 16:39:17', '2019-05-31 16:39:17', null);

-- ----------------------------
-- Table structure for `welfare_chance`
-- ----------------------------
DROP TABLE IF EXISTS `welfare_chance`;
CREATE TABLE `welfare_chance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cuId` bigint(20) NOT NULL COMMENT '用户id',
  `type` varchar(50) DEFAULT NULL COMMENT '类型',
  `restTimes` int(11) DEFAULT '0' COMMENT '机会次数',
  `usedTimes` int(11) DEFAULT '0' COMMENT '已使用',
  `date` date DEFAULT NULL COMMENT '日期',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cuid_type_date` (`cuId`,`type`,`date`) USING BTREE COMMENT '唯一索引',
  KEY `index_cuid` (`cuId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='福利领取机会';

-- ----------------------------
-- Records of welfare_chance
-- ----------------------------
INSERT INTO `welfare_chance` VALUES ('2', '118852', 'TurnaroundDraw', '5', '5', '2019-05-23');
INSERT INTO `welfare_chance` VALUES ('3', '118852', 'TurnaroundDraw', '5', '5', '2019-05-24');
INSERT INTO `welfare_chance` VALUES ('5', '118851', 'TurnaroundDraw', '1', '1', '2019-05-24');
INSERT INTO `welfare_chance` VALUES ('6', '118814', 'TurnaroundDraw', '5', '3', '2019-05-25');
INSERT INTO `welfare_chance` VALUES ('7', '118852', 'TurnaroundDraw', '1', '0', '2019-05-25');
INSERT INTO `welfare_chance` VALUES ('8', '118860', 'TurnaroundDraw', '2', '0', '2019-05-25');
INSERT INTO `welfare_chance` VALUES ('9', '118859', 'TurnaroundDraw', '5', '5', '2019-05-25');
INSERT INTO `welfare_chance` VALUES ('10', '118857', 'TurnaroundDraw', '5', '5', '2019-05-25');
INSERT INTO `welfare_chance` VALUES ('11', '1', 'TurnaroundDraw', '2', '0', '2019-05-25');
INSERT INTO `welfare_chance` VALUES ('12', '118866', 'TurnaroundDraw', '2', '2', '2019-05-27');
INSERT INTO `welfare_chance` VALUES ('13', '118814', 'TurnaroundDraw', '5', '5', '2019-05-28');
INSERT INTO `welfare_chance` VALUES ('14', '118872', 'TurnaroundDraw', '3', '2', '2019-05-28');
INSERT INTO `welfare_chance` VALUES ('15', '118869', 'TurnaroundDraw', '1', '1', '2019-05-28');
INSERT INTO `welfare_chance` VALUES ('16', '118814', 'turnaroundDraw', '5', '5', '2019-05-29');
INSERT INTO `welfare_chance` VALUES ('17', '118877', 'turnaroundDraw', '1', '0', '2019-05-29');
INSERT INTO `welfare_chance` VALUES ('18', '118814', 'turnaroundDraw', '5', '5', '2019-05-30');
INSERT INTO `welfare_chance` VALUES ('19', '118886', 'turnaroundDraw', '2', '1', '2019-05-30');
INSERT INTO `welfare_chance` VALUES ('20', '118888', 'turnaroundDraw', '2', '1', '2019-05-30');
INSERT INTO `welfare_chance` VALUES ('21', '118885', 'turnaroundDraw', '5', '5', '2019-05-31');
INSERT INTO `welfare_chance` VALUES ('22', '118814', 'turnaroundDraw', '1', '0', '2019-05-31');
INSERT INTO `welfare_chance` VALUES ('23', '0', 'turnaroundDraw', '1', '0', '2019-05-31');
INSERT INTO `welfare_chance` VALUES ('24', '118873', 'turnaroundDraw', '1', '0', '2019-05-31');
INSERT INTO `welfare_chance` VALUES ('25', '118892', 'turnaroundDraw', '5', '5', '2019-05-31');
INSERT INTO `welfare_chance` VALUES ('27', '118876', 'turnaroundDraw', '1', '1', '2019-05-31');
